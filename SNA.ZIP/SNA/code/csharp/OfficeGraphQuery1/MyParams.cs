﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficeGraphQuery1
{
    
     class MyParams
    {
        public enum TypeUseOutNode { none, one, all };
        public TypeUseOutNode m_useOutNode;
        public bool m_createSocialNetwork;
        public string m_hGraphFileName;
        public string m_sGraphFileName;
        public string m_rootActorID;
        public string m_rootActorTitle;
        public int m_maxRowsWorkingWith;
        public int m_maxRowsTrending;
        public int m_maxRowsModified;

        public int m_minRankMDocument;
        public int m_minRankTrending;

        public bool m_readModifiedTitles;
        public bool m_readTrendingTitles;

        public MyParams()
        {
            m_useOutNode = TypeUseOutNode.one;
            m_createSocialNetwork = true;
            m_hGraphFileName = "c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\hGraph.xml";
            m_sGraphFileName = "c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\sGraph.xml";
            m_rootActorID = "149342363";//Ariel
            m_rootActorTitle = "unknown";


            //m_rootActorID = "148886980";
            //m_rootActorTitle = "Yifat";
            m_minRankMDocument = 3;
            m_minRankTrending = 10000;
            m_maxRowsWorkingWith = 12;
            m_maxRowsTrending = 20;
            m_maxRowsModified = 10;

            m_readModifiedTitles = true;
            m_readTrendingTitles = true;


        }
    }
}
