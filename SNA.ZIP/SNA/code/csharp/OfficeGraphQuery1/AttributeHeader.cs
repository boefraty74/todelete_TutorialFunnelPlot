﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficeGraphQuery1
{
    public class AttributeHeader
    {
        public string m_id;
        public string m_for;
        public string m_name;
        public string m_type;
        public string m_default;
        public AttributeHeader(string id,string sfor,string name,string type,string sdefault)
        {
            m_id=id;
            m_for=sfor;
            m_name=name;
            m_type=type;
            m_default=sdefault;
        }
        public AttributeHeader(string id, string sfor)
        {
            m_id = id;
            m_for = sfor;// "node";
            m_name = id;
            m_type = "string";
            m_default = "None";
        }
        public AttributeHeader(string id, string sfor,string type)
        {
            m_id = id;
            m_for = sfor;
            m_name = id;
            m_type = type;
            if (type == "string")
                m_default = "None";
            else if (type == "double")
                m_default = "0";

        }


    }
}
