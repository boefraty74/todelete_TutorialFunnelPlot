﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace OfficeGraphQuery1
{
  
    public class MyGraph
    {
        public enum GraphType { regular, hierarchy, special1, special2 }
        public List<MyEdge> m_list_edges;
        public List<MyNode> m_list_nodes;

        public bool m_is_directed;
        public List<Attribute> m_list_attributes;
        public List<AttributeHeader> m_list_attributeHeaders;

        public MyNode m_specialNode1;
        public MyNode m_specialNode2;

        public string m_id;
        public GraphType m_gtype;
        public MyGraph()
        {
            m_is_directed = false;
            m_list_attributes = new List<Attribute>();
            m_list_attributeHeaders = new List<AttributeHeader>();
            m_list_nodes = new List<MyNode>();
            m_list_edges = new List<MyEdge>();
            m_specialNode1 = null;
            m_specialNode2 = null;
            m_gtype = GraphType.regular;
        }

        public void CloneOnlyNodes(MyGraph g)
        {
            foreach (MyNode aNode in g.m_list_nodes)
            {
                string id = aNode.m_id;
                MyNode newNode = new MyNode(id);
                //clone attributes
                newNode.CloneOnlyAttributes(aNode);
                newNode.m_ntype = aNode.m_ntype;
                this.m_list_nodes.Add(newNode);
            }

        }
        public MyNode FindOrAddNode(string id, bool with_create)
        {
            MyNode retNode = null;
            foreach (MyNode aNode in this.m_list_nodes)
            {
                if (aNode.m_id == id)
                {
                    retNode = aNode;
                    break;
                }

            }
            if (retNode == null && with_create)
            {
                retNode = new MyNode(id);
                m_list_nodes.Add(retNode);
            }
            return retNode;
        }
        public MyNode FindOrAddNewNode(MyNode n, bool with_create)
        {
            MyNode retNode = null;
            foreach (MyNode aNode in this.m_list_nodes)
            {
                if (aNode.m_id == n.m_id)
                {
                    retNode = aNode;
                    break;
                }

            }
            if (retNode == null && with_create)
            {
                retNode = new MyNode(n,true);
                m_list_nodes.Add(retNode);
            }
            return retNode;
        }
        public MyNode FindNode(string id)
        {
            MyNode retNode = null;
            foreach (MyNode aNode in this.m_list_nodes)
            {
                if (aNode.m_id == id)
                {
                    retNode = aNode;
                    break;
                }

            }
            
            return retNode;
        }
        public MyNode AddNewNode(string id)
        {//no checks
                MyNode retNode = new MyNode(id);
                m_list_nodes.Add(retNode);        
                return retNode;
        }
        public MyNode AddNewNode(MyNode retNode)
        {//no checks
            m_list_nodes.Add(retNode);
            return retNode;
        }

        public void WriteGraphToXML(string fileName)
        {
            bool weightInAttributes = (AttributesList.FindAttribute("weight", this.m_list_attributeHeaders) != null);
            if (!weightInAttributes)
            {
                m_list_attributeHeaders.Add(new AttributeHeader("weight", "edge", "weight", "double", "1"));
                foreach(MyEdge e in this.m_list_edges)
                {
                    e.m_list_attributes.Add(new Attribute("weight", e.m_weight.ToString()));
                }
            }

            using (XmlWriter writer = XmlWriter.Create(fileName))
            {
                writer.WriteStartDocument();
                
                
                writer.WriteStartElement("graphml", "http://graphml.graphdrawing.org/xmlns");
                writer.WriteAttributeString("xmlns", "xsi", null,"http://www.w3.org/2001/XMLSchema-instance");
                writer.WriteAttributeString("xsi", "schemaLocation", null, "http://graphml.graphdrawing.org/xmlns http://graphml.graphdrawing.org/xmlns/1.0/graphml.xsd");

                // Write  graph/node/edge Attributes Header ,default, type etc.               
                foreach (AttributeHeader ah in this.m_list_attributeHeaders)
                {
                    writer.WriteStartElement("key");
                     writer.WriteAttributeString("id", ah.m_id);
                    writer.WriteAttributeString("for", ah.m_for);
                    writer.WriteAttributeString("attr.name", ah.m_name);
                    writer.WriteAttributeString("attr.type", ah.m_type);
                    writer.WriteStartElement("default");
                    writer.WriteString(ah.m_default);
                    writer.WriteEndElement();//default
                    writer.WriteEndElement();//key
                }


         
 
                writer.WriteStartElement("graph");
                writer.WriteAttributeString("id", this.m_id);
                if(this.m_is_directed)
                    writer.WriteAttributeString("edgedefault", "directed");
                else
                    writer.WriteAttributeString("edgedefault", "undirected");
              
                //TODO: write all graph attributes 
                foreach (Attribute a in this.m_list_attributes)
                {
                    writer.WriteStartElement("data");
                    writer.WriteAttributeString("key", a.m_name);
                    writer.WriteString(a.m_data);
                    writer.WriteEndElement();
                }

                foreach (MyNode node in this.m_list_nodes)
                {
                    writer.WriteStartElement("node");

                    writer.WriteAttributeString("id", node.m_id);
                    //write all node Attributes 
                    foreach(Attribute a in node.m_list_attributes)
                    {
                        writer.WriteStartElement("data");
                        writer.WriteAttributeString("key", a.m_name);
                        writer.WriteString(a.m_data);
                        writer.WriteEndElement();
                    }




                    writer.WriteEndElement();
                }
              
                

                foreach (MyEdge edge in this.m_list_edges)
                {
                    writer.WriteString("\n");
                    //<edge source="Jones" target="Williams"/>
                    writer.WriteStartElement("edge");                  
                    writer.WriteAttributeString("target", edge.m_to.m_id);
                    writer.WriteAttributeString("source", edge.m_from.m_id);
                   

                    //Write all Edge  Attributes                  
                    foreach (Attribute a in edge.m_list_attributes)
                    {
                        writer.WriteStartElement("data");
                        writer.WriteAttributeString("key", a.m_name);
                        writer.WriteString(a.m_data);
                        writer.WriteEndElement();
                    }
                    writer.WriteEndElement();
                }
                writer.WriteEndElement();//</graph>
                writer.WriteEndElement();//</graphml>
                writer.WriteEndDocument();
                writer.Flush();
                writer.Close();
            }



        }

        public void AddSocialEdge(MyNode nodeFrom, MyNode nodeTo, double w)
        {
            string id_from = nodeFrom.m_id;
            string id_to = nodeTo.m_id;
            int to_or_from=0;

            MyEdge e = null;
            //check if similar edge exists
            foreach (MyEdge edge in this.m_list_edges)
            {
               if(id_from==edge.m_from.m_id && id_to==edge.m_to.m_id)
               {
                   to_or_from=1;
                   e = edge;
                   break;
               }
               else if(id_to==edge.m_from.m_id && id_from==edge.m_to.m_id)
                    {
                   to_or_from=-1;
                   e = edge;
                   break;
               }
            }
            if(e==null)//create new
            {
                e = new MyEdge(nodeFrom, nodeTo);
                e.m_weight = w;
                nodeFrom.m_list_edges_as_source.Add(e);
                nodeTo.m_list_edges_as_target.Add(e);
                this.m_list_edges.Add(e);
            }
            else//update existing 
            {
                e.m_weight += w;
            }


        }
        
        public void AddNewEdge(MyNode nodeFrom, MyNode nodeTo, double w)
        {
            string id_from = nodeFrom.m_id;
            string id_to = nodeTo.m_id;
           
            MyEdge e = new MyEdge(nodeFrom,nodeTo);
            e.m_weight = w;
            nodeFrom.m_list_edges_as_source.Add(e);
            nodeTo.m_list_edges_as_target.Add(e);
            this.m_list_edges.Add(e);
        }
        public MyEdge FindOrAddNewEdge(MyEdge e, bool keepDirect,bool createNew)
        {
            MyEdge eNew = null;
            //Edge e is foreign (not in graph)
            string id_from = e.m_from.m_id;
            string id_to = e.m_to.m_id;
            bool eExistingFromTo = false;
            bool eExistingToFrom = false;
            //TODO: time consuming
            foreach(MyEdge e_temp in this.m_list_edges)
            {
                string temp_id_from = e_temp.m_from.m_id;
                string temp_id_to = e_temp.m_to.m_id;
                if(id_from==temp_id_from && id_to==temp_id_to )
                {
                    eExistingFromTo = true;
                    eNew = e_temp;
                    break;
                }
                else if(id_from==temp_id_to && id_to==temp_id_from)
                {
                    eExistingToFrom = true;
                    if (!keepDirect)
                    {
                        eNew = e_temp;
                        break;
                    }
                }
            }

            if ((!eExistingFromTo && !eExistingToFrom) || (!eExistingFromTo && eExistingToFrom && keepDirect))
            { 
                //add from-to
                MyNode nodeFrom = FindNode(e.m_from.m_id);
                MyNode nodeTo = FindNode(e.m_to.m_id);
                
                eNew = new MyEdge(nodeFrom, nodeTo);
                eNew.m_weight = e.m_weight;
                nodeFrom.m_list_edges_as_source.Add(e);
                nodeTo.m_list_edges_as_target.Add(e);
                this.m_list_edges.Add(e);         
            }
            return eNew;
           
        }

        public void AddTreeRankPerNode()
        {// for each node go up-up-up till still in graph (root) and count "ups"  
            if(this.m_gtype!=GraphType.hierarchy)
            {
                //TODO: error
                return;
            }
            foreach (MyNode node in this.m_list_nodes)
            {
                int tempRank = 0;
                MyNode tempNode = node;
                while(true)
                {
                    if (tempNode.m_list_edges_as_target.Count == 0)
                    {
                        node.m_list_attributes.Add(new Attribute("hrank", tempRank.ToString()));
                        break;
                    }
                    tempNode=tempNode.m_list_edges_as_target.First().m_from;
                    tempRank = tempRank+1;
                    if(tempRank>10000)//not tree
                    {
                        //TODO: error 
                        return;
                    }
                   
                }
            }



        }


       
        public void AddDirectsAndColleguesPerNode()
        {
            if (this.m_gtype != GraphType.hierarchy)
            {
                //TODO: error
                return;
            }
            foreach (MyNode node in this.m_list_nodes)
            {
                int tempDirects = node.m_list_edges_as_source.Count;
                node.m_list_attributes.Add(new Attribute("numDirects", tempDirects.ToString()));
                if(tempDirects>0)
                {
                    foreach (MyEdge edge in node.m_list_edges_as_source)
                    {
                        edge.m_to.m_list_attributes.Add(new Attribute("numCollegues", tempDirects.ToString()));
                    }

                }
            }
        }
        public void AddNumViewedPerNode()
        {

        }

        public void MergeGraphs(MyGraph addG)
        {
            //Merge addG into original 
            foreach (MyNode n in addG.m_list_nodes)
            {
                this.FindOrAddNewNode(n, true);
            }
            foreach (MyEdge e in addG.m_list_edges)
            {
                this.FindOrAddNewEdge(e,addG.m_is_directed,true);
            }

        }


        

        public void DeleteNode(string nodeid)
        { //TODO
        }
        public void DeleteNode(MyNode n)
        { //TODO
        }
        public void DeleteEdge(MyNode n1, MyNode n2)
        { //TODO
        }
        public void DeleteEdge(string n1_id,string n2_id)
        { //TODO
        }
        public void DeleteEdges(MyNode n)
        { //TODO
        }
        public void DeleteEdges(string n_id)
        { //TODO
        }

    }

    

}
