﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficeGraphQuery1
{
    public enum NodeType { regular, root, special1, special2 }
    public class MyNode
    {
        public string m_id;
        public List<Attribute> m_list_attributes;
        public List<MyEdge> m_list_edges_as_source;
        public List<MyEdge> m_list_edges_as_target;
        public int m_myflag;
        public NodeType m_ntype;
        public MyNode()
        {
            m_id = null;
            m_list_attributes = new List<Attribute>();
            m_list_edges_as_source = new List<MyEdge>();
            m_list_edges_as_target = new List<MyEdge>();
            m_myflag = 0;
            m_ntype = NodeType.regular;
        }
        public MyNode(string id)
        {
            m_id = id;
            m_list_attributes = new List<Attribute>();
            m_list_edges_as_source = new List<MyEdge>();
            m_list_edges_as_target = new List<MyEdge>();
            m_myflag = 0;
            m_ntype = NodeType.regular;
        }
        public MyNode(MyNode n,bool isolated)
        {
            m_id = n.m_id;
            m_list_attributes = new List<Attribute>();
            CloneOnlyAttributes(n);
            if (isolated)
            {
                m_list_edges_as_source = new List<MyEdge>();
                m_list_edges_as_target = new List<MyEdge>();
            }
            else
            {//TODO
                m_list_edges_as_source = new List<MyEdge>(n.m_list_edges_as_source);
                m_list_edges_as_target = new List<MyEdge>(n.m_list_edges_as_target);
            }
            m_myflag = n.m_myflag;
            m_ntype = n.m_ntype;
        }
        public void CloneOnlyAttributes(MyNode n)
        {
            foreach (Attribute aAtt in n.m_list_attributes)
            {
                Attribute aaa = new Attribute(aAtt.m_name,aAtt.m_data);
                this.m_list_attributes.Add(aaa);
            }
        }
        public void UpdateOneAttribute(MyNode n,string name)
        {
            string atrData = AttributesList.FindAttribute(name, n.m_list_attributes).m_data;
            Attribute a = AttributesList.FindAttribute(name, this.m_list_attributes);
            if (atrData == null)
                return;
            if(a==null)
            {
                this.m_list_attributes.Add(new Attribute(name, atrData));
            }
            else
            {
                a.m_data = atrData;
            }
        }
    }

}
