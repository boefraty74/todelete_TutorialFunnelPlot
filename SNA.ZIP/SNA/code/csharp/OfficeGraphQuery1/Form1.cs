﻿using Microsoft.Office365.Discovery;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Numerics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace OfficeGraphQuery1
{
    
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private async Task<XmlDocument> sendRequest(string query)
        {
            string requestUrl = String.Format("https://microsoft.sharepoint.com/_api/search/query?{0}", query);

            HttpClient client = new HttpClient();
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, requestUrl);
            HttpResponseMessage response = await client.SendAsync(request);
            
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(await response.Content.ReadAsStreamAsync());

            return xmlDoc;
        }

        private async Task<System.IO.Stream> GetStream(string query)
        {
            string requestUrl = String.Format("https://microsoft.sharepoint.com/_api/search/query?{0}", query);

            HttpClient client = new HttpClient();
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, requestUrl);
            HttpResponseMessage response = await client.SendAsync(request);

            return await response.Content.ReadAsStreamAsync();
        }

        static string xml_query = "d:query";
        static string xml_PrimaryQueryResult = "d:PrimaryQueryResult";
        static string xml_relevantResults = "d:RelevantResults";
        static string xml_table = "d:Table";
        static string xml_Rows = "d:Rows";
        static string xml_element = "d:element";
        static string xml_Key = "d:Key";
        static string xml_Value = "d:Value";
        static string xml_Cells = "d:Cells";

        static string spo_query = "querytext=%27*%27&RowLimit=100&Properties=%27GraphQuery:actor({0}\\,action\\:{1}),GraphRankingModel:{{\"features\"\\:[{{\"function\"\\:\"edgeweight\"}}]}}%27&RankingModelId=%270c77ded8-c3ef-466d-929d-905670ea1d72%27";

        static string spo_query_flex = "querytext=%27*%27&RowLimit={2}&Properties=%27GraphQuery:actor({0}\\,action\\:{1}),GraphRankingModel:{{\"features\"\\:[{{\"function\"\\:\"edgeweight\"}}]}}%27&RankingModelId=%270c77ded8-c3ef-466d-929d-905670ea1d72%27";

        static string spo_query_flex1 = "querytext=%27*%27Username:{0}%27*%27&amp;SourceId=%27*%27b09a7990-05ea-4af9-81ef-edfab16c4e31%27*%27&amp;SelectProperties=%27*%27UserName,DocId72%27";



        private async void btnSubmit_Click_old(object sender, EventArgs e)
        {
            string query = string.Format(spo_query, this.textBox1.Text, ActionNNNN(null, Int32.Parse(this.textBox2.Text)));
            // string query = string.Format(spo_query, "149327567", ActionNNNN(null,1021));
          //  string query = string.Format(spo_query, "149474413", ActionNNNN(null, 1013));//Eyal's manager
           // string query = string.Format(spo_query, "149342363", ActionNNNN(null, 1014));//Ariel's workers
            //string query = string.Format(spo_query, "148886980", ActionNNNN(null, 1014));//Yifat's workers
           // string query = string.Format(spo_query, "148886980", ActionNNNN(null, 1033));//Yifat's "working with"
            //string query = string.Format(spo_query, "149342363", ActionNNNN(null, 1033));//Ariel's "working with"
          //  string query1 = string.Format(spo_query_flex1, "boefraty");
             try
             {
                 DataTable table = await TableFromQuery(query);
                 Show(table);
                 
            //     DataTable table1 = await TableFromQuery(query1);
             
            

            //while (MessageBox.Show("Do You want to query over table?", "Again?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            //{
            //    // wun query for each row and return a result in a table for each row.
            //    // You should give: table, query format, column names for each parameter, transform methods.
            //    var tables = await QueryForEachRow(
            //        table, 
            //        spo_query,
            //        new string[] { "Edges" /* parameter for GetObjectId*/, null /*parameter for Action1033 */ },
            //        new ValueTransform[] { GetObjectId, Action1033 });

            //    DataTable all = MergeTables(tables);
            //    Show(all);
            //    table = all;
            //}
            //MessageBox.Show("Done");
             }
             catch
             {
                 MessageBox.Show("Ooops");
                 return;
             }
        }


        private async void btnSubmit_Click(object sender, EventArgs e)
        {
            MyParams myparams = new MyParams();
            int MAX_LEVEL = 4;
            //string query = string.Format(spo_query, "149342363", ActionNNNN(null, 1014));//Ariel's workers
            string rootActorID = myparams.m_rootActorID;
            if (this.textBox1.Text.Length > 1)
                rootActorID = this.textBox1.Text;
            
            //
            string[] vecStr = new string[10];

            List<string> listActorIDs = new List<string>();
            int numRows = this.dataGridView2.Rows.Count;
            for(int r=0;r<numRows;r++)
            {
                if (this.dataGridView2.Rows[r].Cells[0].Value != null)
                {
                    listActorIDs.Add(this.dataGridView2.Rows[r].Cells[0].Value.ToString());
                    vecStr[r] = this.dataGridView2.Rows[r].Cells[0].Value.ToString();
                }
            }

            if (vecStr[0]!=null)
                rootActorID = vecStr[0];

            string rootActorTitle = myparams.m_rootActorTitle;

            MyGraph hGraph = new MyGraph();
            hGraph.m_is_directed = true;
            hGraph.m_id = "hierarchy_graph";
            hGraph.m_gtype = MyGraph.GraphType.hierarchy;
            MyNode rootNode = hGraph.FindOrAddNode(rootActorID,true);

            if (this.dataGridView2.Rows[0].Cells[2].Value != null)
                rootNode.m_list_attributes.Add(new Attribute("Title", this.dataGridView2.Rows[0].Cells[2].Value.ToString()));
            else
                rootNode.m_list_attributes.Add(new Attribute("Title", rootActorTitle));

            hGraph = await RecFillNodes(sender, e, rootNode, hGraph, 1, MAX_LEVEL);//TODO change maxLevel
            for (int jj = 1; jj < numRows;jj++)
            {
                if (vecStr[jj]!=null)
                {
                    string rootActorID_temp = vecStr[jj];
                    MyGraph hGraph_temp = new MyGraph();
                    hGraph_temp.m_is_directed = true;
                    hGraph_temp.m_id = "hierarchy_graph";
                    hGraph_temp.m_gtype = MyGraph.GraphType.hierarchy;
                    MyNode rootNode_temp = hGraph_temp.FindOrAddNode(rootActorID_temp, true);
                    if (this.dataGridView2.Rows[jj].Cells[2].Value!=null)
                        rootNode_temp.m_list_attributes.Add(new Attribute("Title", this.dataGridView2.Rows[jj].Cells[2].Value.ToString()));
                    else
                        rootNode_temp.m_list_attributes.Add(new Attribute("Title", "Someone"));

                    hGraph_temp = await RecFillNodes(sender, e, rootNode_temp, hGraph_temp, 1, MAX_LEVEL);
                    hGraph.MergeGraphs(hGraph_temp);
                }
            }

           hGraph.AddTreeRankPerNode();// add ranks

           
           hGraph.AddDirectsAndColleguesPerNode();// add ranks
           
           
           
            //use same nodes to discover social connections
            MyGraph sGraph = new MyGraph();//social graph
            sGraph.m_is_directed = false;
            sGraph.m_id = "social_graph";
            //copy nodes from hGraph to sGraph
            // clone nodes 
            sGraph.CloneOnlyNodes(hGraph);

            if (myparams.m_useOutNode != MyParams.TypeUseOutNode.none)
            {
                MyNode outNode = new MyNode("-100");//fictional node
                outNode.m_list_attributes.Add(new Attribute("Title", "OUTSIDE"));
                outNode.m_ntype = NodeType.special1;
                sGraph.AddNewNode(outNode);
                sGraph.m_specialNode1 = outNode;

                hGraph.AddNewNode(outNode);
            }

            hGraph.m_list_attributeHeaders.Add(new AttributeHeader("Title", "node", "Title", "string", "unknown"));
            hGraph.m_list_attributeHeaders.Add(new AttributeHeader("hrank", "node", "hrank", "double", "0"));
            hGraph.m_list_attributeHeaders.Add(new AttributeHeader("numDirects", "node", "numDirects", "double", "0"));
            hGraph.m_list_attributeHeaders.Add(new AttributeHeader("numCollegues", "node", "numCollegues", "double", "0"));

            sGraph.m_list_attributeHeaders.Add(new AttributeHeader("Title", "node", "Title", "string", "unknown"));
            sGraph.m_list_attributeHeaders.Add(new AttributeHeader("hrank", "node", "hrank", "double", "0"));
            sGraph.m_list_attributeHeaders.Add(new AttributeHeader("numDirects", "node", "numDirects", "double", "0"));
            sGraph.m_list_attributeHeaders.Add(new AttributeHeader("numCollegues", "node", "numCollegues", "double", "0"));
            sGraph.m_list_attributeHeaders.Add(new AttributeHeader("RecentlyModifiedCount", "node", "RecentlyModifiedCount", "double", "0"));

            if(myparams.m_readModifiedTitles)
                sGraph.m_list_attributeHeaders.Add(new AttributeHeader("ModifiedTitles", "node", "ModifiedTitles", "string", "unknown"));
            if (myparams.m_readTrendingTitles)
                sGraph.m_list_attributeHeaders.Add(new AttributeHeader("TrendingTitles", "node", "TrendingTitles", "string", "unknown"));


            ////save hGraph to xml
            hGraph.WriteGraphToXML(myparams.m_hGraphFileName);

            sGraph = await BuildSocial(sender, e, sGraph, rootNode, false, myparams);
            //update Titles for hGraph
            foreach (MyNode n in hGraph.m_list_nodes)
            {
                MyNode n1 = sGraph.FindOrAddNewNode(n, false);
                if(n1!=null)
                {
                    n.UpdateOneAttribute(n1, "Title");
                }

            }
            sGraph = await AddRecentlyModifiedCount(sender, e, sGraph,myparams);
            if(myparams.m_readTrendingTitles)
                sGraph = await AddTrending(sender, e, sGraph, myparams);
            //save sGraph to xml
            sGraph.WriteGraphToXML(myparams.m_sGraphFileName);
            MessageBox.Show("Done.");
        }

        private async Task<DataTable> GetTable(object sender, EventArgs e, MyNode node, int actionID, int maxLines)
        {
            
            DataTable table = null;

            string query = string.Format(spo_query_flex, node.m_id, ActionNNNN(null, actionID),maxLines);//Ariel's workers
           // table = null;
            int numRows = 0;
            try
            {
                table = await TableFromQuery(query);
                numRows = table.Rows.Count;
            }
            catch
            {
                table = null;
            }

            return table;
        }


        //private async Task<MyGraph> GetOneActorGraph(object sender, EventArgs e, MyNode node, MyGraph graph)
        //{


        //}


        private async Task<MyGraph> RecFillNodes(object sender, EventArgs e, MyNode node, MyGraph graph,int curLevel,int maxLevel)
        {
            DataTable table = await GetTable(sender, e, node,1014, 100);
            if (table == null)
                return graph;

            int rcount = table.Rows.Count;
           
            if (rcount > 0)
            {
                Show(table);
                for (int r= 0; r < rcount; r++)
                {
                    string tempID = table.Rows[r].ItemArray[1].ToString();
                    MyNode toNode = graph.FindOrAddNode(tempID,true);
                    //TODO: check if such edge already exists
                    MyEdge newEdge=new MyEdge(node,toNode);
                    newEdge.m_weight = Convert.ToDouble(table.Rows[r].ItemArray[0].ToString()); //correct weight 
                    newEdge.m_from.m_list_edges_as_source.Add(newEdge);
                    newEdge.m_to.m_list_edges_as_target.Add(newEdge);
                    graph.m_list_edges.Add(newEdge);

                    if(toNode.m_myflag==0)//first time
                    {
                        string tit = table.Rows[r].ItemArray[3].ToString();
                        toNode.m_list_attributes.Add(new Attribute("Title", tit));
                        toNode.m_myflag = 1;
                    }
                }
                //TODO: option to restrict tree height
                if (curLevel + 1 < maxLevel)
                {
                    foreach (MyEdge aEdge in node.m_list_edges_as_source)
                    {
                        MyNode nodeTo = aEdge.m_to;
                        if (nodeTo.m_myflag == 1)
                        {
                            nodeTo.m_myflag = 2;
                            graph = await RecFillNodes(sender, e, nodeTo, graph, curLevel + 1, maxLevel);
                        }
                    }
                }
            }
            return graph;
        }

        private async Task<MyGraph>  AddRecentlyModifiedCount(object sender, EventArgs e, MyGraph graph, MyParams myparams)
        {
            foreach (MyNode node in graph.m_list_nodes)
            {
                int modifiedCount = 0;
                string titlesModified = "";
                DataTable table = await GetTable(sender, e, node, 1003, myparams.m_maxRowsModified);
                if (table == null)
                {
                    modifiedCount=0;
                }
                else
                {
                    int r = table.Rows.Count;
                    Show(table);
                    for(int ri=0;ri<r;ri++)
                    {
                        double w = Convert.ToDouble(table.Rows[ri].ItemArray[0].ToString());
                        if (w >= myparams.m_minRankMDocument)
                        {
                            modifiedCount = modifiedCount + 1;
                            if (myparams.m_readModifiedTitles)
                                titlesModified = titlesModified + " ; " + table.Rows[ri].ItemArray[3].ToString();
                        }
                    }
                }

                node.m_list_attributes.Add(new Attribute("RecentlyModifiedCount", Convert.ToString(modifiedCount)));
                if (myparams.m_readModifiedTitles)
                    node.m_list_attributes.Add(new Attribute("ModifiedTitles", titlesModified));

            }

            return graph;
        }

        private async Task<MyGraph> AddTrending(object sender, EventArgs e, MyGraph graph, MyParams myparams)
        {
            foreach (MyNode node in graph.m_list_nodes)
            {
              
                string titlesTrending = "";
                DataTable table = await GetTable(sender, e, node, 1020, myparams.m_maxRowsTrending);
                if (table == null)
                {
                   //
                }
                else
                {
                    int r = table.Rows.Count;
                    Show(table);
                    for (int ri = 0; ri < r; ri++)
                    {
                        double w = Convert.ToDouble(table.Rows[ri].ItemArray[0].ToString());
                        if (w >= myparams.m_minRankTrending)
                        {
                   
                                titlesTrending = titlesTrending + " ; " + table.Rows[ri].ItemArray[3].ToString();
                        }
                    }
                }

               
                    node.m_list_attributes.Add(new Attribute("TrendingTitles", titlesTrending));

            }

            return graph;
        }


        private async Task<MyGraph> BuildSocial(object sender, EventArgs e, MyGraph graph,  MyNode rootNode,bool discoverNodes,MyParams myparams)
        {
            if(discoverNodes==false)// use only existing nodes
            {
                foreach (MyNode node in graph.m_list_nodes)
                {
                    DataTable table = await GetTable(sender, e, node, 1033, myparams.m_maxRowsWorkingWith);
                    if(table==null)
                    {
                        continue;
                    }
                    int r = table.Rows.Count;
                    Show(table);
                    
                    for(int ri=0;ri<r;ri++)
                    {
                        // get ObjectID, Rank, Title
                        string objectID = table.Rows[ri].ItemArray[2].ToString();
                        string tit = table.Rows[ri].ItemArray[3].ToString();
                        double w=Convert.ToDouble(table.Rows[ri].ItemArray[0].ToString());
                        // ask if node(ObjectID) is in graph 
                        MyNode n = graph.FindNode(objectID);
                        if (n != null)
                        {
                         //add edge
                            graph.AddSocialEdge(node, n, w);

                            Attribute aa = AttributesList.FindAttribute("Title", n.m_list_attributes);
                         //if title is unknown update title
                            
                            if(aa!=null && aa.m_data=="unknown")
                            {
                                
                                aa.m_data = tit;
                            }
                            else if(aa==null)
                            {
                                n.m_list_attributes.Add(new Attribute("Title", tit));
                            }

                        }
                        else if(myparams.m_useOutNode==MyParams.TypeUseOutNode.one)
                        {
                            graph.AddSocialEdge(node,graph.m_specialNode1,w);
                        }

                    }
                }

            }
            else
            {
                //error: not implemented
            }

            return graph;
        }
        private string Action1033(string noUse)
        {
            return "1033";
        }
        static public string ActionNNNN(string noUse, int act)
        {
            return string.Format("{0}", act);
        }

        private DataTable MergeTables(List<DataTable> tables)
        {
            DataTable all = new DataTable();
            foreach (DataTable t in tables)
            {
                all.Merge(t);
            }
            return all;
        }

        private delegate string ValueTransform (string value);

        private string GetObjectId(string edges)
        {
            if (edges == null)
            {
                return string.Empty;
            }

            int objIndex = edges.IndexOf("ObjectId");
            if (objIndex <= 0)
            {
                return edges;
            }

            string[] values = edges.Split(new char[] {',', ':'});
            for (int i = 0; i < values.Count() - 1; ++i)
            {
                if (values[i].Contains("ObjectId"))
                {
                    return values[i + 1];
                }
            }
            
            return edges;
        }


        private async Task<List<DataTable>> QueryForEachRow(DataTable table, string queryFormat, string[] keys, ValueTransform[] transforms)
        {
            List<DataTable> tables = new List<DataTable>();

            foreach (DataRow row in table.Rows)
            {
                string query = queryFormat;

                if (keys != null && keys.Count() > 0)
                {
                    string[] values = new string[keys.Count()];
                    
                    int i = 0;
                    bool foundAllValues = true;
                    foreach (string key in keys)
                    {
                        if (keys[i] == null && transforms[i] != null)
                        {
                            values[i] = transforms[i](null);
                        }
                        else
                        {
                            if (!row.Table.Columns.Contains(key))
                            {
                                foundAllValues = false;
                                break;
                            }

                            string value = (row[key] != null) ? row[key].ToString() : string.Empty;
                            if (transforms != null && transforms[i] != null)
                            {
                                value = transforms[i](value);
                            }

                            values[i] = value;
                        }
                        
                        i++;
                    }

                    if (foundAllValues)
                    {
                        query = string.Format(queryFormat, values);
                    }
                }

                try
                {
                    Console.WriteLine(query);
                    tables.Add(await TableFromQuery(query));
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }

            return tables;
        }

        private async  Task<DataTable> TableFromQuery(string query)
        {
            DataTable table = new DataTable();

            var stream = await GetStream(query);
            if (stream != null)
            {

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(stream);
                XmlNode node = GetTableNode(xmlDoc);


                foreach (XmlNode row in node.ChildNodes)
                {
                    if (!row.Name.Equals(xml_element))
                    {
                        continue;
                    }

                    AddRow(table, row);
                }
            }

            return table;
        }

        private void Show(DataTable table)
        {
            this.dataGridView1.DataSource = table;
        }

        private void AddRow(DataTable table, XmlNode row)
        {
            var cells = GetChildNode(row.ChildNodes, xml_Cells);
            if (cells == null)
                return;

            foreach (XmlNode node in cells.ChildNodes)
            {
                if (!node.Name.Equals(xml_element))
                {
                    continue;
                }

                var key = GetChildNode(node.ChildNodes, xml_Key);

                if (key == null)
                {
                    continue;
                }
                if (string.IsNullOrEmpty(key.InnerText))
                {
                    continue;
                }

                if (!table.Columns.Contains(key.InnerText))
                {
                    table.Columns.Add(key.InnerText);
                }
            }

            var dataRow = table.NewRow();

            foreach (XmlNode node in cells.ChildNodes)
            {
                if (!node.Name.Equals(xml_element))
                {
                    continue;
                }

                var key = GetChildNode(node.ChildNodes, xml_Key);
                if (key == null)
                {
                    continue;
                }

                if (string.IsNullOrEmpty(key.InnerText))
                {
                    continue;
                }

                var value = GetChildNode(node.ChildNodes, xml_Value);
                string valueText = string.Empty;

                if (value != null)
                {
                    valueText = value.InnerText ?? string.Empty;
                }

                dataRow[key.InnerText] = valueText;
            }

            table.Rows.Add(dataRow);
        }

        private XmlNode GetTableNode(XmlDocument xmlDoc)
        {
            XmlNode node = GetChildNode(xmlDoc.ChildNodes, xml_query);
            if (node == null) return null;

            node = GetChildNode(node.ChildNodes, xml_PrimaryQueryResult);
            if (node == null) return null;

            node = GetChildNode(node.ChildNodes, xml_relevantResults);
            if (node == null) return null;

            node = GetChildNode(node.ChildNodes, xml_table);
            if (node == null) return null;

            node = GetChildNode(node.ChildNodes, xml_Rows);
            if (node == null) return null;

            return node;
        }

        private XmlNode GetChildNode(XmlNodeList xmlNodeList, string xml_query)
        {
            foreach(XmlNode node in xmlNodeList)
            {
                if (node.Name.Equals(xml_query))
                {
                    return node;
                }
            }

            return null;
        }

        private void MyClick(object sender, EventArgs e)
        {
            MyGraph g = new MyGraph();
            g.m_gtype = MyGraph.GraphType.regular;
            g.m_id = "1";
            g.m_is_directed = false;

            g.m_list_attributeHeaders.Add(new AttributeHeader("graph_attr1", "graph", "graph_attr1name", "string", "DEmpty"));
            g.m_list_attributeHeaders.Add(new AttributeHeader("graph_attr2", "graph", "graph_attr2name", "string", "DHo-Ho"));

            g.m_list_attributeHeaders.Add(new AttributeHeader("node_attr1", "node", "node_attr1name", "string", "0"));
            g.m_list_attributeHeaders.Add(new AttributeHeader("node_attr2", "node", "node_attr2name", "string", "0"));

            g.m_list_attributeHeaders.Add(new AttributeHeader("stam", "edge", "stam", "double", "0"));



            g.m_list_attributes.Add(new Attribute("graph_attr1", "haha user"));
            g.m_list_attributes.Add(new Attribute("graph_attr2", "hehe user "));

            MyNode n1 = new MyNode("10");
            MyNode n2 = new MyNode("20");
            MyNode n3 = new MyNode("30");

            n1.m_list_attributes.Add(new Attribute("node_attr1", "1"));
            n1.m_list_attributes.Add(new Attribute("node_attr2", "2"));

            n2.m_list_attributes.Add(new Attribute("node_attr1", "1"));
            n2.m_list_attributes.Add(new Attribute("node_attr2", "2"));
            n3.m_list_attributes.Add(new Attribute("node_attr1", "31"));
            n3.m_list_attributes.Add(new Attribute("node_attr2", "32"));
            g.AddNewNode(n1);
            g.AddNewNode(n2);
            g.AddNewNode(n3);
            g.AddNewEdge(n1, n2, 1);
            g.AddNewEdge(n1, n3, 1);

            g.WriteGraphToXML("c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\tryG.xml");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
