﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficeGraphQuery1
{
    public class Attribute
    {
        public string m_name;
        public string m_data;
       

        public Attribute()
        {
            m_name = null;
            m_data = null;
           
        }
        public Attribute(string a, string b)
        {
            m_name = a;
            m_data = b;
           
        }
      
    }

    public class AttributesList
    {
        List<Attribute> m_alist;
        public AttributesList()
        {
            m_alist = new List<Attribute>();
        }
        public Attribute FindAttribute(string name)
        {
            Attribute a = null;
            foreach(Attribute a1 in m_alist)
            {
                if (a.m_name == name)
                {
                    a = a1;
                    break;
                }
            }

            return a;
        }
        static public Attribute FindAttribute(string name, List<Attribute>  alist)
        {
            Attribute a = null;
            foreach (Attribute a1 in alist)
            {
                if (a1.m_name == name)
                {
                    a = a1;
                    break;
                }
            }

            return a;
        }

        static public AttributeHeader FindAttribute(string name, List<AttributeHeader> ahlist)
        {
            AttributeHeader ah = null;
            foreach (AttributeHeader ah1 in ahlist)
            {
                if (ah1.m_name == name)
                {
                    ah = ah1;
                    break;
                }
            }

            return ah;
        }


    }
}
