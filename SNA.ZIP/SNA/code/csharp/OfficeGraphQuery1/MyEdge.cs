﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace OfficeGraphQuery1
{
    public enum EdgeType { regular, special1, special2 };

    public class MyEdge
    {
      
        public MyNode m_from;
        public MyNode m_to;
        public List<Attribute> m_list_attributes;
        public double m_weight;
        public EdgeType m_etype;
        public MyEdge(MyNode from, MyNode to)
        {
            m_from = from;
            m_to = to;
            m_list_attributes = new List<Attribute>();
            m_weight = 1;
            m_etype = EdgeType.regular;
        }
        public MyEdge(MyEdge e2copy)
        {
            m_from = e2copy.m_from;
            m_to = e2copy.m_to;
    
            m_weight = e2copy.m_weight;
            m_etype = e2copy.m_etype;
            m_list_attributes = new List<Attribute>(e2copy.m_list_attributes);
        }
    }
   

}
