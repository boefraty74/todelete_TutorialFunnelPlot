﻿//----------------------------------------------------------------------------------------------
//    Copyright 2014 Microsoft Corporation
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
//----------------------------------------------------------------------------------------------

using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OfficeGraphQuery1
{
    public partial class AuthenticationHelper
    {
        public static readonly string DiscoveryServiceResourceId = "https://api.office.com/discovery/";

        //const string AuthorityFormat = "https://login.windows.net/{0}/";      

        static readonly string RedirectUri = ConfigurationSettings.AppSettings["ida:RedirectUri"].ToString();
        static readonly string ClientId = ConfigurationSettings.AppSettings["ida:ClientID"].ToString();
        static readonly string AADInstance = ConfigurationSettings.AppSettings["ida:AADInstance"].ToString();

        static readonly string AuthorityFormat = "https://login.microsoftonline.com/{0}/";
        //static readonly string AuthorityFormat = "https://login.microsoftonline.com/72f988bf-86f1-41af-91ab-2d7cd011db47/";

        static string _authority = String.Empty;

        //static string _lastTenantId = "72f988bf-86f1-41af-91ab-2d7cd011db47";
        static string _lastTenantId = "common";

        const string _lastTenantIdKey = "LastAuthority";

        static AuthenticationContext authContext = null;

        public static string LastTenantId
        {
            get
            {
                return _lastTenantId;
            }

            set
            {
                _lastTenantId = value;
            }
        }   

        public static string Authority
        {
            get
            {
                _authority = String.Format(AuthorityFormat, LastTenantId);

                return _authority;
            }
        }

        public static AuthenticationResult GetAccessToken(string serviceResourceId)
        {
            AuthenticationResult authResult = null;

            if (authContext == null)
            {
                authContext = new AuthenticationContext(Authority);
                authResult = authContext.AcquireToken(serviceResourceId, ClientId, new Uri(RedirectUri));
            }
            else
            {
                authResult = authContext.AcquireTokenSilent(serviceResourceId, ClientId);
            }

            LastTenantId = authResult.TenantId;

            return authResult;
        }

        public static async Task<AuthenticationResult> GetAccessTokenAsync(string serviceResourceId)
        {
            if (authContext == null)
            {
                authContext = new AuthenticationContext(Authority);
                return authContext.AcquireToken(serviceResourceId, ClientId, new Uri(RedirectUri));
            }
            else
            {
                return await authContext.AcquireTokenSilentAsync(serviceResourceId, ClientId);
            }
        }

        private static string _discoverySvcEndpointUri = "https://api.office.com/discovery/v1.0/me/";
        public static Uri DiscoveryServiceEndpointUri
        {
            get
            {
                return new Uri(_discoverySvcEndpointUri);
            }
        }
    }
}