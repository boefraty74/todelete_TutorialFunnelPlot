#my_graph_plot_advanced.R
#label.cex - size of label (1 default)
# label.color - default is black
# edge.width - default is 1

source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\sparsify_labels_by_layout.R",sep=""))



my_graph_get_show_node_labels<-function(gr,nodeLabel,nodeLabelShowIndicator,parinfo,smart_sparsify_labels,mylayout)
{
  # if graph is overloaded will present only few labels 
  # nodeLabelShowIndicator if NULL => do nothing 
  # if 0 => do not show anything
  # if 1 => show integer indexes
  # nodeLabelShowIndicator => show best and worst automatically 
  if(smart_sparsify_labels)
  {
    mfactor<-0.15/min(parinfo$pin)
    if(is.na(mfactor)||is.null(mfactor))
             mfactor<-1
    gr<-sparsify_labels_by_layout(gr,mylayout,lAttribute=nodeLabelShowIndicator,mfactor=mfactor)
    return(gr)
  }
  
  
  
  numNodes<-length(V(gr))
  
  if(is.null(nodeLabelShowIndicator) || numNodes< 12)
    return(gr);
  
  if(length(nodeLabelShowIndicator)==1 && nodeLabelShowIndicator==0)
  {
    V(gr)$label<-NA
    return(gr)
  }
  if(length(nodeLabelShowIndicator)==1 && nodeLabelShowIndicator==1)
  {
    V(gr)$label<-seq(1,length(V(gr)))
    return(gr)
  }
  seder<-sort(nodeLabelShowIndicator,index.return = T)$ix
  
  keepOnly <- 3 #TEMP
  areaSize<-sqrt(prod(parinfo$din))
  areaPerNodeRoot<-sqrt(areaSize/numNodes)# what is an area per node
  
  temp<-as.numeric(as.character(cut(areaPerNodeRoot,
                                  breaks=c(0,0.3,0.5,Inf),
                                  labels=c(0.25,0.5,1))))
#  print(temp)

  keepOnly<-round(temp*numNodes/2)
  
 
  if(keepOnly+1<numNodes-keepOnly)
    V(gr)$label[seder[seq(keepOnly+1,numNodes-keepOnly)]]<-NA
 
    
 
    
  return(gr)
  
}

my_graph_get_edge_width<-function(gr,edgeWidthAttrib,parinfo)
{
  DEW<-1
  if(!is.null(edgeWidthAttrib) && min(edgeWidthAttrib)==max(edgeWidthAttrib))
  {
    DEW=edgeWidthAttrib[1]
    edgeWidthAttrib=NULL
  }
  
  numEdges<-length(E(gr))
  numNodes<-length(V(gr))
  
  areaSize<-sqrt(prod(parinfo$din))
  
  areaPerNodeRoot<-sqrt(areaSize/numNodes)# what is an area per node
  
  temp<-as.numeric(as.character(cut(areaSize,
                                    breaks=c(0,0.1,0.5,1,2,3,4,5,7,10,20,50,Inf),
                                    labels=c(0.1,0.5,2,3,6,7,8,10,11,12,15,20))))
  #print(temp)
 # DEW<-DEW*temp
  DEW<-DEW
  
  if(!is.null(edgeWidthAttrib))
  {
    msizes<-seq(0.5,5,length.out = 102)*DEW
    mi<-min(edgeWidthAttrib)
    ma<-max(edgeWidthAttrib)
    edgeWidthAttrib<-(edgeWidthAttrib-mi)/(ma-mi)
    #assign due to attribute 
    for (i in c(1:length(E(gr))))
    {
      temp<-round((edgeWidthAttrib[i])*100)
      E(gr)[i]$width <- msizes[temp+1]
    }
  }
  else
  {
    E(gr)[]$width <- DEW
  }
  
  return(gr)

}

my_graph_get_node_rad<-function(gr,nodeRadAttrib,parinfo)
{
  DNR<-0.85
  
  if(!is.null(nodeRadAttrib) && min(nodeRadAttrib)==max(nodeRadAttrib))
  {
    DNR=nodeRadAttrib[1]
    nodeRadAttrib=NULL
  }
  
  numNodes<-length(V(gr))
  areaSize<-sqrt(prod(parinfo$din))
  
  areaPerNodeRoot<-sqrt(areaSize/numNodes)# what is an area per node
  
  temp<-as.numeric(as.character(cut(areaSize,
                                    breaks=c(0,0.1,0.5,1,2,3,4,5,7,10,20,50,Inf),
                                    labels=c(0.1,0.5,2,3,6,7,8,10,11,12,15,20))))
  #print(temp)
  DNR<-DNR*temp
  
  
  if(!is.null(nodeRadAttrib))
  {
    msizes<-seq(0.3,1.4,length.out = 102)*DNR
    mi<-min(nodeRadAttrib)
    ma<-max(nodeRadAttrib)
    nodeRadAttrib<-(nodeRadAttrib-mi)/(ma-mi)
    #assign due to attribute 
    for (i in c(1:length(V(gr))))
    {
      temp<-round((nodeRadAttrib[i])*100)
      V(gr)[i]$size <- msizes[temp+1]
    }
  }
  else
  {
      V(gr)[]$size <- DNR
  }
  
  return(gr)
}
###########
my_graph_get_node_color<-function(gr,nodeColAttrib,nodeColor,parinfo)
{
  DEFAULT_NODE_COLOR<-rgb(1,1,0.0,0.7)
  mcolors<-array(dim=100)
  j<-1
  for (i in seq(0.2,0.95,length.out = 102))
  {
    mcolors[j]<-rgb(0.1,i,0,0.6)
    j<-j+1
  }
  #(nodeColAttrib)
  if(!is.null(nodeColAttrib) && min(nodeColAttrib)!=max((nodeColAttrib)))
  {
    mi<-min(nodeColAttrib)
    ma<-max(nodeColAttrib)
    nodeColAttrib<-(nodeColAttrib-mi)/(ma-mi)
    #assign due to attribute 
    for (i in c(1:length(V(gr))))
    {
      temp<-round((nodeColAttrib[i])*100)
      V(gr)[i]$color <- mcolors[temp+1]
     
    }
    
  }
  else
  {
    if(is.null(nodeColor)) 
      V(gr)[]$color <- DEFAULT_NODE_COLOR
    else
      V(gr)$color<-nodeColor
  } 
  return(gr)
}

##########
my_graph_get_node_label<-function(gr,nodeLabel,parinfo)
{
 # nodeLabel=NA #TEMP
  DEFAULT_NODE_LABEL<-NA
  DEFAULT_NODE_LABEL_FONT_COLOR<-rgb(0.6, 0.05, .0, .8)
  
  if(!is.null(nodeLabel))
    V(gr)$label<-nodeLabel
  
  V(gr)$label.color <- DEFAULT_NODE_LABEL_FONT_COLOR
  
  return(gr)
}

##################
my_graph_get_node_label_size<-function(gr,nodeLabelSizeAttrib,parinfo)
{
  DEFAULT_NODE_LABEL_SIZE <- 0.1

  DNLS <- DEFAULT_NODE_LABEL_SIZE
  
  if(!is.null(nodeLabelSizeAttrib) && min(nodeLabelSizeAttrib)==max(nodeLabelSizeAttrib))
  {
    DNLS=nodeLabelSizeAttrib[1]
    nodeLabelSizeAttrib=NULL
  }
  
  numNodes<-length(V(gr))
  areaSize<-sqrt(prod(parinfo$din))
  
  areaPerNodeRoot<-sqrt(areaSize/numNodes)# what is an area per node
  
  temp<-as.numeric(as.character(cut(areaSize,
                                    breaks=c(0,0.1,0.5,1,2,3,4,5,7,10,20,50,Inf),
                                    labels=c(2.1,2.2,2.5,4,6,7,8,9,10,12,15,20))))
  
  #print(temp)
  
  DNLS<-DNLS*temp
  
  
  if(!is.null(nodeLabelSizeAttrib))
  {
    msizes<-seq(0.75,1.25,length.out = 102)*DNLS
    mi<-min(nodeLabelSizeAttrib)
    ma<-max(nodeLabelSizeAttrib)
    nodeLabelSizeAttrib<-(nodeLabelSizeAttrib-mi)/(ma-mi)
    #assign due to attribute 
    for (i in c(1:length(V(gr))))
    {
      temp<-round((nodeLabelSizeAttrib[i])*100)
      V(gr)[i]$label.cex <- msizes[temp+1]
    }
  }
  else
  {
    V(gr)[]$label.cex <- DNLS
  }
  
  return(gr)
  
}
################
##################
#  my_graph_plot_advanced 
##################
##################
my_graph_plot_advanced<-function(gr,nodeRadAttrib=NULL,nodeColAttrib=NULL,
                                 nodeLabelShowIndicator=NULL,
                                 nodeLabel=NULL,nodeLabelSizeAttrib=NULL,
                                 nodeGroupIndicator=NULL, nodeColor=NULL,
                                 edgeColorAttrib=NULL,edgeWidthAttrib=NULL,edgeTypeAttrib=NULL,
                                mylayout=layout.auto(gr),
                                stam=NULL,
                                smart_sparsify_labels=FALSE,...)
{
if(is.null(nodeLabelShowIndicator))
    nodeLabelShowIndicator<-nodeRadAttrib #TEMP

if(!is.null(nodeRadAttrib))
  if(length(unique(nodeRadAttrib))==1)
    nodeRadAttrib=NULL;
  
  if(!is.null(nodeColAttrib))
    if(length(unique(nodeColAttrib))==1)
      nodeColAttrib=NULL;
    
    if(!is.null(nodeLabelSizeAttrib))
      if(length(unique(nodeLabelSizeAttrib))==1)
        nodeLabelSizeAttrib=NULL;
      
      if(!is.null(edgeColorAttrib))
        if(length(unique(edgeColorAttrib))==1)
          edgeColorAttrib=NULL;
        
        if(!is.null(edgeWidthAttrib))
          if(length(unique(edgeWidthAttrib))==1)
            edgeWidthAttrib=NULL;
  
  DEFAULT_NODE_SHAPE<-"circle"
  
  DEFAULT_EDGE_WIDTH<-1
  DEFAULT_EDGE_LABEL<-1
  DEFAULT_EDGE_COLOR<-rgb(0.1, 0.1, 0.1, .8)
  
  PARINFO<-par()#PARINFO$din
  PARINFO$side<-sqrt(prod(PARINFO$din))
  
  numNodes<-length(V(gr))
  numEdges<-length(E(gr))
  
  if(is.null(mylayout))
  {
    if(is.directed(gr))
      mylayout <-layout.reingold.tilford(gr,root=1) # good for tree
    else
      #mylayout<-layout_with_kk(gr,kkconst = vcount(gr))# not good for disconnected 
      mylayout<-layout_with_graphopt(gr,mass=30) 
    # mylayout<-layout_nicely(gr)
    #mylayout<-layout.fruchterman.reingold(gr)#
    
  }
  
  # set nodeRad
  gr<-my_graph_get_node_rad(gr,nodeRadAttrib,PARINFO)
  # set nodeColor
  gr<-my_graph_get_node_color(gr,nodeColAttrib,nodeColor,PARINFO)
  
  #TODO: set nodeShape
  #set nodeLabel
  gr<-my_graph_get_node_label(gr,nodeLabel,PARINFO)
 
  
  
  #set nodeLabelSize
  gr<-my_graph_get_node_label_size(gr,nodeLabelSizeAttrib,PARINFO)
  
  
  #set sparse label
  gr<-my_graph_get_show_node_labels(gr,nodeLabel,nodeLabelShowIndicator,PARINFO,smart_sparsify_labels,mylayout)
  
  #set edgeWidth
  gr<-my_graph_get_edge_width(gr,edgeWidthAttrib,PARINFO)
  
  
  
  #TODO: set edgeLabel
  #TODO: set edgeColor
  
  
  
  
  
#  E(gr)$curved=F
  
  V(gr)$frame.color <- NA # no frame on node
 # V(gr)$label<-NA
  
  if(is.directed(gr))
    plot(gr,vertex.color=V(gr)$color,layout=mylayout,asp=0,...)
  else
    plot(gr,vertex.color=V(gr)$color,layout=mylayout,asp=1,...)
  
}