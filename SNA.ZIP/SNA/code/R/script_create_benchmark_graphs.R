library(igraph)

NN<-12
#family
g1<- graph.full(NN)
write_graph(g1,"c:/Users/boefraty/projects/PBI/SNA/data/benchmark_graphs/my_family.xml",format="graphml")

#isolated
g2<- simplify(as.undirected(graph(c(1,1,NN,NN))))
write_graph(g2,"c:/Users/boefraty/projects/PBI/SNA/data/benchmark_graphs/my_isolated.xml",format="graphml")

#anarchy
g3 <- erdos.renyi.game(NN, 5/NN)
write_graph(g1,"c:/Users/boefraty/projects/PBI/SNA/data/benchmark_graphs/my_anarchy.xml",format="graphml")

#mafia
g4<-as.undirected(graph.star(NN))
write_graph(g4,"c:/Users/boefraty/projects/PBI/SNA/data/benchmark_graphs/my_mafia.xml",format="graphml")

