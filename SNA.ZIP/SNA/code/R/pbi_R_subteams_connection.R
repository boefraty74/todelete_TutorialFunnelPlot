source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\CreateSubteamsByHierarchyLevel.R",sep=""))


# dbgf<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\debug.Rda",sep="")
# load(file=dbgf)# for DEBUG

pbi_R_subteams_connection<-function(dataset)
{
  
 
  #find wich one of dataset$V1[1],dataset$V1[2],dataset$V1[3] is sGraph
  snaFile<-as.character(dataset$V1[1])
  if(length(grep("sGraph",as.character(dataset$V1[2])))>0)
    snaFile<-as.character(dataset$V1[2])
  if(length(grep("sGraph",as.character(dataset$V1[3])))>0)
    snaFile<-as.character(dataset$V1[3])
  
  treeFile<-as.character(dataset$V1[1])
  if(length(grep("hGraph",as.character(dataset$V1[2])))>0)
    treeFile<-as.character(dataset$V1[2])
  if(length(grep("hGraph",as.character(dataset$V1[3])))>0)
    treeFile<-as.character(dataset$V1[3])
  
  
  treeGraph<-read.graph(file=treeFile,format="graphml")
  snaGraph<-read.graph(file=snaFile,format="graphml")
  
  
  set.seed(42)
 # par(mar=c(5, 4, 4, 2)/7 + 0.1);
  par(mfcol=c(1,3))
  targetLevel=dataset$Level[1]
  CreateSubteamsByHierarchyLevel(treeGraph=treeGraph,snaGraph = snaGraph,targetLevel = targetLevel)
  
  
}