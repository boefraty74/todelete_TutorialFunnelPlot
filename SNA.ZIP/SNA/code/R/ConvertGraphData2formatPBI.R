#ConvertGraphData2formatPBI
# converts Nodes and Edges tables to formats From, To, Props to be used in PBI 
ConvertGraphData2formatPBI<-function(df4n,df4e)
{
  library(dplyr)

df4n$autoNodeID<-seq(1,nrow(df4n))
df4e$autoEdgeID<-seq(1,nrow(df4e))


df4e_from<-subset(df4e,select=c(autoEdgeID,E_from))
df4e_to<-subset(df4e,select=c(autoEdgeID,E_to))

#map V_id to sequebce 
myIDs<-df4n$autoNodeID
names(myIDs)<-df4n$V_id

df4e_from$autoNodeID<-myIDs[df4e$E_from]
df4e_to$autoNodeID<-myIDs[df4e$E_to]
df4e_prop<-df4e

#add self-edges to each df4e_to,df4e_from
NN<-nrow(df4n)
NE<-nrow(df4e)
for (n in seq(1,NN))
{
  #
  tfrom <- data.frame(autoEdgeID = NE+n, E_from = df4n$V_id[n],autoNodeID=df4n$autoNodeID[n])
  df4e_from <- bind_rows(df4e_from, tfrom)
  
  tto <- data.frame(autoEdgeID = NE+n, E_to = df4n$V_id[n],autoNodeID=df4n$autoNodeID[n])
  df4e_to <- bind_rows(df4e_to, tto)
  
  tprop<-data.frame(weight=0, autoEdgeID=NE+n,E_from = df4n$V_id[n],E_to = df4n$V_id[n])
  df4e_prop <- bind_rows(df4e_prop, tprop)
  
}



listRes<-list(df4n,df4e_from,df4e_to,df4e_prop)
return(listRes)

}