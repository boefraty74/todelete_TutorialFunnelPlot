library(igraph)
library(networkD3)

my_networkD3_plot<-function(igra,attrib_node=NULL,outFileName=NULL)
{
  M<-as_adj(igra)
  adj_matr<-as.data.frame.matrix(M)
  #table_nodes<-data.frame(g.n.vertices)
  ee<-ends(igra,c(1:length(E(igra))))
  #table_edges
  table_edges<-as.data.frame.matrix(ee)
  
  simpleNetwork(table_edges) # funny plot 
  
  if(!is.null(outFileName))
  {
    saveNetwork(net_D3,file=outFileName,selfcontained = TRUE)
  }
  
}