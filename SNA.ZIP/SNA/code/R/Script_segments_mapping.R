#user params 
PLOT_METHOD=3# 1 or 2 or 3

THRESH_ABS_CUST4SEG=0 # suppress segment if its count is <THRESH_ABS_CUST4SEG 
THRESH_REL_CUST4SEG=0 # suppress segment if its count/total_count is <THRESH_REL_CUST4SEG
THRESH_TOP_CUST4SEG=0 # suppress segment if it isnot in top K segments (by count of customers)

THRESH_DIRECTED_EDGE=0.0
THRESH_UNDIRECTED_WEIGHTED_EDGE=0.01#NOT IN USE

#TODO: Think about filter out customers with few transactions(?) 

GRAPH_DIRECTED=T  # directed graph
NORM_WEIGHT_IN_EDGE=TRUE # normalize weight in edge to [0,1]
SHOW_ISOLATED=F # if FALSE don't show isolated nodes(segments)

SHOW_EDGE_WEIGHT=F
SHOW_SEG_COUNT=F


SHOW_CLIQUES=FALSE # NOT YET IMPLEMENTED
SIZE_CLIQUE=c(2,3,4)



#
set.seed(42)
library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\my_graph_plot_advanced.R",sep=""))

specify_decimal <- function(x, k)
{
  if(is.numeric(x))
    format(round(x, k), nsmall=k)
  else
    return(x)
}

indexSubsets<-function(vecSizes,k)
{
  resList<-list()
  i=1
  for (nn in vecSizes)
  {
    resList[[nn]]=combn(1:nn, k, simplify = FALSE)
    i=i+1
  }
  return(resList)
  
}

myPlotWithSubPlots<-function(gr,nodeRadAttrib=NULL,nodeColAttrib=NULL,
                             edgeWidthAttrib=NULL,nodeLabelSizeAttrib=NULL,smart_sparsify_labels=T,...)
{
  allClusters<-clusters(gr, mode="weak")
  no<-allClusters$no
  co<-ceiling(sqrt(no))# num columns
  ro<-ceiling(no/co)#num rows
  par(mfrow=c(co,ro),mar=c(0,0,0,0)+0.1,omi=c(0,0,0,0)+0.1)
  for (c in (1:no))
  {
    iii<-(allClusters$membership!=c)
    jjj<-(allClusters$membership==c)
    g<-delete.vertices(gr,iii)
    plot(g,...)
#      my_graph_plot_advanced(g,nodeRadAttrib=nodeRadAttrib[jjj],nodeColAttrib=nodeColAttrib[jjj],
#                             edgeWidthAttrib=edgeWidthAttrib[jjj],nodeLabelSizeAttrib=nodeLabelSizeAttrib[jjj],
#                             ...)
  }
  
}



#TEMP
load(paste(Sys.getenv("SNA4PBI_PATH"),"data\\debug.Rda",sep=""))
if(exists("dataset"))
{
  seg2cust=dataset
}else{
  seg2cust=data.frame(custID=c(1,2,3,1,1,2,3,4),
                      seg1=c(0,1,0,1,0,1,1,0),
                      seg2=c(1,0,1,1,1,1,1,0),
                      seg3=c(0,1,0,0,0,0,1,0),
                      seg4=c(0,0,0,0,0,0,0,1),
                      seg5=c(1,0,0,0,1,0,0,0))
}

nr<-nrow(seg2cust)

#seg2cust<-seg2cust[1:min(1000,nr),]

NUM_SEG<-ncol(seg2cust)-1
NUM_CUST<-length(unique(seg2cust[,1]))

sumBySegment<-as.vector(apply(seg2cust[,2:(NUM_SEG+1)],2,sum))

#clean segments with insufficient counts
sel_by_abs=rep(TRUE,NUM_SEG)
sel_by_rel=rep(TRUE,NUM_SEG)
sel_by_top=rep(TRUE,NUM_SEG)
if(is.numeric(THRESH_ABS_CUST4SEG) && THRESH_ABS_CUST4SEG>0)
{
  sel_by_abs=(sumBySegment>=THRESH_ABS_CUST4SEG);
}
if(is.numeric(THRESH_REL_CUST4SEG) && THRESH_REL_CUST4SEG>0)
{
  sel_by_rel=(sumBySegment/sum(sumBySegment)>=THRESH_REL_CUST4SEG);
}
if(is.numeric(THRESH_TOP_CUST4SEG) && THRESH_TOP_CUST4SEG>0)
{
  temp=sort(sumBySegment,decreasing = T,index.return=TRUE)
  sel_by_top[]=FALSE
  sel_by_top[temp$ix[1:THRESH_TOP_CUST4SEG]]=TRUE
}
sel=as.logical(sel_by_abs*sel_by_rel*sel_by_top);
sumBySegment=sumBySegment[sel]
sel=c(TRUE,sel)
seg2cust<-as.data.frame(seg2cust[,sel])
NUM_SEG<-ncol(seg2cust)-1
names(seg2cust)[1]="custID"


#aaa<-aggregate(seg2cust,by=list("custID"),sum)
aggdata <-aggregate(seg2cust, by=list(seg2cust$custID), FUN=sum, na.rm=TRUE,simplify=TRUE)

aggdata[,2]<-aggregate(seg2cust[,1], by=list(seg2cust$custID), FUN = length)[2]
names(aggdata)[2]<-"num_customers"



aggMatr<-as.matrix(aggdata[,seq(from=3,length.out=NUM_SEG)])
#only 1's in aggMatr
A=(aggMatr>0)
aggMatr[A]=1;
numsegs2cust=apply(aggMatr,1,sum)
aggMatrClean=aggMatr[numsegs2cust>1,]
setsSizes=(numsegs2cust[numsegs2cust>1])
uniqueSetsSizes=unique(numsegs2cust[numsegs2cust>1])
allSubsetIndexes<-indexSubsets(uniqueSetsSizes,2)

indSeg<-seq(1,NUM_SEG)

adjMatr<-matrix(0,nrow = NUM_SEG, ncol = NUM_SEG)
adjMatr_dir<-adjMatr

for(cu in seq(from=1,length.out=length(setsSizes)))
{
  #get non zero indexes only into vector
  temp<-aggMatrClean[cu,]
  temp<-indSeg[temp>0]
  
  #get subsetIndexes
  ssi<-allSubsetIndexes[[length(temp)]]
  
  #increment entries of matrix
  for (ind in (1:length(ssi)))
  {
    s1<-temp[ssi[[ind]][1]]
    s2<-temp[ssi[[ind]][2]]
    adjMatr[s1,s2]<-adjMatr[s1,s2]+1
  }
  
}




for (s1 in (1:NUM_SEG))
  for (s2 in (seq(to=NUM_SEG,length.out=max(NUM_SEG-s1,0))))
  { 
 #   for (c in (1:NUM_CUST))
#      adjMatr[s1,s2]<-adjMatr[s1,s2]+(aggMatr[c,s1]>0)*(aggMatr[c,s2]>0)
    #compute normalized weights for directed 
    adjMatr_dir[s1,s2]<-adjMatr[s1,s2]/(sumBySegment[s1]+0.001)
    adjMatr_dir[s2,s1]<-adjMatr[s1,s2]/(sumBySegment[s2]+0.001)
    if(NORM_WEIGHT_IN_EDGE &&!GRAPH_DIRECTED && adjMatr[s1,s2])
      adjMatr[s1,s2]<-adjMatr[s1,s2]/(sumBySegment[s1]+sumBySegment[s2]-adjMatr[s1,s2])
    
  }

adjMatr_dir[adjMatr_dir<THRESH_DIRECTED_EDGE]=0



#TODO: if requested compute and show cliques
#TODO: advanced visalization 




#adjMatr contains count of shared customers 
#create graph 
#  with segments as nodes
#  sumBySegment on nodes
# adjMatr[s1,s2] on edges 

#create directed/undirected version
gr_undir<- graph.empty()
gr_dir<- graph.empty()

if(!GRAPH_DIRECTED)
{
  gr_undir<-graph.adjacency(adjMatr, mode=c("undirected"), weighted=TRUE, diag=TRUE)
  gr<-gr_undir
  mylayout=NULL
}else{
  gr_dir<-graph.adjacency(adjMatr_dir, mode=c("directed"), weighted=TRUE, diag=TRUE)
  gr<-gr_dir
  mylayout=layout_with_fr(gr)
}

E(gr)$width=7*(E(gr)$weight-min(E(gr)$weight)+0.01)/(max(E(gr)$weight)-min(E(gr)$weight)+0.01)
V(gr)$size=20*(0.5+(sumBySegment-min(sumBySegment)+0.01)/(max(sumBySegment)-min(sumBySegment)+0.01))
V(gr)$label=names(seg2cust)[2:(NUM_SEG+1)]
if(SHOW_SEG_COUNT)
  V(gr)$label=paste(V(gr)$label,'\n',sumBySegment)




label=specify_decimal(E(gr)$weight,2)

if(!is.null(label)&& SHOW_EDGE_WEIGHT)
{
  E(gr)$label=label
}

# remove isolated if requested 
if(!SHOW_ISOLATED)
  gr<-delete.vertices(gr,V(gr)[degree(gr)==0])

if(length(V(gr))<2)
{
  par(mfrow=c(1,1))
  plot.new()
  title(sub="Empty plot: Network has less than 2 vertices")
}else if(PLOT_METHOD==1){
  par(mfrow=c(1,1),mar=c(0,0,0,0))
  plot(gr,edge.curved=GRAPH_DIRECTED,edge.arrow.size=2.0,edge.label.cex=0.75,vertex.label.cex=0.75)
}else if(PLOT_METHOD==2){
  par(mfrow=c(1,1),mar=c(0,0,0,0))
  my_graph_plot_advanced(gr,nodeRadAttrib=V(gr)$size,nodeColAttrib=V(gr)$size,
                         edgeWidthAttrib=E(gr)$width,nodeLabelSizeAttrib=V(gr)$size,
                         edge.curved=GRAPH_DIRECTED,smart_sparsify_labels = T,edge.arrow.size=1.0)
}else if(PLOT_METHOD==3){
  myPlotWithSubPlots(gr,nodeRadAttrib=V(gr)$size,nodeColAttrib=V(gr)$size,
                         edgeWidthAttrib=E(gr)$width,nodeLabelSizeAttrib=V(gr)$size,
                         edge.curved=GRAPH_DIRECTED,smart_sparsify_labels = T,edge.arrow.size=1.0)
}

#bipartite 
# lbp=layout_as_bipartite(gr,bipartite_mapping(gr)$type,maxiter=1000,hgap=1,vgap=1)
# lbp1=lbp[,c(2,1)]
# plot(gr,layout=lbp1)




