source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))

#save(dataset,file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")# for DEBUG
pbi_R_draw_graph_me_my_cliques<-function(dataset)
{
  source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
  snaFile<-as.character(dataset$V1[1])
  if(length(grep("sGraph",as.character(dataset$V1[2])))>0)
    snaFile<-as.character(dataset$V1[2])
  if(length(grep("sGraph",as.character(dataset$V1[3])))>0)
    snaFile<-as.character(dataset$V1[3])
  
  
  myPropFile<-as.character(dataset$V1[1])
  if(length(grep(".csv",as.character(dataset$V1[2])))>0)
    myPropFile<-as.character(dataset$V1[2])
  if(length(grep(".csv",as.character(dataset$V1[3])))>0)
    myPropFile<-as.character(dataset$V1[3])
  
  t<-read.csv(myPropFile)
    myID<-as.character(t[1])
  
  
  
  g_sna_with_outsider<-read_graph(file=snaFile,format="graphml")
  
  Lp1<-length(V(g_sna_with_outsider))
  g_sna<-delete.vertices(g_sna_with_outsider,V(g_sna_with_outsider)[Lp1])
    
  #largest cliques
  #cliques
  ###
  cl <- maximal.cliques(g_sna)
  LCL<-length(cl)
  MINC=6
  
  ml<-c(1:LCL)
  for (i in c(1:LCL))
  {
    ml[i]<-length(cl[[i]])*length(intersect(cl[[i]]$id,myID))
  }
  cl1<-cl[ml==max(ml)]
  
  if(max(ml)==0){
    cl1=NULL
    } else {
  colbar <- rainbow(length(cl1) + 1)
  for (i in 1:length(cl1)) 
    V(g_sna)[cl1[[i]]]$color <- colbar[i+1]
    }
  par(mar=c(5, 4, 4, 2)/5 + 0.1);
  set.seed(42)
  l_sna<-layout.auto(g_sna)
  V(g_sna)$label<- one_word_labels(V(g_sna)$Title)
  plot(g_sna, mark.groups=cl1,vertex.size=0.3, vertex.label.cex=0.5, edge.color=rgb(.4,.4,0,.3),layout=l_sna)
  
  title(main=paste("My largest ",length(cl1)*(max(ml)>0), "Clique(s) of size", max(ml)))
  
  
}