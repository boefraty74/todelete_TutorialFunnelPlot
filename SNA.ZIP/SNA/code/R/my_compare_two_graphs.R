library(igraph)
library(stats)

norm_ks<-function(vec1,vec2)
{
  res<-0
  sd1<-sd(vec1)
  sd2<-sd(vec2)
  if(sd1*sd2<0.001)#almost zero
  {
    if(sd1<0.01 && sd2<0.01)
      return(0)
    else
      return(1)
  }
  m1<-mean(vec1)
  m2<-mean(vec2)
  vec1<-(vec1-m1)/sd1
  vec2<-(vec2-m2)/sd2
  temp<-ks.test(vec1,vec2)
  res<-(temp$statistic)
  return(res)
  
}






# benchmarking on Graph 
# accepts two graphs 
# returns distance metrix
my_compare_two_graphs<-function(gr1,gr2,params=NULL)
{
  
  dd<-rep(NA,10)
  ww<-rep(NA,10)
  
  # get rank distribution 
  V(gr1)$deg<-degree(gr1,mode="all")
  V(gr2)$deg<-degree(gr2,mode="all")
  dd[1]<-norm_ks(V(gr1)$deg,V(gr2)$deg) #compare degree distribution
  ww[1]<-1
  
  
 #compare percentage of isolated nodes
  ratio_Iso1<-sum(V(gr1)$deg==0)/length(V(gr1))
  ratio_Iso2<-sum(V(gr2)$deg==0)/length(V(gr2))
  
  dd[2]<-abs(ratio_Iso1-ratio_Iso2)
  ww[2]<-30
 
  
  
  # get closeness distribution 
  V(gr1)$clo<-closeness(gr1,mode="all")
  V(gr2)$clo<-closeness(gr2,mode="all")
  dd[3]<-norm_ks(V(gr1)$clo,V(gr2)$clo) #compare closeness distribution
  ww[3]<-1
  # get betweeness distribution 
  V(gr1)$betw<-betweenness(gr1)
  V(gr2)$betw<-betweenness(gr2)
  dd[4]<-norm_ks(V(gr1)$betw,V(gr2)$betw) #compare betweeness distribution
  ww[4]<-1
    # get page rank ditribution 
  V(gr1)$pr<-page_rank(gr1)$vector
  V(gr2)$pr<-page_rank(gr2)$vector
  dd[5]<-norm_ks(V(gr1)$pr,V(gr2)$pr) #compare pr distribution
  ww[5]<-1
  # get local clustering coefficient 
  V(gr1)$trans<-transitivity(gr1,type="local",isolates="zero")
  V(gr2)$trans<-transitivity(gr2,type="local",isolates="zero")
  dd[6]<-norm_ks(V(gr1)$trans,V(gr2)$trans) #compare trans distribution
  ww[6]<-1
  # get global clustering coefficient
  gr1$trans<-transitivity(gr1,type="global",isolates="zero")
  gr2$trans<-transitivity(gr2,type="global",isolates="zero")
  dd[7]<-abs(gr1$trans-gr2$trans)
  ww[7]<-1
  # get shortest path distribution 
  #comoute each distance and average them somehow 
  x1<-shortest.paths(gr1);shp1<-as.vector(x1[lower.tri(x1, diag = FALSE)])
  x2<-shortest.paths(gr2);shp2<-as.vector(x2[lower.tri(x2, diag = FALSE)])
  shp1[is.na(shp1)]<-length(V(gr1))+1
  shp2[is.na(shp2)]<-length(V(gr2))+1
  shp1[is.infinite(shp1)]<-length(V(gr1))*2
  shp2[is.infinite(shp2)]<-length(V(gr2))*2
  dd[8]<-norm_ks(shp1,shp2) #compare trans distribution
  ww[8]<-1
  
  
  
  ww<-ww/sum(ww,na.rm=T)
  
  final<-mean(dd*ww,na.rm = T)
  
  print(dd)
  res<-list(final,dd,ww)
  return(res)
}




