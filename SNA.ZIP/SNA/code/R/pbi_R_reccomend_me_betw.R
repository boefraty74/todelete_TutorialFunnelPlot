source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\get_betw_value_missing_edges.R",sep=""))


#save(dataset,file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")# for DEBUG
pbi_R_reccomend_me_betw<-function(dataset)
{
  source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
  #find wich one of dataset$V1[1],dataset$V1[2],dataset$V1[3] is sGraph
  snaFile<-as.character(dataset$V1[1])
  if(length(grep("sGraph",as.character(dataset$V1[2])))>0)
    snaFile<-as.character(dataset$V1[2])
  if(length(grep("sGraph",as.character(dataset$V1[3])))>0)
    snaFile<-as.character(dataset$V1[3])
  
  myPropFile<-as.character(dataset$V1[1])
  if(length(grep(".csv",as.character(dataset$V1[2])))>0)
    myPropFile<-as.character(dataset$V1[2])
  if(length(grep(".csv",as.character(dataset$V1[3])))>0)
    myPropFile<-as.character(dataset$V1[3])
  
  
  
  g_sna_with_outsider<-read_graph(file=snaFile,format="graphml")
  Lp1<-length(V(g_sna_with_outsider))
  g_sna<-delete.vertices(g_sna_with_outsider,V(g_sna_with_outsider)[Lp1])
  
  t<-read.csv(myPropFile)
  tN<-match(t$ActorID,V(g_sna)$id)
  if(length(tN)==0)
    return;
  
  g<-g_sna
  
  av<-as.vector(adjacent_vertices(g,tN,mode="all")[[1]])
  non_av<-setdiff(seq(1,length(V(g))),av)
  ee<-cbind(rep(tN,length(non_av)),non_av)
  
  
  
  
  res<-get_betw_value_missing_edges(g=g,ee=ee,tN=tN)
  
  absChange<-res[[1]]
  relChange<-res[[2]]
  
  sortedChange<-sort(relChange,decreasing = TRUE,index.return = TRUE)
  
  
  par(mar = c(0,0,0,0))
  plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')
  
  text(x = 0.1, y = 0.9, paste("RECOMMENDATION: Connections to improve your \n  centrality in the social network"), 
       cex = 1.0, col = "black", family="serif", font=2, adj=0)
  
  
  sss<-""
  for(i in 1:3)
  {
    sss<-paste(sss,"\n",
               V(g)$Title[ee[sortedChange$ix[i],2]],
               sortedChange$x[i],"%")
    
    
  }
  
  
  text(x = 0.1, y = 0.5, sss, 
       cex = 1.0, col = "gray30", family="sans", font=1, adj=0)
  
  
  
  
  
  
}