#decide about which labels to show 
sparsify_labels_by_layout<-function(g,iL,labels=V(g)$label,
                                    lAttribute=NULL,mfactor=1,
                                    minVertDist=1,minHoriDist=2.2) 
{
  minVertDist<-minVertDist*mfactor
  minHoriDist<-minHoriDist*mfactor
  
  NV<-length(V(g))
  if(is.null(lAttribute))
    lAttribute<-sample(1:100,NV,TRUE)
  
  iL_norm<-(iL-min(iL))/(max(iL)-min(iL))
  
  
  DD_H<-as.matrix(dist(iL_norm[,1],method = "manhattan"))
  DD_V<-as.matrix(dist(iL_norm[,2],method = "manhattan"))
  
  #sort labels by attribute 
  ss<-sort(lAttribute,index.return =TRUE)
  tempAttr1<-match(1:NV,ss$ix)
  tempAttr2<-(-abs(tempAttr1-median(tempAttr1)))
  order_imp<-sort(tempAttr2,index.return =TRUE)$ix
  #start from most important and go down
  #update dist matrix and labels
  for (i in order_imp)
  {
    if(!is.na(labels[i]))
    {
      labels<- UpdateDistAndLabels(DD_H,DD_V,labels,i,minVertDist,minHoriDist)
      V(g)$label<-labels
      
      #Sys.sleep(0.1)
    }
  }
  #plot(g,layout=iL)
  return(g)
}



##
UpdateDistAndLabels<-function(DD_H,DD_V,labels,i,minVertDist,minHoriDist)
{
  # remove all neighbours
  badH<-(DD_H[i,]<minHoriDist);badH[i]=FALSE
  badV<-(DD_V[i,]<minVertDist);badV[i]=FALSE
  labels[badH & badV]<-NA
  return(labels)
}

if(0){
#try it 
  par(mar=c(5, 4, 4, 2)/7 + 0.1);
 set.seed(42)
 #g<-random.graph.game(200,0.01)
  g<-read.graph('c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\akatz\\sGraph.xml',
                format='graphml')
  g<-delete.vertices(g,V(g)[length(V(g))])
 NV<-length(V(g))
 #V(g)$label<-paste(1:NV,"_aaa",sep="")
 V(g)$label<-V(g)$Title
 #lAttribute=NULL
 lAttribute<-V(g)$hrank
 iL<-layout.auto(g)
# 
# 
 plot(g,layout=iL)
# 
 ppp<-par()$pin
 mfactor=20/(min(ppp))
 
  g<-sparsify_labels_by_layout(g=g,iL=iL,labels=V(g)$label,
                                     lAttribute=lAttribute,mfactor=mfactor,
                                     minVertDist=1,minHoriDist=3) 
 
 plot(g,layout=iL)


}


