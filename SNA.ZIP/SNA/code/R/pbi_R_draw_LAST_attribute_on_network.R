#source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\pbi_R_graph_draw_with_attributes.R",sep=""))
#save(dataset,file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")# for DEBUG

pbi_R_draw_LAST_attribute_on_network<-function(dataset,tit=NULL,multi=1)
{
  
  set.seed(42)
  NC<-ncol(dataset)
  dataset$nodeColAttrib<-dataset[,NC]*multi
  par(mar=c(5, 4, 4, 2)/7 + 0.1);
  pbi_R_graph_draw_with_attributes(dataset)
  if(is.null(tit))
    tit<-paste("Attribute on top of Social Network: ",names(dataset)[NC])
  title(main=tit)
}