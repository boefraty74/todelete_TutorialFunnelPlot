# CreateSubteamsByHierarchyLevel.R
# Construct subteams trees from full tree, update connectivity

source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\my_graph_plot_advanced.R",sep=""))






CreateSubteamsByHierarchyLevel<-function(treeGraph,snaGraph,targetLevel=1)
{
  NV<-length(V(treeGraph))
  NE<-length(E(snaGraph))
  
  V(treeGraph)$hrank[NV]<-NaN
  zeroHRank<-V(treeGraph)$hrank[1]
  
  # create column to select head of each group 
  temp<- (V(treeGraph)$hrank-zeroHRank== targetLevel)
  temp_above<- (V(treeGraph)$hrank-zeroHRank< targetLevel)
  temp_under<- (V(treeGraph)$hrank-zeroHRank> targetLevel)
  
  # make OUTSIDER the new group
  temp[NV]<-TRUE
  temp_above[NV]<-FALSE
  temp_under[NV]<-FALSE
  
  NT<-sum(temp,na.rm=T)
  
  V(treeGraph)$subteam_head<-0
  V(treeGraph)$subteam_above<-0
  V(treeGraph)$subteam_head[temp]<-seq(1,NT)
  V(treeGraph)$subteam_above[temp_above]<-1
  
  # create column to select members of each group 
  V(treeGraph)$subteam<-0
  # for each head of group extract all reports 
  for(team in seq(1,NT))
  {
    thi<-match(team,V(treeGraph)$subteam_head)
    resTemp<-graph.dfs(graph=treeGraph,root=V(treeGraph)[thi],neimode = "out",unreachable = F,dist=TRUE)
    selected<-as.vector(resTemp$order)
    selected<-as.integer(selected[!is.na(selected)])
    V(treeGraph)$subteam[selected]<-team
    #update numDirects for thi
    V(treeGraph)$numDirects[thi]<-length(selected)
    V(snaGraph)$numDirects[thi]<-length(selected)
  }
  
  # update nodes of new 2 graphs 
  nodesInTree<-seq(1:NV)[V(treeGraph)$subteam_above+V(treeGraph)$subteam_head>0]
  nodesInSNA<-seq(1:NV)[V(treeGraph)$subteam_head>0]
  treeTeams<-induced_subgraph(treeGraph, nodesInTree[1:length(nodesInTree)-1])
  snaTeams<-induced_subgraph(snaGraph, nodesInSNA)
  
  #V(treeTeams)$label<-one_word_labels(V(treeTeams)$Title)
  #V(snaTeams)$label<-one_word_labels(V(snaTeams)$Title)
  
  V(snaTeams)$label<-paste(one_word_labels(V(snaTeams)$Title),"\n",V(snaTeams)$numDirects,"",sep="")
  V(treeTeams)$label<-paste(one_word_labels(V(treeTeams)$Title),"\n",V(treeTeams)$numDirects,"",sep="")
  V(snaTeams)$label[NT]="OUTSIDE"
  
  # update edges of SNA by teams
  adjMatrix<-matrix(data=0,nrow=NT,ncol=NT) 
  ee<-ends(snaGraph,E(snaGraph))
  for(e in seq(1,NE))
  {
    tfrom<-V(treeGraph)$subteam[ee[e,1]]
    tto<-V(treeGraph)$subteam[ee[e,2]]
    if(tfrom>0 && tto>0)
    {
      adjMatrix[tfrom,tto]<-adjMatrix[tfrom,tto]+1
      adjMatrix[tto,tfrom]<-adjMatrix[tto,tfrom]+1
    }
  }
  if(length(E(snaTeams)))
    snaTeams<-delete_edges(snaTeams, seq(1,length(E(snaTeams))))
  countEdges<-0
  for(n1 in seq(1,NT))
  {
    for (n2 in seq(n1,NT))
    {
      if(adjMatrix[n1,n2]>0)
      {
        countEdges<-countEdges+1
        # print(c(n1,n2,adjMatrix[n1,n2]))
        #snaTeams<-add.edges(snaTeams,c(n1,n2)) %>%
        # set_edge_attr("weight", value = adjMatrix[n1,n2])
        snaTeams<-add.edges(snaTeams,c(n1,n2))
        E(snaTeams)$weight[countEdges]=adjMatrix[n1,n2]
      }
    }
  }
  
  eet<-ends(snaTeams,E(snaTeams))
  # remeber number internal/external/outside weights for each node
  V(snaTeams)$internalWeights<-diag(adjMatrix)
  V(snaTeams)$externalWeights<- colSums(adjMatrix[1:NT-1,])
  V(snaTeams)$outsideWeights<- adjMatrix[,NT]
  V(snaTeams)$totalWeights<-V(snaTeams)$internalWeights+V(snaTeams)$externalWeights+V(snaTeams)$outsideWeights
  
  
  
  
  snaTeams_no_external<-delete.edges(snaTeams,seq(1,length(E(snaTeams)))[eet[,2]==NT])
  snaTeams_no_external<-delete.vertices(snaTeams_no_external,NT)
  snaTeams_only_external<-delete.edges(snaTeams,seq(1,length(E(snaTeams)))[eet[,2]!=NT])
  
  snaTeams_no_external<-simplify(snaTeams_no_external)
  
  
  
  #E(snaTeams)$label<-E(snaTeams)$weight
  
  my_graph_plot_advanced(treeTeams,mylayout=NULL)
  title(main=paste("Hierarchy of organization up to level ",targetLevel),
        sub=paste("Numbers in nodes are number of direct reports", "\n", 
                  "Numbers in leaves are team size"),
        cex.main = 1.5,cex.sub = 1.5)
  
  #E(snaTeams_no_external)$width<-E(snaTeams_no_external)$weight
  E(snaTeams_no_external)$label<- E(snaTeams_no_external)$weight
  V(snaTeams_no_external)$label<-paste(one_word_labels(V(snaTeams_no_external)$Title),"\n",V(snaTeams_no_external)$internalWeights,"",sep="")
  
  if(length(E(snaTeams_no_external))>85)
    E(snaTeams_no_external)$label<-""
  
  my_graph_plot_advanced(snaTeams_no_external,
                         mylayout=NULL,
                         nodeRadAttrib=V(snaTeams_no_external)$numDirects+1,
                         nodeColAttrib = V(snaTeams_no_external)$numDirects+1,
                         edgeWidthAttrib = E(snaTeams_no_external)$weight)
  title(main=paste("Connections within and between teams at level ",targetLevel),
                   sub=paste("Size of the node proportional to team size", "\n", 
                   "Numbers in nodes are number of connections WITHIN team"),
        cex.main = 1.5,cex.sub = 1.5)
  
  
  E(snaTeams_only_external)$label<- E(snaTeams_only_external)$weight
  if(length(E(snaTeams_only_external))>75)
    E(snaTeams_only_external)$label<-""
  
  V(snaTeams_only_external)$label[1:(NT-1)]<-paste(one_word_labels(V(snaTeams_only_external)$Title),
                                                   "\n",V(snaTeams_only_external)$totalWeights,"",sep="")
  
#    E(snaTeams_only_external)$label<- paste(E(snaTeams_only_external)$weight,"/",
#                                            V(snaTeams_only_external)$totalWeights[1:(NT-1)])
  
   
    
  my_graph_plot_advanced(snaTeams_only_external,
                         mylayout=layout.star(snaTeams_only_external,NT),
                         nodeRadAttrib=V(snaTeams_only_external)$numDirects+1,
                         nodeColAttrib = V(snaTeams_only_external)$numDirects+1,
                         edgeWidthAttrib = E(snaTeams_only_external)$weight,
                         nodeLabelShowIndicator=V(snaTeams)$outsideWeights)
  
  title(main=paste("Out of organization connections of each team at level ",targetLevel),
        sub=paste("Size of the node proportional to team size", "\n", 
                  "Numbers in nodes are number of TOTAL CONNECTIONS of the team"),
        cex.main = 1.5,cex.sub = 1.5)

}


if(0)
{
snaGF<-"C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\akatz\\sGraph.xml"
treeGF<-"C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\akatz\\hGraph.xml"

#snaGF<-"C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\japhilli\\sGraph.xml"
#treeGF<-"C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\japhilli\\hGraph.xml"

#snaGF<-"C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\nipirvan\\sGraph.xml"
#treeGF<-"C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\nipirvan\\hGraph.xml"



treeGraph<-read.graph(file=treeGF,format="graphml")
snaGraph<-read.graph(file=snaGF,format="graphml")

targetLevel=2
CreateSubteamsByHierarchyLevel(treeGraph=treeGraph,snaGraph = snaGraph,targetLevel = targetLevel)
}