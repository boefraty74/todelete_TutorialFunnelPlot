
load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")# for DEBUG

library(igraph)


get_betw_value_missing_edges<-function(g,ee,tN=NULL)
{
  NR<-nrow(ee)
  #if(is.null(tN))
  #  tN<-seq(1,length(V(g)))
  E(g)$weight=1
  #compute betweenes 
  if(!is.null(tN)){
    btw<-closeness(g,vids=V(g)[tN]) # absolute addition
  } else {
    btw<-mean(closeness(g),na.rm = TRUE) # absolute addition
  }
  
  cB<-rep(0,NR)
  for(r in seq(1,NR))
  {
    r
    g1<-as.undirected(add.edges(g,as.integer(ee[r,])))
    E(g1)$weight=1
    
    if(!is.null(tN)){
      btw1<-closeness(g1,vids=V(g1)[tN]) # absolute addition
    } else {
      btw1<-mean(closeness(g1),na.rm = TRUE) # absolute addition
    }
    remove(g1)
    cB[r]<-btw1-btw
  }
  
  cB_perc<-round(100*cB/btw,digits=2) # percentage addition 
  
  res<-list(cB,cB_perc,btw)
  return(res)
}



reconstruct_iGraph_from_PBI_columns<-function(eFrom,eTo,eWeight=NULL,vID,vLabel=NULL,autoNodeID)
{
  # eFrom = vID of "from" vertex
  # eTo = vID of "to" vertex
  # eWeight = weight of edge (if null will be replaced by 1)
  # vID = unique IDs of vertices 
  # vLabel = unique strings for vertices "to show", (if NULL will be replaced by vID)
  #autoNodeID = 1,2,3,...
  
  
  #TODO: WORKS WRING IF SOME autoNodeID is missing 
  NV<-length(unique(vID))
  NE<-length(eFrom)
  
  
  
  if(is.null(eWeight)){
    eWeight<-rep(1,NE)
  }
  if(is.null(vLabel)){
    vLabel<-vID
  }
  
  u<-data.frame(vID,vLabel,autoNodeID,stringsAsFactors = F)
  u<-unique(u)
  u<-u[order(u$autoNodeID),]
  
  myIDs<-seq(1,NV)
  names(myIDs)<-as.character(u$autoNodeID)
  
  #g<-graph.empty(n=NV, directed=FALSE)
  #add.vertices(g, myIDs[vID])
  #add.edges(g,as.vector(rbind(myIDs[eFrom],myIDs[eTo])))
  
  #eedges<-as.numeric(as.vector(rbind(myIDs[eFrom],myIDs[eTo])))
  eFromTo<-rbind(eFrom,eTo)
  
  NC<-  ncol(eFromTo)
  keepEdges<-rep(1,NC)
  for (c in seq(1,NC))
    keepEdges[c]<-prod(is.element(eFromTo[,c],u$autoNodeID))
  
  eFromTo<-eFromTo[,as.logical(keepEdges)]
  eedges<-as.numeric(as.vector(eFromTo))
  
  #selectedEdges<-seq(1,NC)
  #selectedEdges<-selectedEdges[as.logical(keepEdges)]
  
  
  
  #g<-graph(eedges,n=max(eedges), directed=F)
  g<-graph(as.character(eedges))
  
  
  #Order rows in u such that autoNodeID coinsides with names(V(g))
  uu<-u[myIDs[names(V(g))],]
  
  
  
  V(g)$label<-as.character(uu$vLabel)
  V(g)$id<-as.character(uu$vID)
  
  g<-simplify(g)
  
  
  #TODO: find selected edges 
  sho<-paste(ends(g,E(g))[,1],ends(g,E(g))[,2],sep="_")
  lo<-paste(eFrom,eTo,sep="_")
  selectedEdges<-match(sho,lo)
  
  
  g$selectedEdges<-selectedEdges
  g$selectedNodes<-match(V(g)$id,as.character(vID))
  
  E(g)$weight<-eWeight[selectedEdges]
  
  
  return(g)
}






my_get_all_edge_attr<-function(g,index)
{
  forAllEdges<-get.edge.attribute(g)
  res<-list()
  count=1
  for(n in names(forAllEdges))
  {
    res<-append(res,list(forAllEdges[[count]][index]))  
    count=count+1
  }
  names(res)<-names(forAllEdges)
  return(res)
}




############################
one_word_labels<-function(la)
{
  L=length(la)
  res<-la
  fff<-strsplit(la," ")
  for(i in c(1:L))
  {
    res[i]<-fff[[i]][1]
    
  }
  return(res)
}




pbi_R_reccomend_org_centr_FLAT<-function(g_sna)
{
  set.seed(42)
  MAX_NEE<-750
 
  #g_sna_with_outsider<-read_graph(file=snaFile,format="graphml")
  #Lp1<-length(V(g_sna_with_outsider))
  #g_sna<-delete.vertices(g_sna_with_outsider,V(g_sna_with_outsider)[Lp1])
  
  
  g<-g_sna
  
  ee<-matrix(nrow=0,ncol=2)
  for (tN in 1:length(V(g)))
  {
    av<-as.vector(adjacent_vertices(g,tN,mode="all")[[1]])
    non_av<-setdiff(seq(1,length(V(g))),av)
    ee1<-cbind(rep(tN,length(non_av)),non_av)
    ff<-ee1[,1]<ee1[,2]
    ee1<-ee1[ff,]
    ee<-rbind(ee,ee1)
  }
  #TODO: leave only up to 2000 random edges 
  NEE<-nrow(ee)
  
  if(NEE>MAX_NEE)
  {
    iii<-sample(seq(1,NEE),MAX_NEE)
    ee<-ee[iii,]
  }
  res<-get_betw_value_missing_edges(g=g,ee=ee,tN=NULL)
  
  absChange<-res[[1]]
  relChange<-res[[2]]
  
  sortedChange<-sort(relChange,decreasing = TRUE,index.return = TRUE)
  
  
  par(mar = c(0,0,0,0))
  plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')
  
  text(x = 0.1, y = 0.9, paste("RECOMMENDATION: Connections to improve organization \n  CENTRALITY in the social network"), 
       cex = 1.0, col = "black", family="serif", font=2, adj=0)
  
  
  sss<-""
  for(i in 1:min(10,nrow(ee)))
  {
    sss<-paste(sss,"\n",
               V(g)$label[ee[sortedChange$ix[i],1]],
               "--",
               V(g)$label[ee[sortedChange$ix[i],2]],
               sortedChange$x[i],"%")
    
    
  }
  
  
  text(x = 0.1, y = 0.4, sss, 
       cex = 1.0, col = "gray30", family="sans", font=1, adj=0)
  
  

}

eFrom <- dataset$autoNodeID
eTo <- dataset$autoNodeID.1
eWeight <- dataset$weight
vID <- dataset$V_id
vLabel <- dataset$V_label
autoNodeID<-dataset$autoNodeID.2

g<-reconstruct_iGraph_from_PBI_columns(eFrom,eTo,eWeight,vID,vLabel,autoNodeID)
g_sna<-as.undirected(g)

pbi_R_reccomend_org_centr_FLAT(g_sna)

