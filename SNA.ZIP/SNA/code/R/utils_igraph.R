library(igraph)
#source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\my_networkD3_plot.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\my_graph_plot_advanced.R",sep=""))


my_simplify<-function(gr)
{
  gr<-simplify(gr)
  #remove isolated
  d<-degree(gr)
  isol<-seq(1,length(V(gr)))[d==0]
  gr<-delete.vertices(gr,isol)
  return(gr)
}


my_get_all_edge_attr<-function(g,index)
{
  forAllEdges<-get.edge.attribute(g)
  res<-list()
  count=1
  for(n in names(forAllEdges))
  {
    res<-append(res,list(forAllEdges[[count]][index]))  
    count=count+1
  }
  names(res)<-names(forAllEdges)
  return(res)
}



my_graph_plot<-function(gr,attrib_node,mylayout)
{
  #generate 100 colors black to white
  mcolors<-array(dim=100)
  j<-1
  for (i in seq(0,1,0.01))
  {
    mcolors[j]<-rgb(0,i,0,0.8)
    j<-j+1
  }
  mi<-min(attrib_node)
  ma<-max(attrib_node)
  #assign due to attribute 
  for (i in c(1:length(V(gr))))
  {
    temp<-round(((attrib_node[i]-mi)/(ma-mi))*100)
    V(gr)[i]$color <- mcolors[temp+1]
  }
  V(gr)$label.cex <- 0.5 * attrib_node / ma+ .3
  V(gr)$label.color <- rgb(0.8, 0.2, .0, .8)
  V(gr)$frame.color <- NA
  #plot 
  plot(gr, vertex.color=V(gr)$color,vertex.label=V(gr)$number,layout=mylayout)
}

############################
one_word_labels<-function(la)
{
  L=length(la)
  res<-la
  fff<-strsplit(la," ")
  for(i in c(1:L))
  {
    res[i]<-fff[[i]][1]
    
  }
  return(res)
}

my_graph_plot<-function(gr,attrib_node,mylayout)
{
  #generate 100 colors black to white
  mcolors<-array(dim=100)
  j<-1
  for (i in seq(0,1,0.01))
  {
    mcolors[j]<-rgb(0,i,0,0.8)
    j<-j+1
  }
  mi<-min(attrib_node)
  ma<-max(attrib_node)
  #assign due to attribute 
  for (i in c(1:length(V(gr))))
  {
    temp<-round(((attrib_node[i]-mi)/(ma-mi))*100)
    V(gr)[i]$color <- mcolors[temp+1]
  }
  V(gr)$label.cex <- 0.5 * attrib_node / ma+ .3
  V(gr)$label.color <- rgb(0.8, 0.2, .0, .8)
  V(gr)$frame.color <- NA
  #plot 
  plot(gr, vertex.color=V(gr)$color,vertex.label=V(gr)$number,layout=mylayout)
}
#######################
my_graph_plot_advanced_old<-function(gr,nodeRadAttrib=NULL,nodeColAttrib=NULL,nodeLabel=NULL,
                                 edgeColorAttrib=NULL,edgeWidthAttrib=NULL,edgeTypeAttrib=NULL,
                                 nodeGroupIndicator=NULL, nodeColor=NULL,
                                 mylayout=layout.auto(gr))
{
 
  if(is.null(mylayout))
  {
   if(is.directed(gr))
     mylayout <-layout.reingold.tilford(gr,root=1) # good for tree
    else
      mylayout<-layout.fruchterman.reingold(gr)
    #mylayout<-layout.spring(gr) # almost like f-r
    #mylayout<-layout.lgl(gr)
    
  }
  
  DEFAULT_NODE_COLOR<-rgb(1,1,0.0,0.7)
  DEFAULT_FONT_COLOR<-rgb(0.6, 0.05, .0, .8)
  DEFAULT_NODE_RAD<-3
  
  mcolors<-array(dim=100)
  j<-1
  for (i in seq(0.2,0.95,length.out = 102))
  {
    mcolors[j]<-rgb(0.1,i,0,0.6)
    j<-j+1
  }
  #print(nodeColAttrib)
  if(!is.null(nodeColAttrib) && min(nodeColAttrib)!=max((nodeColAttrib)))
  {
    mi<-min(nodeColAttrib)
    ma<-max(nodeColAttrib)
    nodeColAttrib<-(nodeColAttrib-mi)/(ma-mi)
    #assign due to attribute 
    for (i in c(1:length(V(gr))))
    {
      temp<-round((nodeColAttrib[i])*100)
      V(gr)[i]$color <- mcolors[temp+1]
      print(temp)
    }
    
  }
  else
  {
    if(is.null(nodeColor)) 
      V(gr)[]$color <- DEFAULT_NODE_COLOR
    else
      V(gr)$color<-nodeColor
  } 
  
  
  if(!is.null(nodeLabel))
    V(gr)$label<-nodeLabel
  
  
  V(gr)$label.color <- DEFAULT_FONT_COLOR
  V(gr)$frame.color <- NA # no frame on node
  
  if(is.directed(gr))
    plot(gr,vertex.color=V(gr)$color,layout=mylayout,asp=0)
  else
    plot(gr,vertex.color=V(gr)$color,layout=mylayout)
  
}
############################

