# CreateSubgraphsByNames.R
#create h and sna subgraphs from large ones
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))

FindNamesInColumn<-function(searchHere,inNames)
{
  searchHere<-tolower(searchHere)
  inNames<-tolower(inNames)
  
  NN<-length(searchHere)
  NI<-length(inNames)
  tempRes<-rep(FALSE,NN)
  for (n in inNames)
  {
    pos = regexpr(n,searchHere)
    ii<-match(TRUE,pos!=-1)
    if(is.na(ii))
    {
      pos = regexpr(one_word_labels(n),searchHere)
      ii<-match(TRUE,pos!=-1)
    }
    tempRes[ii]<-TRUE
  }
  tempRes<-seq(1,NN)[tempRes]
  return(tempRes)
}




############
#CreateSubgraphsByNames
###########
CreateSubgraphsByNames<-function(names2find,lsgName=NULL,lhgName=NULL,
                                 nameMe="noone",outSnaName=NULL,outHName=NULL,
                                 outNameMeCSV=NULL,outNameCSV=NULL)
{
  
  #some defailt names
  if(is.null(lsgName))
    lsgName<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\demo_data\\OfficeGraphData\\japhilli\\sGraph.xml",sep="")
  if(is.null(lhgName))
    lhgName<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\demo_data\\OfficeGraphData\\japhilli\\hGraph.xml",sep="")
  if(is.null(outSnaName))
    outSnaName<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\sGraph.xml",sep="")
  if(is.null(outHName))
    outHName<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\hGraph.xml",sep="")
  if(is.null(outNameMeCSV))
    outNameMeCSV<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\demo_data\\OfficeGraphData\\someone.csv",sep="")
  if(is.null(outNameCSV))
    outNameCSV<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\demo_data\\dataset.csv",sep="")
  
  
  names2find<-c(names2find,"OUTSIDE")
  large_sGraph<-read.graph(lsgName,format="graphml")
  large_hGraph<-read.graph(lhgName,format="graphml")
  
  
  #find ids of vetrices by names or first names (if not found)
  foundInds<-FindNamesInColumn(V(large_hGraph)$Title,names2find)
  
  NV<-length(V(large_hGraph))
  NE<-length(E(large_sGraph))
  
  myNodes<-NULL
  newHRank<-rep(NaN,NV)
  newNumCollegues<-V(large_hGraph)$numCollegues
  
  
  for(ind in foundInds)
  {
    # create column to select head of each group
    resTemp<-graph.dfs(graph=large_hGraph,root=V(large_hGraph)[ind],neimode = "out",unreachable = F,dist=TRUE)
    mmm<-resTemp$order[!is.na(resTemp$order)]
    newHRank[!is.nan(resTemp$dist)]=resTemp$dist[!is.nan(resTemp$dist)]
    newNumCollegues[ind]<-0
    
    myNodes<-unique(union(myNodes,mmm))
  }
  newHRank[NV]<-0
  
  #update hrank 
  V(large_hGraph)$hrank<-newHRank
  V(large_sGraph)$hrank<-newHRank
  #update numCollegues
  V(large_hGraph)$numCollegues<-newNumCollegues
  V(large_sGraph)$numCollegues<-newNumCollegues
  
  inNodes<-rep(FALSE,NV)
  inNodes[myNodes]<-TRUE
  inNodes[NV]<-FALSE #outsider
  
  #go through all edges and add edges to outsider
  ee<-ends(large_sGraph,1:NE)
  for(ei in 1:NE)# update edges to OUTSIDER 
  {
    if(inNodes[ee[ei,1]] && !inNodes[ee[ei,2]])
    {
      attr<-my_get_all_edge_attr(large_sGraph,ei)
      large_sGraph<-add.edges(graph=large_sGraph,edges=c(ee[ei,1],NV),attr=attr)
    }
    else if(!inNodes[ee[ei,1]] && inNodes[ee[ei,2]])
    {
      attr<-my_get_all_edge_attr(large_sGraph,ei)
      large_sGraph<-add.edges(large_sGraph,c(ee[ei,2],NV),attr=attr)
    }
  }
  
  
  
  
  #Extract sub-teams
  treeG<-induced_subgraph(large_hGraph, V(large_hGraph)[myNodes])
  snaG<-induced_subgraph(large_sGraph, V(large_sGraph)[myNodes])
  
  snaG<-simplify(snaG,edge.attr.comb=list(weight="sum", "ignore"))
 
  #me
  foundInds<-FindNamesInColumn(V(snaG)$Title,nameMe)
  ActorID<-V(snaG)$id[foundInds]
  Title<-V(snaG)$Title[foundInds]
  alias<-"alias"
  me_df<-data.frame(ActorID,Title,alias)
  
   
  #Save outputs
  write.graph(treeG,outHName,"graphml")
  write.graph(snaG,outSnaName,"graphml")
  
  #save CSV of dataset
  df0<-data.frame(c(outSnaName,outHName,outNameMeCSV),stringsAsFactors = FALSE)
  df0[1,1]<-sub(Sys.getenv("SNA4PBI_PATH"),"",df0[1,1],fixed=TRUE)
  df0[2,1]<-sub(Sys.getenv("SNA4PBI_PATH"),"",df0[2,1],fixed=TRUE)
  df0[3,1]<-sub(Sys.getenv("SNA4PBI_PATH"),"",df0[3,1],fixed=TRUE)
  if(!is.null(outNameCSV) && !is.na(outNameCSV))
    write.table(df0, file = outNameCSV,sep=",",quote = FALSE,
                row.names = FALSE,col.names = FALSE)
  
  #save CSV of ME (if ME found)
  if(!is.null(outNameMeCSV) && !is.na(outNameMeCSV))
    write.table(me_df, file = outNameMeCSV,sep=",",quote = FALSE,
                row.names = FALSE,col.names = TRUE)
  
  #SHOW
  V(treeG)$label<-V(treeG)$Title
  V(snaG)$label<-V(snaG)$Title
  
  plot(treeG)
  plot(snaG)
}

################
# USAGE
##############

#inputs
 lsgName<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\japhilli\\sGraph.xml"
 lhgName<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\japhilli\\hGraph.xml"
# lsgName<-NULL
# lhgName<-NULL

#names2find<-c("Stas Klyachkovsky")
# nameMe<-"Jacob Minsky"
#  names2find<-c("Yifat Sagiv")
#  nameMe<-"Ali Hamud"
 
#   names2find<-c("Ariel Katz")
#   nameMe<-"Boris Efraty"

names2find<-c("Yoav Yassour")
nameMe<-""
 
 
outSnaName<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\dataset\\sGraph.xml"
outHName<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\dataset\\hGraph.xml"
outNameMeCSV=NULL
outNameCSV=NULL

CreateSubgraphsByNames(names2find=names2find,lsgName=lsgName,lhgName=lhgName,
                       nameMe=nameMe,
                       outSnaName=outSnaName,outHName=outHName,
                       outNameMeCSV=NULL,outNameCSV=NULL)
