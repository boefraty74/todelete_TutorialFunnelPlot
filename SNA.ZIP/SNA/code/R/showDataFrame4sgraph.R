#showDataFrame4sgraph

#run after (1) pbiConnector
# (2)computeDataFrame4sgraph.R

outPDFPath = paste(Sys.getenv("SNA4PBI_PATH"),"output\\out.pdf",sep="")
outHTMLPath = paste(Sys.getenv("SNA4PBI_PATH"),"output\\out_html\\",sep="")

print("Removing all HTMLs")
file.remove(dir(outHTMLPath,full.names=T))

pdf(file=outPDFPath)  



l_tree <-layout.reingold.tilford(g_tree) # good for tree
l_sna<-layout.auto(g_sna) #good for SN


par(mfrow=c(1,1))

my_graph_plot(g_tree,df4nodes$V_centr_tree,l_tree);title(main="Hierarchy and hierarchical centrality")

my_graph_plot(g_sna,df4nodes$V_centr,l_sna);title(main="Social Network and Social Centrality")

par(mfrow=c(1,1))
my_graph_plot(g_sna,-df4nodes$V_height,l_sna);title(main="Level in Hierarchy on top of Social Network")

par(mfrow=c(1,1))

barplot(sorted_conflicts[ind2show],names.arg=sorted_labels[ind2show] ,cex.names=0.5,main="Largest and smallset  gaps of Closeness",
        xlab= "Name",
        ylab= "Gap in closeness",
        col=colors1[ind2show]
)

par(mfrow=c(2,1))
my_graph_plot(g_sna,as.numeric(df4nodes$V_degree),l_sna);title(main="Node Degree (count connections)")

hist(as.numeric(df4nodes$V_degree),main="Degree distribution")

par(mfrow=c(1,1))
my_graph_plot(g_sna,as.numeric(df4nodes$V_betw),l_sna);title(main="Betweeness")

par(mfrow=c(1,1))
my_graph_plot(g_sna,as.numeric(df4nodes$V_pageRank),l_sna);title(main="Page Rank")

par(mfrow=c(1,1))
my_graph_plot(g_sna,as.numeric(df4nodes$V_coreness),l_sna);title(main="Coreness")

par(mfrow=c(2,1))
my_graph_plot(g_sna,df4nodes$V_ratio_down,l_sna);title(main="Upward communication")
hist(as.numeric(df4nodes$V_ratio_down),main="Upward communication distribution")



par(mfrow=c(2,1))
my_graph_plot(g_sna,df4nodes$V_ratio_up,l_sna);title(main="Downward communication")
hist(df4nodes$V_ratio_up,main="Downward communication distribution")

par(mfrow=c(2,1))
my_graph_plot(g_sna,df4nodes$V_ratio_up,l_sna);title(main="Same level communication")
hist(df4nodes$V_ratio_samelevel,main="Same level communication distribution")

par(mfrow=c(2,1))
my_graph_plot(g_sna,df4nodes$V_ratio_outside,l_sna);title(main="In-Out  communication")
hist(df4nodes$V_ratio_samelevel,main="In-Out communication distribution")


# communities
par(mfrow=c(1,1))
blocks <- cohesive.blocks(g_sna)
set.seed(42)
plot(blocks, g_sna, vertex.size=.3, vertex.label.cex=0.6, edge.color=rgb(.4,.4,0,.3),layout=l_sna,main="Communities")


#cliques
###
cl <- maximal.cliques(g_sna)
LCL<-length(cl)
MINC=4

ml<-c(1:LCL)
for (i in c(1:LCL))
{
  ml[i]<-length(cl[[i]])
}
cl1<-cl[ml>MINC]


colbar <- rainbow(length(cl1) + 1)
for (i in 1:length(cl1)) {
  V(g_sna)[cl1[[i]]]$color <- colbar[i+1]
}
plot(g_sna, mark.groups=cl1,vertex.size=.3, vertex.label.cex=0.5, edge.color=rgb(.4,.4,0,.3),layout=l_sna)

title(main=paste("Cliques of size  >",MINC))

#largest cliques

cl <- largest.cliques(g_sna)
colbar <- rainbow(length(cl) + 1)

for (i in 1:length(cl)) {
  V(g_sna)[cl[[i]]]$color <- colbar[i+1]
}
plot(g_sna, mark.groups=cl,vertex.size=.3, vertex.label.cex=0.5, edge.color=rgb(.4,.4,0,.3),layout=l_sna)

title(main=paste("Largest Cliques of size",length(cl[[1]])))




# Create fake data


dev.off() 


