library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))

inputFile_company<-  paste(Sys.getenv("SNA4PBI_PATH"),"data\\company.graphml",sep="")  
inputFile_company_sna<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\company_sna.graphml",sep="")

g_sna<-read_graph(file=inputFile_company_sna,format="graphml")
V(g_sna)$label<-V(g_sna)$id

g_tree<-read_graph(file=inputFile_company,format="graphml")
V(g_tree)$label<-V(g_tree)$id

tree.clos<-closeness(g_tree,mode="all")
sna.clos<-closeness(g_sna,mode="all")

plot(tree.clos,sna.clos,
     main= "Company rank vs. Closeness in social network ",
     xlab= "Position in company hierarchy",
     ylab= "Closeness in social network",
     xlim=c(0.005,0.02),ylim=c(0.01,0.04),
     col= "blue", pch = 19, cex = 1, lty = "solid", lwd = 2)
text(tree.clos,sna.clos, labels=V(g_sna)$label, cex= 0.7, pos=3)


l_tree <-layout.reingold.tilford(g_tree,root=1) # good for tree
l_sna<-layout.auto(g_sna) 



par(mfrow=c(1,2))
my_graph_plot(g_tree,tree.clos,l_tree);title(main="Hierarchy")
my_graph_plot(g_sna,sna.clos,l_sna);title(main="Closeness")

