source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\generate_special_graph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\my_compare_two_graphs.R",sep=""))



# load graph 
#inputFile_company_sna<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\benchmark_graphs\\my_perfect.xml"
inputFile_company_sna<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\ssrini\\sGraph.xml"
g<-read_graph(file=inputFile_company_sna,format="graphml")
g<-delete.vertices(g,V(g)[length(V(g))])
  
nE<-length(E(g))
nV<-length(V(g))
# load benchmark graphs 

g_a<- generate_special_graph(nE,nV,"A-Team")
g_f<- generate_special_graph(nE,nV,"Family")
g_m<- generate_special_graph(nE,nV,"Mafia")
g_i<- generate_special_graph(nE,nV,"Isolated")


gr1<-g;gr2<-g_i
d_i<-my_compare_two_graphs(gr1,gr2,params=NULL)
gr1<-g;gr2<-g_m
d_m<-my_compare_two_graphs(gr1,gr2,params=NULL)
gr1<-g;gr2<-g_f
d_f<-my_compare_two_graphs(gr1,gr2,params=NULL)
gr1<-g;gr2<-g_a
d_a<-my_compare_two_graphs(gr1,gr2,params=NULL)


dists<-c(d_a[[1]],d_f[[1]],d_m[[1]],d_i[[1]])



#dists<-max(dists)-dists
dists<-100*dists/sum(dists)
dists<- 100-dists
dists<-100*dists/sum(dists)

slices <- dists
lbls <- c("a-team","family","mafia","isolated")
pct <- round((slices)/sum(slices)*100)
lbls <- paste(lbls, pct) # add percents to labels 
lbls <- paste(lbls,"%",sep="") # ad % to labels 
pie(slices[slices>0],labels = lbls[slices>0], col=rainbow(length(lbls)),
    main="Similarity to benchmark networks")

