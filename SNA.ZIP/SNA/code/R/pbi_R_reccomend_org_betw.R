source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))

#save(dataset,file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")# for DEBUG
pbi_R_reccomend_org_betw<-function(dataset)
{
  
  par(mar = c(0,0,0,0))
  plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')
  
  text(x = 0.1, y = 0.8, paste("RECOMMENDATION:\nConnections to improve org \nBETWEENESS centrality in the social network"), 
       cex = 1.0, col = "black", family="serif", font=2, adj=0)
  
  
  
  
  text(x = 0.1, y = 0.4, paste("\n Moshe Haim  -- Binyamin Netanyahu : 1% \n",
                               "Binyamin Netanyahu -- Aba Gurio: 5%\n",
                               "King Crimson -- Richard Sixth: 2%"), 
       cex = 1.0, col = "gray30", family="sans", font=1, adj=0)
 
  
  
  
  
  
}