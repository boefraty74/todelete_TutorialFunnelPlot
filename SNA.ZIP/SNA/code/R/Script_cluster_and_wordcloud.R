
library(igraph)
library(wordcloud)
library(tm)
library(stringr)

par(mfrow=c(1,3))

source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\pbi_R_draw_LAST_attribute_on_network.R",sep=""))



inputFile_company_sna<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\demo_data\\OfficeGraphData\\akatz\\sGraph.xml",sep="")
g_sna_with_outsider<-read_graph(file=inputFile_company_sna,format="graphml")
Lp1<-length(V(g_sna_with_outsider))
g_sna<-delete.vertices(g_sna_with_outsider,V(g_sna_with_outsider)[Lp1])
LLL<-length(V(g_sna))
V(g_sna)$label<-one_word_labels(V(g_sna)$Title)








# clustering 
G<-g_sna

#####
memberships <- list()

### edge.betweenness.community
ebc <- edge.betweenness.community(G)
mods <- sapply(0:ecount(G), function(i) {
  g2 <- delete.edges(G, ebc$removed.edges[seq(length=i)])
  cl <- clusters(g2)$membership
  modularity(G, cl)
})

g2 <- delete.edges(G, ebc$removed.edges[1:(which.max(mods)-1)])
memberships$`Edge betweenness` <- clusters(g2)$membership


ccc<-memberships$`Edge betweenness`


unique_ccc<-unique(ccc)
count_ccc<-unique_ccc
for(c in unique_ccc)
  count_ccc[c]<-sum(ccc==c)

#sort from largest to smallest
sodata<-sort(count_ccc,decreasing=T,index.return = T)


my_rainbow<-c(rgb(0,1,0),rgb(0,0,1),rgb(1,0,0),rgb(1,1,0),rgb(0,1,1),rgb(1,0,1))
#my_rainbow<-c("1","2","3","4","5","6")
my_rainbow[sodata$ix]<-my_rainbow[1:length(unique_ccc)]
#V(G)$color <- rainbow(max(ccc))[ccc+1] #OK         
V(G)$color <- my_rainbow[ccc] #OK         
# V(G)$color <- rainbow(5)[memberships$`Leading eigenvector`+1]  #so-so              
#V(G)$color <- rainbow(5)[memberships$Spinglass+1]  #so-so      
#plot(G) #plot as I do 
#my_graph_plot_advanced(G,mylayout=NULL,nodeColor=V(G)$color,smart_sparsify_labels = TRUE)
my_graph_plot_advanced(G,mylayout=NULL,nodeColor=V(G)$color,smart_sparsify_labels = TRUE)


title("Clustering")


#idexes of first and second largest 
titles1<-V(G)$ModifiedTitles[ccc==sodata$ix[1]]
titles2<-V(G)$ModifiedTitles[ccc==sodata$ix[2]]

#TODO: remove some words  
pal <- brewer.pal(9,"RdYlGn")
pal <- pal[-(1:4)]
wordcloud(titles1,scale=c(5,0.1), max.words=Inf, random.order=FALSE, rot.per=0.35, use.r.layout=FALSE,min.freq=2,colors=pal)
title("Largest Cluster")


pal <- brewer.pal(9,"YlGnBu")
pal <- pal[-(1:4)]
wordcloud(titles2,scale=c(5,0.1), max.words=Inf, random.order=FALSE, rot.per=0.35, use.r.layout=FALSE,min.freq=2,colors=pal)
title("Second Largest Cluster")






