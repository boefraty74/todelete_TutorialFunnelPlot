library(igraph)

#source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\dataEdges.R",sep=""))


#decode graph into 4 tables 

computeDataFrame4igraph<-function(g_sna)
{

  NN<-length(V(g_sna))
  NE<-length(E(g_sna))

  adj_list_g_sna<- get.adjlist(g_sna)

#DATA.FRAME for nodes
  atrV<-vertex_attr(g_sna)
  vnames<-names(atrV)
  df4nodes<-data.frame(nodeID=seq(1,length.out=NN))
  for(n in seq(1,length.out=length(vnames)))
  {
    df4nodes<-cbind(df4nodes,atrV[[n]])
  }
  df4nodes<-as.data.frame(df4nodes)
  names(df4nodes)[-1]<-vnames
  
#DATA.FRAME for edges
  atrE<-edge_attr(g_sna)
  enames<-names(atrE)
  df4edges<-data.frame(edgeID=seq(1,length.out=NE))
  for(n in seq(1,length.out=length(enames)))
  {
    df4edges<-cbind(df4edges,atrE[[n]])
  }
  df4edges<-as.data.frame(df4edges)
  names(df4edges)[-1]<-enames
  
#DATA.FRAME for graph
  g_sna$is_directed=is.directed(g_sna)
  atrG<-graph_attr(g_sna)
  gnames<-names(atrG)
  df4graph<-NULL
  for(n in seq(1,length.out=length(gnames)))
  {
    df4graph<-cbind(df4graph,atrG[[n]])
  }
  df4graph<-as.data.frame(df4graph)
  names(df4graph)<-gnames
  

#DATA.FRAME for connections
df4connections=as.data.frame(ends(g_sna,seq(1,length.out=NE)))
#df4connections=cbind(seq(1,length.out=NE),df4connections)
#names(df4connections)=c("edgeID", "from_NodeID","to_NodeID")
names(df4connections)=c("from_NodeID","to_NodeID")

#add pseudo edges for isolated nodes
df4edges$demi=FALSE
dg<-degree(g_sna)
isolated<-(dg==0)
numIsolated<-(sum(isolated))
ie<-0
for (e in seq(NE+1,length.out=numIsolated))
{
  ie<-ie+1
  isoNodeID=(seq(1,length.out = NN)[isolated])[ie]
  df4edges=rbind(df4edges,df4edges[1,])
  df4edges[e,]=NaN
  df4edges[e,1]=e
  df4edges$demi[e]=TRUE
  df4connections=rbind(df4connections,
                       data.frame(from_NodeID=isoNodeID,to_NodeID=isoNodeID))
}

df4edges=cbind(df4edges,df4connections)
resultList<-list(df4nodes,df4edges,df4graph)
return(resultList)

}




