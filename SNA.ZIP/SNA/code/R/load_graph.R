# load graph from file 
library(igraph)
inputFile<- paste(Sys.getenv("SNA4PBI_PATH"),"data\\sna_large.graphml",sep="") 

if(inputFile=="")
{
  inputFile <- file.choose()
}

g<-read_graph(file=inputFile,format="graphml")
V(g)$label<-V(g)$id

# node properties
graph.v.betw<-betweenness(g)
graph.v.clos<-closeness(g,mode="all")
graph.v.deg<-degree(g)

graph.v.id<-c(1:length(V(g)))
graph.v.alpha_c<-alpha_centrality(g)
graph.v.page_rank<-page_rank(g)$vector
graph.v.labels<-V(g)$label

graph_v_table<-data.frame(graph.v.id,graph.v.labels,graph.v.alpha_c,graph.v.page_rank,graph.v.betw,+
                            graph.v.clos,graph.v.deg)



#graph in PBI form: table_nodes,table_edges, adjacency matrix
M<-as_adj(g)
graph.adj_matr<-as.data.frame.matrix(M)
#table_nodes<-data.frame(g.n.vertices)
ee<-ends(g,c(1:length(E(g))))
#table_edges
graph.edges<-as.data.frame.matrix(ee)

graph.fileName<-as.data.frame(inputFile)


