library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\computeDataFrame4sgraph.R",sep=""))


inputFile_company_sna<-as.character(dataset$myData.V1[1])
inputFile_company_tree<-as.character(dataset$myData.V1[2])

g_sna_with_outsider<-read_graph(file=inputFile_company_sna,format="graphml")
g_tree_with_outsider<-read_graph(file=inputFile_company_tree,format="graphml")

listRes<-computeDataFrame4sgraph(g_sna_with_outsider,g_tree_with_outsider)
#df4nodes,df4edges_sna,df4edges_tree,df4edges_sna_with_outsider,
#fileName_graph_sna,fileName_graph_tree,df4graph_sna,df4graph_tree

df4nodes<-listRes[[1]]
df4edges_sna<-listRes[[2]]
df4edges_tree<-listRes[[3]]
df4edges_sna_with_outsider<-listRes[[4]]
fileName_graph_sna<-listRes[[5]]
fileName_graph_tree<-listRes[[6]]
df4graph_sna<-listRes[[7]]
df4graph_tree<-listRes[[8]]




g<-read_graph(file=graphfileName_sna,format="graphml")
V(g)$label<-V(g)$id
g.n.clos<-closeness(g,mode="all")

set.seed(42)
l<-layout.auto(g) 
my_graph_plot(g,g.n.clos,l);title(main="Closeness")


#####

graph.fileName<-dataset
library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
g<-read_graph(file=as.character(graph.fileName$inputFile[1]),format="graphml")
V(g)$label<-V(g)$id
g.n.betw<-betweenness(g)

set.seed(42)
l<-layout.auto(g) 
my_graph_plot(g,g.n.betw,l);title(main="Betweenness")

####

library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
g<-read_graph(file=as.character(graph.fileName$inputFile[1]),format="graphml")
V(g)$label<-V(g)$id
g.n.page_rank<-page_rank(g)$vector

set.seed(42)
l<-layout.auto(g) 
my_graph_plot(g,g.n.page_rank,l);title(main="Page Rank")

####

library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
g<-read_graph(file=as.character(graph.fileName$inputFile[1]),format="graphml")
V(g)$label<-V(g)$id
blocks <- cohesive.blocks(g)
set.seed(42)
l<-layout.auto(g) 
plot(blocks, g, vertex.size=.3, vertex.label.cex=0.4, edge.color=rgb(.4,.4,0,.3),layout=l)
title(main="Communities")


###
graph.fileName<-dataset
library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
g<-read_graph(file=as.character(graph.fileName$inputFile[1]),format="graphml")
V(g)$label<-V(g)$id
cl <- maximal.cliques(g)
LCL<-length(cl)
MINC=2

ml<-c(1:LCL)
for (i in c(1:LCL))
{
   ml[i]<-length(cl[[i]])
}
cl1<-cl[ml>MINC]


colbar <- rainbow(length(cl1) + 1)
set.seed(42)
l<-layout.auto(g) 
for (i in 1:length(cl1)) {
  V(g)[cl1[[i]]]$color <- colbar[i+1]
}
plot(g, mark.groups=cl1,vertex.size=.3, vertex.label.cex=0.4, edge.color=rgb(.4,.4,0,.3),layout=l)

title(main=paste("Cliques of size  >",MINC))

###
graph.fileName<-dataset
library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
g<-read_graph(file=as.character(graph.fileName$inputFile[1]),format="graphml")
V(g)$label<-V(g)$id
cl <- largest.cliques(g)
colbar <- rainbow(length(cl) + 1)
set.seed(42)
l<-layout.auto(g) 
for (i in 1:length(cl)) {
  V(g)[cl[[i]]]$color <- colbar[i+1]
}
plot(g, mark.groups=cl,vertex.size=.3, vertex.label.cex=0.4, edge.color=rgb(.4,.4,0,.3),layout=l)

title(main="Largest Cliques")





