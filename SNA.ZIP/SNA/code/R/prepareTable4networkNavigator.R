###############
library(dplyr)

convertNumeric2rgb<-function(nodeColAttrib=c(1,2,3),rgbMin=NULL,rgbMax=NULL)
{
  DEFAULT_NODE_COLOR<-rgb(1,1,0.0,0.7)
  DEFAULT_NODE_COLOR_STR<-"rgb(1,1,0.0)"
  
  mcolors<-array(dim=102)
  rgbcolors<-array(dim=c(102,4))
  resColors<-array(data="",dim=c(length(nodeColAttrib),1))
  
  
  j<-1
  if(is.null(rgbMin))
  {
    for (i in seq(0.2,0.95,length.out = 102))
    {
      mcolors[j]<-rgb(0.1,i,0,0.6)
      rgbcolors[j,]<-c(0.1,i,0,0.6)
      j<-j+1
    }
  } else {
    for (i in seq(0,1,length.out = 102))
    {
      rgbcolors[j,]<-c(rgbMin[1]*i+rgbMax[1]*(1-i),rgbMin[2]*i+rgbMax[2]*(1-i),rgbMin[3]*i+rgbMax[3]*(1-i),0.6)
      mcolors[j]<-rgb(rgbMin[1]*i+rgbMax[1]*(1-i),rgbMin[2]*i+rgbMax[2]*(1-i),rgbMin[3]*i+rgbMax[3]*(1-i),0.6)
      j<-j+1
    }
  }
  rgbcolors<-round(rgbcolors*255)
  #(nodeColAttrib)
  if(min(nodeColAttrib,na.rm=TRUE)!=max(nodeColAttrib,na.rm=TRUE))
  {
    mi<-min(nodeColAttrib,na.rm=TRUE)
    ma<-max(nodeColAttrib,na.rm=TRUE)
    nodeColAttrib<-(nodeColAttrib-mi)/(ma-mi) #normalized in [0,1]
    #assign due to attribute 
    for (i in c(1:length(nodeColAttrib)))
    {
      temp<-round((nodeColAttrib[i])*100)+1 #index in [1,101]
      resColors[i] <- paste("rgb(",rgbcolors[temp,1],",",rgbcolors[temp,2],",",rgbcolors[temp,3],")",sep="")
      #try also
      #resColors[i] <- mcolors[temp]
    }
    
  } else {
    resColors[]<- DEFAULT_NODE_COLOR_STR
  } 
  
  return(resColors)
  
}
##############################
Create3TablesForNetworkNavigator<-function(df4nodes_new,df4edges_sna)
{
  df4edges_sna_new<-df4edges_sna
  NE<-nrow(df4edges_sna)
  NN<-nrow(df4nodes_new)
  # add self-edges only if node is isolated !!!
  for (n in seq(1,NN))
  {
    #
     rowFromTo<-data.frame(E_from=df4nodes_new$V_id[n],E_to=df4nodes_new$V_id[n],weight=0)
     df4edges_sna_new <- bind_rows(df4edges_sna_new, rowFromTo)
  }
  
  #nodesFromTable, nodesToTable, edgesTable
  from_ii<-match(df4edges_sna_new$E_from,df4nodes_new$V_id)
  to_ii<-match(df4edges_sna_new$E_to,df4nodes_new$V_id)
  
  nodesFromTable<-df4nodes_new[from_ii,]
  nodesToTable<-df4nodes_new[to_ii,]
  edgesTable<-df4edges_sna_new
  NE<-nrow(edgesTable)
  
  nodesFromTable$auto_ind<-seq(1,NE)
  nodesToTable$auto_ind<-seq(1,NE)
  edgesTable$auto_ind<-seq(1,NE)
  
  resTables<-list(nodesFromTable,nodesToTable,edgesTable)
  return(resTables)
}


# creates new dataframe good for networkNavigator 
# SourceNode,TargetNode,
# SourceNodeColor,TargetNodeColor for each numeric column of df4nodes
prepareTable4networkNavigator<-function(df4edges_sna,df4nodes)
{
  df4nodes_new<-df4nodes
  
  NE<-nrow(df4edges_sna)
  NN<-nrow(df4nodes)
  
  #add color nodes for each numeric nodes column 
  nna<-names(df4nodes)
  countAdded=0
  
 for (c in seq(1,ncol(df4nodes)))
 {
   if(is.numeric(df4nodes[,c]))
   {
     countAdded<-countAdded+1
     rgbCol<-convertNumeric2rgb(df4nodes[,c])
     df4nodes_new[,ncol(df4nodes_new)+1]<-rgbCol
     names(df4nodes_new)[ncol(df4nodes_new)]<-paste("rgb_",nna[c],sep="")
   }
   
 }
 
  #extend edges table with columns of from to node
  outRes<-Create3TablesForNetworkNavigator(df4nodes_new,df4edges_sna)
  
}

