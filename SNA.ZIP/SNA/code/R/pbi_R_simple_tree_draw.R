source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))

#save(dataset,file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")# for DEBUG
pbi_R_simple_tree_draw<-function(dataset)
{
  eFrom <- dataset$autoNodeID
  eTo <- dataset$autoNodeID.1
  eWeight <- dataset$weight
  vID <- dataset$V_id
  vLabel <- dataset$V_label
  autoNodeID<-dataset$autoNodeID.2
  
  g<-reconstruct_iGraph_from_PBI_columns(eFrom,eTo,eWeight,vID,vLabel,autoNodeID)
  g<-as.directed(g)
  
  my_graph_plot_advanced(g,mylayout=NULL)
}