#get_betw_value_missing_edges
#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\mydebug.Rda")# for DEBUG
get_betw_value_missing_edges<-function(g,ee,tN=NULL)
{
  NR<-nrow(ee)
  #if(is.null(tN))
  #  tN<-seq(1,length(V(g)))
  E(g)$weight=1
  #compute betweenes 
  if(!is.null(tN)){
    btw<-closeness(g,vids=V(g)[tN]) # absolute addition
  } else {
    btw<-mean(closeness(g),na.rm = TRUE) # absolute addition
  }
  
  cB<-rep(0,NR)
  for(r in seq(1,NR))
  {
    r
    g1<-as.undirected(add.edges(g,as.integer(ee[r,])))
    E(g1)$weight=1
    
    if(!is.null(tN)){
      btw1<-closeness(g1,vids=V(g1)[tN]) # absolute addition
    } else {
      btw1<-mean(closeness(g1),na.rm = TRUE) # absolute addition
    }
    remove(g1)
    cB[r]<-btw1-btw
  }
  
  cB_perc<-round(100*cB/btw,digits=2) # percentage addition 
  
  res<-list(cB,cB_perc,btw)
  return(res)
}
