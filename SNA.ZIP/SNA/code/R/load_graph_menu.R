library(igraph)
library(tools)
last_file_name<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\last_file_name.csv",sep="")
FFF=matrix(c("File XML","*.xml","File CSV","*.csv","File graphml","*.graphml","ALL","*.*"),ncol=2,byrow=1)

#read last
 if(file.exists(last_file_name)==FALSE) {
  graphFile<-""
} else {
  graphFile<-read.csv(last_file_name,header=FALSE)
  graphFile<-as.character(graphFile$V1)
}

#attempt to replace
gF<-aaa<-choose.files(default="",caption="Select File or \"Cancel\"",multi=FALSE,filters=FFF,index=3)
if(length(gF)>0)
  graphFile<-gF

if(graphFile!="")
  write.table(graphFile,file=last_file_name,row.names = F,col.names = F)


g<-read_graph(file=graphFile,format=file_ext(graphFile))

vv<-V(g)
ee<-E(g)

#


# node properties
node_betw<-betweenness(g)
node_clos<-closeness(g,mode="all")
node_deg<-degree(g)

node_id<-c(1:length(V(g)))
node_alpha_c<-alpha_centrality(g)
node_page_rank<-page_rank(g)$vector
node_labels<-V(g)$label

graph_nodes<-data.frame(node_id,node_alpha_c,node_page_rank,node_betw,+
                          node_clos,node_deg)


#graph in PBI form: table_nodes,table_edges, adjacency matrix
M<-as_adj(g)
graph.adj_matr<-as.data.frame.matrix(M)

#table_nodes<-data.frame(g.n.vertices)
ee<-ends(g,c(1:length(E(g))))
#table_edges
graph_edges<-as.data.frame.matrix(ee)

graph_fileName<-as.data.frame(graphFile)


vv_attr<-get.vertex.attribute(g)
ee_attr<-get.edge.attribute(g)

graph_edges<-cbind(graph_edges,ee_attr)
graph_nodes<-cbind(graph_nodes,vv_attr)


V(g)$label<-V(g)$id

plot(g)
