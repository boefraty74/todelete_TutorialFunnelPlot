source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\pbi_R_benchmark_comparison4sn.R",sep=""))

#save(dataset,file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
# dbgf<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\debug.Rda",sep="")
# load(file=dbgf)# for DEBUG
pbi_R_benchmark_graph<-function(dataset)
{
 
  par(mar=c(5, 4, 4, 2)/7 + 0.1);
  eFrom <- dataset$autoNodeID
  eTo <- dataset$autoNodeID.1
  eWeight <- dataset$weight
  vID <- dataset$V_id
  vLabel <- dataset$V_label
  autoNodeID<-dataset$autoNodeID.2
  
  g<-reconstruct_iGraph_from_PBI_columns(eFrom,eTo,eWeight,vID,vLabel,autoNodeID)
  g<-as.undirected(g)
  bLF<-paste(Sys.getenv("SNA4PBI_PATH"),"data/benchmark_graphs/benchmark_list1.csv",sep="")
  pbi_R_benchmark_comparison4sn(gr=g,benchListFile=bLF)
}