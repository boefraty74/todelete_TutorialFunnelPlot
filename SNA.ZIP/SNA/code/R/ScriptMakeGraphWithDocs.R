#ScriptMakeGraphWithDocs.R
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\makeGraphWithDocs.R",sep=""))

#read graph
sgraName<-"c:/Users/boefraty/projects/PBI/SNA/data/demo_data/OfficeGraphData/dataset/sGraph.xml"
sg<-read_graph(sgraName,format="graphml")
#sg<-delete.vertices(sg,length(V(sg))) # delete "OUTSIDER"

mygraph<-sg
toshow=TRUE
resList<-makeGraphWithDocs(mygraph=mygraph,toshow=toshow)