library(XLConnect)
library(igraph)

source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))

#######PARAMS
xlsName<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\EV2016.xlsx",sep="")
MIN_SCORE<-2
MIN_UNDIR_WEIGHT<-4
MINC<-3


makeFriendshipMat<-function(aMat,mw=0.75,MIN_UNDIR_WEIGHT=0)
{
  L=ncol(aMat)
  fMat<-aMat*0
  #fMat=pmin(aMat,t(aMat))
  fMat=(aMat+t(aMat))*(1-mw)+pmin(aMat,t(aMat))*mw
  fMat[fMat<MIN_UNDIR_WEIGHT]=0
  return(fMat)
}

my_draw_cliques<-function(g,MINC)
{
  #g - undirected graph (igraph)
  #MINC - minimal size of clique
  cl <- maximal.cliques(g)
  LCL<-length(cl)
  
  l_sna<-mylayout<-layout_with_graphopt(g,mass=30) 
  ml<-c(1:LCL)
  for (i in c(1:LCL))
  {
    ml[i]<-length(cl[[i]])
  }
  cl1<-cl[ml>=MINC]
  
  
  colbar <- rainbow(length(cl1) + 1)
  if(length(cl1)>0)
    for (i in 1:length(cl1)) {
      V(g)[cl1[[i]]]$color <- colbar[i+1]
    }
  par(mar=c(5, 4, 4, 2)/4 + 0.1);
  plot(g, mark.groups=cl1,vertex.size=.3, vertex.label.cex=0.8, edge.color=rgb(.4,.4,0,.3),layout=l_sna)
  title(main=paste("Cliques of size  >=",MINC))
  
}

my_draw_communities<-function(g)
{
  
  
  set.seed(42)
  #l_sna<-layout.fruchterman.reingold(g_sna)
  l_sna<-layout_with_graphopt(g,mass=30) 
  V(g)$label.dist=0.2
  blocks <- cohesive.blocks(g)
  par(mar=c(5, 4, 4, 2)/3 + 0.1);
  plot(blocks, g, vertex.size=3, vertex.label.cex=0.6, 
       edge.color=rgb(.4,.4,0,.3),layout=l_sna,main="Communities")
  
  
  title(main=paste("Communities"))
  
}






to <- readWorksheetFromFile(xlsName,
                            sheet=1,
                            startRow = 2,
                            endRow=27,
                            startCol=1,
                            endCol = 1,
                            header=FALSE)

from <- readWorksheetFromFile(xlsName,
                            sheet=1,
                            startRow = 1,
                            endRow=1,
                            startCol=2,
                            endCol = 43,
                            header=FALSE)

tele_mat <- readWorksheetFromFile(xlsName,
                              sheet=1,
                              startRow = 2,
                              endRow=27,
                              startCol=2,
                              endCol = 43,
                              header=FALSE)

jury_mat <- readWorksheetFromFile(xlsName,
                                  sheet=2,
                                  startRow = 2,
                                  endRow=27,
                                  startCol=2,
                                  endCol = 43,
                                  header=FALSE)


from<-data.frame(t(from),stringsAsFactors = FALSE)
names(from)<-'Country'
names(to)<-'Country'

LFROM<-length(from$Country)
LTO<-length(to$Country)


max_actors<-unique(rbind(from,to))
min_actors<-data.frame(unique(intersect(from$Country,to$Country)))
names(max_actors)<-'Country'
names(min_actors)<-'Country'
L=length(max_actors$Country)

#create adj matrix
fullAdjMatTele<-matrix(0,L,L)
fullAdjMatJury<-matrix(0,L,L)



for(i in seq(1,L))
  for(j in seq(1,L))
  {
   
    #find how much points i gave to j 
    country_i<-max_actors$Country[i]
    country_j<-max_actors$Country[j]
    tempi<-seq(1,LFROM)[!is.na(match(from$Country,country_i))]
    tempj<-seq(1,LTO)[!is.na(match(to$Country,country_j))]
    if(length(tempi)&&length(tempj)&&!is.na(tempi)&&!is.na(tempj))
    {
      print(paste(country_i,' --> ',country_j,':',tele_mat[tempj[1],tempi[1]]))
      if(!is.na(tele_mat[tempj[1],tempi[1]])&&tele_mat[tempj[1],tempi[1]]>=MIN_SCORE)
        fullAdjMatTele[i,j]<-tele_mat[tempj[1],tempi[1]]
      if(!is.na(jury_mat[tempj[1],tempi[1]])&&jury_mat[tempj[1],tempi[1]]>=MIN_SCORE)
        fullAdjMatJury[i,j]<-jury_mat[tempj[1],tempi[1]]
    }    
  }


#create teleG,juryG directed 
library(igraph)
g1 <- graph.adjacency( fullAdjMatTele,mode="directed",weighted=TRUE)
V(g1)$label<-max_actors$Country
plot((g1))

#create undirected
fullAdj=fullAdjMatJury
fullAdj=fullAdjMatTele

friendsMatTele<-makeFriendshipMat(fullAdjMatTele,mw=0.75,MIN_UNDIR_WEIGHT=MIN_UNDIR_WEIGHT)
friendsMatJury<-makeFriendshipMat(fullAdjMatJury,mw=0.75,MIN_UNDIR_WEIGHT=MIN_UNDIR_WEIGHT)

g_tele <- graph.adjacency( friendsMatTele,mode="undirected",weighted=TRUE)
g_jury <- graph.adjacency( friendsMatJury,mode="undirected",weighted=TRUE)

E(g_tele)$color<-"red"
E(g_jury)$color<-"green"


gg<-union(g_tele,g_jury)
E(gg)$color[!is.na(E(gg)$color_1)]=E(gg)$color_1[!is.na(E(gg)$color_1)]
E(gg)$color[!is.na(E(gg)$color_2)]=E(gg)$color_2[!is.na(E(gg)$color_2)]

E(gg)$weight[!is.na(E(gg)$weight_1)]=E(gg)$weight_1[!is.na(E(gg)$weight_1)]
E(gg)$weight[!is.na(E(gg)$weight_2)]=E(gg)$weight_2[!is.na(E(gg)$weight_2)]

V(gg)$label<-max_actors$Country
E(gg)$width<-E(gg)$weight
plot((gg))




#cliques
###

my_draw_cliques(g,MINC)


my_draw_communities(g)


#my_draw_centrality(g)