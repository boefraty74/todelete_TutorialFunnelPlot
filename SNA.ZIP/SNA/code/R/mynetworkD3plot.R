library(igraph)
library(networkD3)

print("mynetworkD3plot.R")

mynetworkD3plot<-function(igra,attrib_node=NULL,outFileName=NULL)
{
  M<-as_adj(igra)
  adj_matr<-as.data.frame.matrix(M)
  #table_nodes<-data.frame(g.n.vertices)
  ee<-ends(igra,c(1:length(E(igra))))
  #table_edges
  table_edges<-as.data.frame.matrix(ee)
  
  net3<-simpleNetwork(table_edges) # funny plot 
  
  if(!is.null(outFileName))
  {
    saveNetwork(net3,file=outFileName,selfcontained = TRUE)
  }
 
  print("done") 
}
