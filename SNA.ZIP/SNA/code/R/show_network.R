library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))

MySelectFontSize<-function(gr,userSize)
{
fs<-7
if(!is.null(userSize))
  return(userSize);

NN<-length(V(gr))
NE<-length(E(gr))

if(NN<25)
  fs<-12
else if (NN<50)
  fs<-10
else if (NN<75)
  fs<-8
else if (NN<100)
  fs<-7
else
  fs<-6
return(fs)

}





userSize=NULL
userLinkDist=66
userOpacity=0.6
userZoom=TRUE

NN<-length(V(g))
EE<-length(E(g))

V(g)$label<-one_word_labels(V(g)$Title)



  userNodeCol<-"green"

ee<-ends(g,c(1:length(E(g))))


Source<-V(g)$label[ee[,1]]
Target<-V(g)$label[ee[,2]]
Value<-E(g)$weight*0
SLinks<-data.frame(Source,Target,Value)

myFontSize<-MySelectFontSize(g,userSize)

# simpn<-simpleNetwork(Data=MLinks,height=NULL,width=NULL,linkDistance = userLinkDist,
#                charge=-200,fontSize=myFontSize,opacity=userOpacity,zoom=userZoom,nodeColour="green",
#                nodeClickColour="green")



indNodes<-seq(0,NN-1)
name<-V(g)$label
ssource<-indNodes[ee[,1]]
ttarget<-indNodes[ee[,2]]
vvalue<-E(g)$weight/max(E(g)$weight)

nname<-V(g)$label
ggroup<-vector(mode = "integer", length = NN)
ggroup[]<-0
ssize<-vector(mode = "integer", length = NN)
ssize[]<-10

MLinks= data.frame(ssource,ttarget,vvalue,stringsAsFactors = F)
MNodes = data.frame(nname,ggroup,ssize,stringsAsFactors = F)

fn<-forceNetwork(Links = MLinks, Nodes = MNodes,
                 Source = "ssource", Target = "ttarget",
                 Value = "vvalue", NodeID = "nname",
                 Group = "ggroup", opacity = 1,
                 legend=T,zoom=T,opacityNoHover=1, fontSize = 10)

fn


saveNetwork(fn,file = 'Net.html')



