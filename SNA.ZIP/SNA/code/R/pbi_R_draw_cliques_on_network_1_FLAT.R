#source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))

#save(dataset,file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")# for DEBUG

#source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
library(igraph)
# source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\my_graph_plot_advanced.R",sep=""))
#my_graph_plot_advanced.R
#label.cex - size of label (1 default)
# label.color - default is black
# edge.width - default is 1

#source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\sparsify_labels_by_layout.R",sep=""))
#decide about which labels to show 
sparsify_labels_by_layout<-function(g,iL,labels=V(g)$label,
                                    lAttribute=NULL,mfactor=1,
                                    minVertDist=1,minHoriDist=2.2) 
{
  minVertDist<-minVertDist*mfactor
  minHoriDist<-minHoriDist*mfactor
  
  NV<-length(V(g))
  if(is.null(lAttribute))
    lAttribute<-sample(1:100,NV,TRUE)
  
  iL_norm<-(iL-min(iL))/(max(iL)-min(iL))
  
  
  DD_H<-as.matrix(dist(iL_norm[,1],method = "manhattan"))
  DD_V<-as.matrix(dist(iL_norm[,2],method = "manhattan"))
  
  #sort labels by attribute 
  ss<-sort(lAttribute,index.return =TRUE)
  tempAttr1<-match(1:NV,ss$ix)
  tempAttr2<-(-abs(tempAttr1-median(tempAttr1)))
  order_imp<-sort(tempAttr2,index.return =TRUE)$ix
  #start from most important and go down
  #update dist matrix and labels
  for (i in order_imp)
  {
    if(!is.na(labels[i]))
    {
      labels<- UpdateDistAndLabels(DD_H,DD_V,labels,i,minVertDist,minHoriDist)
      V(g)$label<-labels
      
      #Sys.sleep(0.1)
    }
  }
  plot(g,layout=iL)
  return(g)
}



##
UpdateDistAndLabels<-function(DD_H,DD_V,labels,i,minVertDist,minHoriDist)
{
  # remove all neighbours
  badH<-(DD_H[i,]<minHoriDist);badH[i]=FALSE
  badV<-(DD_V[i,]<minVertDist);badV[i]=FALSE
  labels[badH & badV]<-NA
  return(labels)
}

if(0){
  #try it 
  par(mar=c(5, 4, 4, 2)/7 + 0.1);
  set.seed(42)
  #g<-random.graph.game(200,0.01)
  g<-read.graph('c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\akatz\\sGraph.xml',
                format='graphml')
  g<-delete.vertices(g,V(g)[length(V(g))])
  NV<-length(V(g))
  #V(g)$label<-paste(1:NV,"_aaa",sep="")
  V(g)$label<-V(g)$Title
  #lAttribute=NULL
  lAttribute<-V(g)$hrank
  iL<-layout.auto(g)
  # 
  # 
  plot(g,layout=iL)
  # 
  ppp<-par()$pin
  mfactor=20/(min(ppp))
  
  g<-sparsify_labels_by_layout(g=g,iL=iL,labels=V(g)$label,
                               lAttribute=lAttribute,mfactor=mfactor,
                               minVertDist=1,minHoriDist=3) 
  
  plot(g,layout=iL)
  
  
}





my_graph_get_show_node_labels<-function(gr,nodeLabel,nodeLabelShowIndicator,parinfo,smart_sparsify_labels,mylayout)
{
  # if graph is overloaded will present only few labels 
  # nodeLabelShowIndicator if NULL => do nothing 
  # if 0 => do not show anything
  # if 1 => show integer indexes
  # nodeLabelShowIndicator => show best and worst automatically 
  if(smart_sparsify_labels)
  {
    
    mfactor<-0.15/min(parinfo$pin)
    if(is.na(mfactor)||is.null(mfactor))
      mfactor<-1
    gr<-sparsify_labels_by_layout(gr,mylayout,lAttribute=nodeLabelShowIndicator,mfactor=mfactor)
    return(gr)
  }
  
  
  
  numNodes<-length(V(gr))
  
  if(is.null(nodeLabelShowIndicator) || numNodes< 12)
    return(gr);
  
  if(length(nodeLabelShowIndicator)==1 && nodeLabelShowIndicator==0)
  {
    V(gr)$label<-NA
    return(gr)
  }
  if(length(nodeLabelShowIndicator)==1 && nodeLabelShowIndicator==1)
  {
    V(gr)$label<-seq(1,length(V(gr)))
    return(gr)
  }
  seder<-sort(nodeLabelShowIndicator,index.return = T)$ix
  
  keepOnly <- 3 #TEMP
  areaSize<-sqrt(prod(parinfo$din))
  areaPerNodeRoot<-sqrt(areaSize/numNodes)# what is an area per node
  
  temp<-as.numeric(as.character(cut(areaPerNodeRoot,
                                    breaks=c(0,0.3,0.5,Inf),
                                    labels=c(0.25,0.5,1))))
  #  print(temp)
  
  keepOnly<-round(temp*numNodes/2)
  
  
  if(keepOnly+1<numNodes-keepOnly)
    V(gr)$label[seder[seq(keepOnly+1,numNodes-keepOnly)]]<-NA
  
  
  
  
  return(gr)
  
}

my_graph_get_edge_width<-function(gr,edgeWidthAttrib,parinfo)
{
  DEW<-1
  if(!is.null(edgeWidthAttrib) && min(edgeWidthAttrib)==max(edgeWidthAttrib))
  {
    DEW=edgeWidthAttrib[1]
    edgeWidthAttrib=NULL
  }
  
  numEdges<-length(E(gr))
  numNodes<-length(V(gr))
  
  areaSize<-sqrt(prod(parinfo$din))
  
  areaPerNodeRoot<-sqrt(areaSize/numNodes)# what is an area per node
  
  temp<-as.numeric(as.character(cut(areaSize,
                                    breaks=c(0,0.1,0.5,1,2,3,4,5,7,10,20,50,Inf),
                                    labels=c(0.1,0.5,2,3,6,7,8,10,11,12,15,20))))
  #print(temp)
  # DEW<-DEW*temp
  DEW<-DEW
  
  if(!is.null(edgeWidthAttrib))
  {
    msizes<-seq(1,9,length.out = 102)*DEW
    mi<-min(edgeWidthAttrib)
    ma<-max(edgeWidthAttrib)
    edgeWidthAttrib<-(edgeWidthAttrib-mi)/(ma-mi)
    #assign due to attribute 
    for (i in c(1:length(E(gr))))
    {
      temp<-round((edgeWidthAttrib[i])*100)
      E(gr)[i]$width <- msizes[temp+1]
    }
  }
  else
  {
    E(gr)[]$width <- DEW
  }
  
  return(gr)
  
}

my_graph_get_node_rad<-function(gr,nodeRadAttrib,parinfo)
{
  DNR<-0.85
  
  if(!is.null(nodeRadAttrib) && min(nodeRadAttrib)==max(nodeRadAttrib))
  {
    DNR=nodeRadAttrib[1]
    nodeRadAttrib=NULL
  }
  
  numNodes<-length(V(gr))
  areaSize<-sqrt(prod(parinfo$din))
  
  areaPerNodeRoot<-sqrt(areaSize/numNodes)# what is an area per node
  
  temp<-as.numeric(as.character(cut(areaSize,
                                    breaks=c(0,0.1,0.5,1,2,3,4,5,7,10,20,50,Inf),
                                    labels=c(0.1,0.5,2,3,6,7,8,10,11,12,15,20))))
  #print(temp)
  DNR<-DNR*temp
  
  
  if(!is.null(nodeRadAttrib))
  {
    msizes<-seq(0.3,1.4,length.out = 102)*DNR
    mi<-min(nodeRadAttrib)
    ma<-max(nodeRadAttrib)
    nodeRadAttrib<-(nodeRadAttrib-mi)/(ma-mi)
    #assign due to attribute 
    for (i in c(1:length(V(gr))))
    {
      temp<-round((nodeRadAttrib[i])*100)
      V(gr)[i]$size <- msizes[temp+1]
    }
  }
  else
  {
    V(gr)[]$size <- DNR
  }
  
  return(gr)
}
###########
my_graph_get_node_color<-function(gr,nodeColAttrib,nodeColor,parinfo)
{
  DEFAULT_NODE_COLOR<-rgb(1,1,0.0,0.7)
  mcolors<-array(dim=100)
  j<-1
  for (i in seq(0.2,0.95,length.out = 102))
  {
    mcolors[j]<-rgb(0.1,i,0,0.6)
    j<-j+1
  }
  #(nodeColAttrib)
  if(!is.null(nodeColAttrib) && min(nodeColAttrib)!=max((nodeColAttrib)))
  {
    mi<-min(nodeColAttrib)
    ma<-max(nodeColAttrib)
    nodeColAttrib<-(nodeColAttrib-mi)/(ma-mi)
    #assign due to attribute 
    for (i in c(1:length(V(gr))))
    {
      temp<-round((nodeColAttrib[i])*100)
      V(gr)[i]$color <- mcolors[temp+1]
      
    }
    
  }
  else
  {
    if(is.null(nodeColor)) 
      V(gr)[]$color <- DEFAULT_NODE_COLOR
    else
      V(gr)$color<-nodeColor
  } 
  return(gr)
}

##########
my_graph_get_node_label<-function(gr,nodeLabel,parinfo)
{
  # nodeLabel=NA #TEMP
  DEFAULT_NODE_LABEL<-NA
  DEFAULT_NODE_LABEL_FONT_COLOR<-rgb(0.6, 0.05, .0, .8)
  
  if(!is.null(nodeLabel))
    V(gr)$label<-nodeLabel
  
  V(gr)$label.color <- DEFAULT_NODE_LABEL_FONT_COLOR
  
  return(gr)
}

##################
my_graph_get_node_label_size<-function(gr,nodeLabelSizeAttrib,parinfo)
{
  DEFAULT_NODE_LABEL_SIZE <- 0.1
  
  DNLS <- DEFAULT_NODE_LABEL_SIZE
  
  if(!is.null(nodeLabelSizeAttrib) && min(nodeLabelSizeAttrib)==max(nodeLabelSizeAttrib))
  {
    DNLS=nodeLabelSizeAttrib[1]
    nodeLabelSizeAttrib=NULL
  }
  
  numNodes<-length(V(gr))
  areaSize<-sqrt(prod(parinfo$din))
  
  areaPerNodeRoot<-sqrt(areaSize/numNodes)# what is an area per node
  
  temp<-as.numeric(as.character(cut(areaSize,
                                    breaks=c(0,0.1,0.5,1,2,3,4,5,7,10,20,50,Inf),
                                    labels=c(2.1,2.2,2.5,4,6,7,8,9,10,12,15,20))))
  
  #print(temp)
  
  DNLS<-DNLS*temp
  
  
  if(!is.null(nodeLabelSizeAttrib))
  {
    msizes<-seq(0.2,2,length.out = 102)*DNLS
    mi<-min(nodeLabelSizeAttrib)
    ma<-max(nodeLabelSizeAttrib)
    nodeLabelSizeAttrib<-(nodeLabelSizeAttrib-mi)/(ma-mi)
    #assign due to attribute 
    for (i in c(1:length(V(gr))))
    {
      temp<-round((nodeLabelSizeAttrib[i])*100)
      V(gr)[i]$label.cex <- nsizes[temp+1]
    }
  }
  else
  {
    V(gr)[]$label.cex <- DNLS
  }
  
  return(gr)
  
}
################
##################
#  my_graph_plot_advanced 
##################
##################
my_graph_plot_advanced<-function(gr,nodeRadAttrib=NULL,nodeColAttrib=NULL,
                                 nodeLabelShowIndicator=NULL,
                                 nodeLabel=NULL,nodeLabelSizeAttrib=NULL,
                                 nodeGroupIndicator=NULL, nodeColor=NULL,
                                 edgeColorAttrib=NULL,edgeWidthAttrib=NULL,edgeTypeAttrib=NULL,
                                 mylayout=layout.auto(gr),
                                 stam=NULL,
                                 smart_sparsify_labels=FALSE)
{
  if(is.null(nodeLabelShowIndicator))
    nodeLabelShowIndicator<-nodeRadAttrib #TEMP
  
  DEFAULT_NODE_SHAPE<-"circle"
  
  DEFAULT_EDGE_WIDTH<-1
  DEFAULT_EDGE_LABEL<-1
  DEFAULT_EDGE_COLOR<-rgb(0.1, 0.1, 0.1, .8)
  
  PARINFO<-par()#PARINFO$din
  PARINFO$side<-sqrt(prod(PARINFO$din))
  
  numNodes<-length(V(gr))
  numEdges<-length(E(gr))
  
  if(is.null(mylayout))
  {
    if(is.directed(gr))
      mylayout <-layout.reingold.tilford(gr,root=1) # good for tree
    else
      #mylayout<-layout_with_kk(gr,kkconst = vcount(gr))# not good for disconnected 
      mylayout<-layout_with_graphopt(gr,mass=30) 
    # mylayout<-layout_nicely(gr)
    #mylayout<-layout.fruchterman.reingold(gr)#
    
  }
  
  # set nodeRad
  gr<-my_graph_get_node_rad(gr,nodeRadAttrib,PARINFO)
  # set nodeColor
  gr<-my_graph_get_node_color(gr,nodeColAttrib,nodeColor,PARINFO)
  
  #TODO: set nodeShape
  #set nodeLabel
  gr<-my_graph_get_node_label(gr,nodeLabel,PARINFO)
  
  
  
  #set nodeLabelSize
  gr<-my_graph_get_node_label_size(gr,nodeLabelSizeAttrib,PARINFO)
  
  
  #set sparse label
  gr<-my_graph_get_show_node_labels(gr,nodeLabel,nodeLabelShowIndicator,PARINFO,smart_sparsify_labels,mylayout)
  
  #set edgeWidth
  gr<-my_graph_get_edge_width(gr,edgeWidthAttrib,PARINFO)
  
  
  
  #TODO: set edgeLabel
  #TODO: set edgeColor
  
  
  
  
  
  #  E(gr)$curved=F
  
  V(gr)$frame.color <- NA # no frame on node
  # V(gr)$label<-NA
  
  if(is.directed(gr))
    plot(gr,vertex.color=V(gr)$color,layout=mylayout,asp=0)
  else
    plot(gr,vertex.color=V(gr)$color,layout=mylayout,asp=1)
  
}

my_simplify<-function(gr)
{
  gr<-simplify(gr)
  #remove isolated
  d<-degree(gr)
  isol<-seq(1,length(V(gr)))[d==0]
  gr<-delete.vertices(gr,isol)
  return(gr)
}


my_get_all_edge_attr<-function(g,index)
{
  forAllEdges<-get.edge.attribute(g)
  res<-list()
  count=1
  for(n in names(forAllEdges))
  {
    res<-append(res,list(forAllEdges[[count]][index]))  
    count=count+1
  }
  names(res)<-names(forAllEdges)
  return(res)
}



my_graph_plot<-function(gr,attrib_node,mylayout)
{
  #generate 100 colors black to white
  mcolors<-array(dim=100)
  j<-1
  for (i in seq(0,1,0.01))
  {
    mcolors[j]<-rgb(0,i,0,0.8)
    j<-j+1
  }
  mi<-min(attrib_node)
  ma<-max(attrib_node)
  #assign due to attribute 
  for (i in c(1:length(V(gr))))
  {
    temp<-round(((attrib_node[i]-mi)/(ma-mi))*100)
    V(gr)[i]$color <- mcolors[temp+1]
  }
  V(gr)$label.cex <- 0.5 * attrib_node / ma+ .3
  V(gr)$label.color <- rgb(0.8, 0.2, .0, .8)
  V(gr)$frame.color <- NA
  #plot 
  plot(gr, vertex.color=V(gr)$color,vertex.label=V(gr)$number,layout=mylayout)
}

############################
one_word_labels<-function(la)
{
  L=length(la)
  res<-la
  fff<-strsplit(la," ")
  for(i in c(1:L))
  {
    res[i]<-fff[[i]][1]
    
  }
  return(res)
}

my_graph_plot<-function(gr,attrib_node,mylayout)
{
  #generate 100 colors black to white
  mcolors<-array(dim=100)
  j<-1
  for (i in seq(0,1,0.01))
  {
    mcolors[j]<-rgb(0,i,0,0.8)
    j<-j+1
  }
  mi<-min(attrib_node)
  ma<-max(attrib_node)
  #assign due to attribute 
  for (i in c(1:length(V(gr))))
  {
    temp<-round(((attrib_node[i]-mi)/(ma-mi))*100)
    V(gr)[i]$color <- mcolors[temp+1]
  }
  V(gr)$label.cex <- 0.5 * attrib_node / ma+ .3
  V(gr)$label.color <- rgb(0.8, 0.2, .0, .8)
  V(gr)$frame.color <- NA
  #plot 
  plot(gr, vertex.color=V(gr)$color,vertex.label=V(gr)$number,layout=mylayout)
}
#######################
my_graph_plot_advanced_old<-function(gr,nodeRadAttrib=NULL,nodeColAttrib=NULL,nodeLabel=NULL,
                                     edgeColorAttrib=NULL,edgeWidthAttrib=NULL,edgeTypeAttrib=NULL,
                                     nodeGroupIndicator=NULL, nodeColor=NULL,
                                     mylayout=layout.auto(gr))
{
  
  if(is.null(mylayout))
  {
    if(is.directed(gr))
      mylayout <-layout.reingold.tilford(gr,root=1) # good for tree
    else
      mylayout<-layout.fruchterman.reingold(gr)
    #mylayout<-layout.spring(gr) # almost like f-r
    #mylayout<-layout.lgl(gr)
    
  }
  
  DEFAULT_NODE_COLOR<-rgb(1,1,0.0,0.7)
  DEFAULT_FONT_COLOR<-rgb(0.6, 0.05, .0, .8)
  DEFAULT_NODE_RAD<-3
  
  mcolors<-array(dim=100)
  j<-1
  for (i in seq(0.2,0.95,length.out = 102))
  {
    mcolors[j]<-rgb(0.1,i,0,0.6)
    j<-j+1
  }
  #print(nodeColAttrib)
  if(!is.null(nodeColAttrib) && min(nodeColAttrib)!=max((nodeColAttrib)))
  {
    mi<-min(nodeColAttrib)
    ma<-max(nodeColAttrib)
    nodeColAttrib<-(nodeColAttrib-mi)/(ma-mi)
    #assign due to attribute 
    for (i in c(1:length(V(gr))))
    {
      temp<-round((nodeColAttrib[i])*100)
      V(gr)[i]$color <- mcolors[temp+1]
      print(temp)
    }
    
  }
  else
  {
    if(is.null(nodeColor)) 
      V(gr)[]$color <- DEFAULT_NODE_COLOR
    else
      V(gr)$color<-nodeColor
  } 
  
  
  if(!is.null(nodeLabel))
    V(gr)$label<-nodeLabel
  
  
  V(gr)$label.color <- DEFAULT_FONT_COLOR
  V(gr)$frame.color <- NA # no frame on node
  
  if(is.directed(gr))
    plot(gr,vertex.color=V(gr)$color,layout=mylayout,asp=0)
  else
    plot(gr,vertex.color=V(gr)$color,layout=mylayout)
  
}
############################
#source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))
reconstruct_iGraph_from_PBI_columns<-function(eFrom,eTo,eWeight=NULL,vID,vLabel=NULL,autoNodeID)
{
  # eFrom = vID of "from" vertex
  # eTo = vID of "to" vertex
  # eWeight = weight of edge (if null will be replaced by 1)
  # vID = unique IDs of vertices 
  # vLabel = unique strings for vertices "to show", (if NULL will be replaced by vID)
  #autoNodeID = 1,2,3,...
  
  
  #TODO: WORKS WRING IF SOME autoNodeID is missing 
  NV<-length(unique(vID))
  NE<-length(eFrom)
  
  
  
  if(is.null(eWeight)){
    eWeight<-rep(1,NE)
  }
  if(is.null(vLabel)){
    vLabel<-vID
  }
  
  u<-data.frame(vID,vLabel,autoNodeID,stringsAsFactors = F)
  u<-unique(u)
  u<-u[order(u$autoNodeID),]
  
  myIDs<-seq(1,NV)
  names(myIDs)<-as.character(u$autoNodeID)
  
  #g<-graph.empty(n=NV, directed=FALSE)
  #add.vertices(g, myIDs[vID])
  #add.edges(g,as.vector(rbind(myIDs[eFrom],myIDs[eTo])))
  
  #eedges<-as.numeric(as.vector(rbind(myIDs[eFrom],myIDs[eTo])))
  eFromTo<-rbind(eFrom,eTo)
  
  NC<-  ncol(eFromTo)
  keepEdges<-rep(1,NC)
  for (c in seq(1,NC))
    keepEdges[c]<-prod(is.element(eFromTo[,c],u$autoNodeID))
  
  eFromTo<-eFromTo[,as.logical(keepEdges)]
  eedges<-as.numeric(as.vector(eFromTo))
  
  #selectedEdges<-seq(1,NC)
  #selectedEdges<-selectedEdges[as.logical(keepEdges)]
  
  
  
  #g<-graph(eedges,n=max(eedges), directed=F)
  g<-graph(as.character(eedges))
  
  
  #Order rows in u such that autoNodeID coinsides with names(V(g))
  uu<-u[myIDs[names(V(g))],]
  
  
  
  V(g)$label<-as.character(uu$vLabel)
  V(g)$id<-as.character(uu$vID)
  
  g<-simplify(g)
  
  
  #TODO: find selected edges 
  sho<-paste(ends(g,E(g))[,1],ends(g,E(g))[,2],sep="_")
  lo<-paste(eFrom,eTo,sep="_")
  selectedEdges<-match(sho,lo)
  
  
  g$selectedEdges<-selectedEdges
  g$selectedNodes<-match(V(g)$id,as.character(vID))
  
  E(g)$weight<-eWeight[selectedEdges]
  
  
  return(g)
}


pbi_R_draw_cliques_on_network_1<-function(dataset,tit=NULL,MINC=NULL)
{
  #source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))
  
  #dataset$nodeColAttrib<-dataset$V_coreness
  #pbi_R_graph_draw_with_attributes(dataset)
  
  eFrom <- dataset$autoNodeID
  eTo <- dataset$autoNodeID.1
  eWeight <- dataset$weight
  vID <- dataset$V_id
  vLabel <- dataset$V_label
  autoNodeID<-dataset$autoNodeID.2
  
  g_sna<-reconstruct_iGraph_from_PBI_columns(eFrom,eTo,eWeight,vID,vLabel,autoNodeID)
  g_sna<-as.undirected(g_sna)
  set.seed(42)
  #l_sna<-layout.fruchterman.reingold(g_sna)
  l_sna<-mylayout<-layout_with_graphopt(g_sna,mass=30) 
  
  #cliques
  ###
  cl <- maximal.cliques(g_sna)
  LCL<-length(cl)
  if(is.null(MINC))
    MINC=5
  
  ml<-c(1:LCL)
  for (i in c(1:LCL))
  {
    ml[i]<-length(cl[[i]])
  }
  cl1<-cl[ml>MINC]
  
  
  colbar <- rainbow(length(cl1) + 1)
  if(length(cl1)>0)
    for (i in 1:length(cl1)) {
      V(g_sna)[cl1[[i]]]$color <- colbar[i+1]
    }
  par(mar=c(5, 4, 4, 2)/4 + 0.1);
  plot(g_sna, mark.groups=cl1,vertex.size=.3, vertex.label.cex=0.8, edge.color=rgb(.4,.4,0,.3),layout=l_sna)
  
  if(is.null(tit))
    title(main=paste("Cliques of size  >",MINC))
  else
    title(main=tit)
  
  #largest cliques
  
 # cl <- largest.cliques(g_sna)
#  colbar <- rainbow(length(cl) + 1)
  
 # for (i in 1:length(cl)) {
#    V(g_sna)[cl[[i]]]$color <- colbar[i+1]
 # }
#  plot(g_sna, mark.groups=cl,vertex.size=.3, vertex.label.cex=0.5, edge.color=rgb(.4,.4,0,.3),layout=l_sna)
  
#  title(main=paste("Largest Cliques of size",length(cl[[1]])))
  
  
 
  
  
 
}
