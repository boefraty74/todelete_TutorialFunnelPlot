#reconstruct_iGraph_from_columns

eFrom <- df4edges_sna_from_PBI$E_from
eTo <- df4edges_sna_to_PBI$E_to
eWeight <- df4edges_sna_prop_PBI$weight
vID <- df4nodes_PBI$V_id
vLabel <- df4nodes_PBI$V_label
autoNodeID<-

reconstruct_iGraph_from_columns<-function(eFrom,eTo,eWeight=NULL,vID,vLabel=NULL)
{
  # eFrom = vID of "from" vertex
  # eTo = vID of "to" vertex
  # eWeight = weight of edge (if null will be replaced by 1)
  # vID = unique IDs of vertices 
  # vLabel = unique strings for vertices "to show", (if NULL will be replaced by vID)
  
  NV<-length(vID)
  NE<-length(eFrom)
  
  myIDs<-seq(1,NV)
  names(myIDs)<-vID
  
  if(is.null(eWeight)){
    eWeight<-rep(1,NE)
  }
  if(is.null(vLabel)){
    vLabel<-vID
  }
  
  #g<-graph.empty(n=NV, directed=FALSE)
  #add.vertices(g, myIDs[vID])
  #add.edges(g,as.vector(rbind(myIDs[eFrom],myIDs[eTo])))
  
  eedges<-as.numeric(as.vector(rbind(myIDs[eFrom],myIDs[eTo])))
  g<-graph(eedges,n=max(eedges), directed=F)
  
  V(g)$label<-as.character(vLabel)
  V(g)$id<-as.character(vID)
  E(g)$weight<-eWeight
  return(g)
}