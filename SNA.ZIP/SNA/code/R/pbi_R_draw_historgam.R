source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))

#save(dataset,file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")# for DEBUG
pbi_R_draw_historgam<-function(dataset,tit=NULL)
{
  source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\pbi_R_graph_draw_with_attributes.R",sep=""))
  set.seed(42)
  if(is.null(tit))
    tit<-paste("Histogram of ",names(dataset)[1])
 # par(mar=c(5,3,2,2)+0.1)
  hist(dataset[,1],main=tit,ylab="count",xlab=names(dataset)[1],col="yellow")
  
}