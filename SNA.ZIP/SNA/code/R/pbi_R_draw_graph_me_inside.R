source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))

#save(dataset,file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")# for DEBUG
pbi_R_draw_graph_me_inside<-function(dataset)
{
  DEFAULT_NODE_COLOR<-rgb(1,1,0.0,0.5)
  DEFAULT_MYNODE_COLOR<-rgb(0,1,0.0,0.9)
  
  
  source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
  #find wich one of dataset$V1[1],dataset$V1[2],dataset$V1[3] is sGraph
  snaFile<-as.character(dataset$V1[1])
  if(length(grep("sGraph",as.character(dataset$V1[2])))>0)
    snaFile<-as.character(dataset$V1[2])
  if(length(grep("sGraph",as.character(dataset$V1[3])))>0)
    snaFile<-as.character(dataset$V1[3])
  
  
  myPropFile<-as.character(dataset$V1[1])
  if(length(grep(".csv",as.character(dataset$V1[2])))>0)
    myPropFile<-as.character(dataset$V1[2])
  if(length(grep(".csv",as.character(dataset$V1[3])))>0)
    myPropFile<-as.character(dataset$V1[3])
  
  t<-read.csv(myPropFile)
  
  
  
  g_sna_with_outsider<-read_graph(file=snaFile,format="graphml")
  Lp1<-length(V(g_sna_with_outsider))
  g_sna<-delete.vertices(g_sna_with_outsider,V(g_sna_with_outsider)[Lp1])
  
  nodeColor1=rep(DEFAULT_NODE_COLOR,length(V(g_sna)))
  myInd<-NULL
  for(i in seq(1,length(V(g_sna))))
    if(V(g_sna)$id[i]==as.character(t[1]))
    {
      nodeColor1[i]<-DEFAULT_MYNODE_COLOR
      myInd<-i
    }
  
  
  set.seed(42)
  par(mar=c(5, 4, 4, 2)/7 + 0.1);
  
  nodeLabelShowIndicator<-V(g_sna)$numDirects
  nodeLabelShowIndicator[myInd]<-max(nodeLabelShowIndicator)+1
  
    my_graph_plot_advanced(g_sna,nodeLabel=one_word_labels(V(g_sna)$Title),
                           nodeColor=nodeColor1,mylayout = NULL,
                           nodeLabelShowIndicator=nodeLabelShowIndicator,smart_sparsify_labels=TRUE)
  title(main="My location in the group")
}