library(igraph)

source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\dataEdges.R",sep=""))
#should run after reading in graphs with outsider

# inputFile_company<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\hGraph.xml"
# inputFile_company_sna<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\sGraph.xml"
# 
# g_sna_with_outsider<-read_graph(file=inputFile_company_sna,format="graphml")
# g_tree_with_outsider<-read_graph(file=inputFile_company,format="graphml")

computeDataFrame4sgraph<-function(g_sna_with_outsider,g_tree_with_outsider)
{
Lp1<-length(V(g_sna_with_outsider))

g_sna<-delete.vertices(g_sna_with_outsider,V(g_sna_with_outsider)[Lp1])
g_tree<-delete.vertices(g_tree_with_outsider,V(g_tree_with_outsider)[Lp1])

LLL<-length(V(g_sna))


V(g_sna)$label<-one_word_labels(V(g_sna)$Title)
V(g_tree)$label<-one_word_labels(V(g_tree)$Title)

snaWeight<-E(g_sna)$weight
g_sna_uniform<-g_sna
E(g_sna_uniform)$weight<-1

#E(g_sna)$weight<-snaWeight

V_id<-V(g_sna)$id
V_label<-V(g_sna)$label
V_name<-V(g_sna)$Title
V_degree<-degree(g_sna,mode="all")
V_degree_with_outsider<-degree(g_sna_with_outsider,mode="all")
V_height<-V(g_sna)$hrank
V_pageRank<-page_rank(g_sna_uniform)$vector
V_betw<-betweenness(g_sna_uniform)
V_centr<-closeness(g_sna_uniform,mode="all")
V_centr_tree<-closeness(g_tree,mode="all")
V_coreness<-graph.coreness(g_sna,mode="all")
V_numCollegues<-V(g_sna)$numCollegues
V_numDirects<-V(g_sna)$numDirects
V_numRecentlyModified<-V(g_sna)$RecentlyModifiedCount
V_ModifiedTitles<-V(g_sna)$ModifiedTitles
V_TrendingTitles<-V(g_sna)$TrendingTitles
V_Years<-V(g_sna)$Years
if(is.null(V_Years))
  V_Years<-V_numDirects


zzz<-V_height*0
V_total_weight<-zzz
V_ratio_up<-zzz
V_ratio_down<-zzz
V_ratio_samelevel<-zzz
V_ratio_outside<-zzz

adj_list_g_sna<- get.adjlist(g_sna)
adj_list_g_sna_with_outsider<- get.adjlist(g_sna_with_outsider)


for (v in c(1:LLL))
{
  V_total_weight[v]<-sum(E(g_sna_with_outsider)[from(v)]$weight)
  V_ratio_up[v]<-sum(V(g_sna)$hrank[adj_list_g_sna[[v]]]<V(g_sna)$hrank[v])
  V_ratio_down[v]<-sum(V(g_sna)$hrank[adj_list_g_sna[[v]]]>V(g_sna)$hrank[v])
  V_ratio_samelevel[v]<-sum(V(g_sna)$hrank[adj_list_g_sna[[v]]]==V(g_sna)$hrank[v])
  ttt<-get.edge.ids(g_sna_with_outsider, c(v,Lp1), directed = FALSE, error = FALSE, multi = FALSE)
  #print(ttt)
  if(ttt>0)
  {
    V_ratio_outside[v]<-E(g_sna_with_outsider)$weight[ttt]/V_total_weight[v]
  }
  
}

temp<-V_ratio_up+V_ratio_down+V_ratio_samelevel
V_ratio_up<-V_ratio_up/temp
V_ratio_down<-V_ratio_down/temp
V_ratio_samelevel<-V_ratio_samelevel/temp

#DATA.FRAME for nodes
df4nodes<-as.data.frame(cbind(V_id,V_label,V_name),stringsAsFactors =FALSE)
df4nodes$V_degree <- V_degree
df4nodes$V_height <- V_height
df4nodes$V_pageRank <- V_pageRank
df4nodes$V_betw <- V_betw
df4nodes$V_centr <-V_centr 
df4nodes$V_centr_tree <-V_centr_tree 
df4nodes$V_ratio_up <-V_ratio_up 
df4nodes$V_ratio_down <-V_ratio_down 
df4nodes$V_ratio_samelevel <-V_ratio_samelevel 
df4nodes$V_ratio_outside <-V_ratio_outside 
df4nodes$V_total_weight <-V_total_weight 
df4nodes$V_coreness <-V_coreness 
df4nodes$V_numCollegues <-V_numCollegues
df4nodes$V_numDirects <-V_numDirects
df4nodes$V_numRecentlyModified<-V_numRecentlyModified
df4nodes$V_ModifiedTitles<-V_ModifiedTitles
df4nodes$V_TrendingTitles<-V_TrendingTitles
df4nodes$V_Years <-V_Years

#df4nodes with outsider
df4nodes_with_outsider<-df4nodes
numRows<-length(df4nodes[,1])
df4nodes_with_outsider[numRows,]=df4nodes_with_outsider[1,]
df4nodes_with_outsider[numRows+1,]$V_id=-100
df4nodes_with_outsider[numRows+1,]$V_label="OUTSIDER"
df4nodes_with_outsider[numRows+1,]$V_name="OUTSIDER"
df4nodes_with_outsider$V_degree_with_outsider<-V_degree_with_outsider
df4nodes_with_outsider[numRows+1,]$V_degree<-0

#DATA.FRAME for edges
df4edges_sna<-dataEdges(g_sna)
df4edges_tree<-dataEdges(g_tree)
df4edges_sna_with_outsider<-dataEdges(g_sna_with_outsider)

#DATA.FRAME for each graph
fileName_graph_sna<-as.data.frame(inputFile_company_sna)
fileName_graph_tree<-as.data.frame(inputFile_company_tree)

df4graph_sna<-as.data.frame(graph.attributes(g_sna))
df4graph_tree<-as.data.frame(graph.attributes(g_tree))


resultList<-list(df4nodes,df4edges_sna,df4edges_tree,df4edges_sna_with_outsider,
                 fileName_graph_sna,fileName_graph_tree,df4graph_sna,
                 df4graph_tree,df4nodes_with_outsider)

return(resultList)

}




