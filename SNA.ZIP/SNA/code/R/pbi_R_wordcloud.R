library(wordcloud)
library(tm)
library(stringr)

#dbgf<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\debug.Rda",sep="")
#load(file=dbgf)# for DEBUG
pbi_R_wordcloud<-function(dataset)
{
  myColumn<-dataset[,1]#first column  
  #TODO: remove some words  
  pal <- brewer.pal(9,"YlGnBu")
  pal <- pal[-(1:4)]
  wordcloud(myColumn,scale=c(5,0.1), max.words=Inf, random.order=FALSE, rot.per=0.35, use.r.layout=FALSE,min.freq=2,colors=pal)
}
