#pbi_R_connector.R
#copy into connector
#source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\pbi_R_connector.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\computeDataFrame4sgraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\ConvertGraphData2formatPBI.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\prepareTable4networkNavigator.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\makeGraphWithDocs.R",sep=""))


myFile <- file.choose()
#get name of directory
myData  <- read.csv(myFile,header=FALSE,stringsAsFactors = FALSE)

# TODO: 
# paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\computeDataFrame4sgraph.R",sep="")
myData$V1[1]<-paste(Sys.getenv("SNA4PBI_PATH"),myData$V1[1],sep="")
myData$V1[2]<-paste(Sys.getenv("SNA4PBI_PATH"),myData$V1[2],sep="")
myData$V1[3]<-paste(Sys.getenv("SNA4PBI_PATH"),myData$V1[3],sep="")


inputFile_company_sna<-myData$V1[1]
inputFile_company_tree<-myData$V1[2]

persData<-read.csv(myData$V1[3],header=TRUE,stringsAsFactors = FALSE)

g_sna_with_outsider<-read_graph(file=inputFile_company_sna,format="graphml")
g_tree_with_outsider<-read_graph(file=inputFile_company_tree,format="graphml")

listRes<-computeDataFrame4sgraph(g_sna_with_outsider,g_tree_with_outsider)
#df4nodes,df4edges_sna,df4edges_tree,df4edges_sna_with_outsider,
#fileName_graph_sna,fileName_graph_tree,df4graph_sna,df4graph_tree
df4nodes<-listRes[[1]]
df4edges_sna<-listRes[[2]]
df4edges_tree<-listRes[[3]]
df4edges_sna_with_outsider<-listRes[[4]]
fileName_graph_sna<-listRes[[5]]
fileName_graph_tree<-listRes[[6]]
df4graph_sna<-listRes[[7]]
df4graph_tree<-listRes[[8]]
df4nodes_with_outsider<-listRes[[9]]

#NetworkNavigatorFormat
nnf<-prepareTable4networkNavigator(df4edges_sna,df4nodes)
nnfTableFrom<-nnf[[1]]
nnfTableTo<-nnf[[2]]
nnfTableEdges<-nnf[[3]]
class(nnfTableFrom)<-"data.frame"
class(nnfTableTo)<-"data.frame"
class(nnfTableEdges)<-"data.frame"


#PBI format  
listRes_sna4PBI<-ConvertGraphData2formatPBI(df4nodes,df4edges_sna)

df4nodes_PBI<-listRes_sna4PBI[[1]]
df4edges_sna_from_PBI<-listRes_sna4PBI[[2]]
df4edges_sna_to_PBI<-listRes_sna4PBI[[3]]
df4edges_sna_prop_PBI<-listRes_sna4PBI[[4]]


listRes_tree4PBI<-ConvertGraphData2formatPBI(df4nodes,df4edges_tree)
df4edges_tree_from_PBI<-listRes_tree4PBI[[2]]
df4edges_tree_to_PBI<-listRes_tree4PBI[[3]]
df4edges_tree_prop_PBI<-listRes_tree4PBI[[4]]



listRes_sna_w_outsider_4PBI<-ConvertGraphData2formatPBI(df4nodes_with_outsider,df4edges_sna_with_outsider)
df4nodes_with_outsider_PBI<-listRes_sna_w_outsider_4PBI[[1]]
df4edges_with_outsider_sna_from_PBI<-listRes_sna_w_outsider_4PBI[[2]]
df4edges_with_outsider_sna_to_PBI<-listRes_sna_w_outsider_4PBI[[3]]
df4edges_with_outsider_sna_prop_PBI<-listRes_sna_w_outsider_4PBI[[4]]
#detach("package:dplyr", unload=TRUE)



#documents
mygraph=g_sna_with_outsider
toshow=FALSE
resListDoc<-makeGraphWithDocs(mygraph=mygraph,toshow=toshow)
dfnn_mygraph_modi<-resListDoc$dfnn_mygraph_modi
dfnn_mygraph_trend<-resListDoc$dfnn_mygraph_trend
dfnn_mygraph_trend_sna<-resListDoc$dfnn_mygraph_trend_sna
dfnn_mygraph_modi_sna<-resListDoc$dfnn_mygraph_modi_sna
dfnn_mygraph_people_n_docs<-resListDoc$dfnn_mygraph_people_n_docs


# class(dfnn_mygraph_modi)<-"data.frame"
# class(dfnn_mygraph_trend)<-"data.frame"
# class(dfnn_mygraph_people_n_docs)<-"data.frame"

if(is.null(dfnn_mygraph_modi)){
  dfnn_mygraph_modi=data.frame()
}else{
  class(dfnn_mygraph_modi)<-"data.frame"
}
if(is.null(dfnn_mygraph_trend)){
  dfnn_mygraph_trend=data.frame()
}else{
  class(dfnn_mygraph_trend)<-"data.frame"
}
if(is.null(dfnn_mygraph_people_n_docs)){
  dfnn_mygraph_people_n_docs=data.frame()
}else{
  class(dfnn_mygraph_people_n_docs)<-"data.frame"
}


if(is.null(dfnn_mygraph_trend_sna)){
  dfnn_mygraph_trend_sna=data.frame()
}else{
  class(dfnn_mygraph_trend_sna)<-"data.frame"
}
if(is.null(dfnn_mygraph_modi_sna)){
  dfnn_mygraph_modi_sna=data.frame()
}else{
  class(dfnn_mygraph_modi_sna)<-"data.frame"
}


class(dfnn_mygraph_modi_sna)<-"data.frame"


df4nodes_ME<-df4nodes[df4nodes$V_id==persData$ActorID,]

#add to each datafame extra column for future use
df4nodes$forFutureUse = 0
df4edges_sna$forFutureUse = 0
df4edges_tree$forFutureUse = 0
df4edges_sna_with_outsider$forFutureUse = 0
df4nodes_with_outsider$forFutureUse = 0

df4nodes_PBI$forFutureUse = 0
df4edges_sna_prop_PBI$forFutureUse = 0

df4edges_tree_prop_PBI$forFutureUse = 0

df4nodes_with_outsider_PBI$forFutureUse = 0
df4edges_with_outsider_sna_prop_PBI$forFutureUse = 0

#rm(fileName_graph_sna)
#rm(fileName_graph_tree)
#rm(df4edges_sna)
#rm(df4edges_tree)
#rm(df4edges_sna_with_outsider)
#rm(df4nodes)
#rm(df4nodes_with_outsider)

class(df4edges_tree_from_PBI)<-"data.frame"
class(df4edges_sna_from_PBI)<-"data.frame"
class(df4edges_with_outsider_sna_from_PBI)<-"data.frame"

class(df4edges_tree_to_PBI)<-"data.frame"
class(df4edges_sna_to_PBI)<-"data.frame"
class(df4edges_with_outsider_sna_to_PBI)<-"data.frame"


class(df4edges_tree_prop_PBI)<-"data.frame"
class(df4edges_sna_prop_PBI)<-"data.frame"
class(df4edges_with_outsider_sna_prop_PBI)<-"data.frame"


class(df4nodes_ME)<-"data.frame"



