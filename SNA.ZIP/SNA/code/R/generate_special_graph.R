#generate special graphs
library(igraph)
generate_special_graph<-function(nE,nV,gTitle)
{
  #gTitle is one of: Isolated, A-team, Mafia, Family
  g<-NULL
  #Isolated = maximally isolated with nE and nV
  if(gTitle=="Isolated")
  {
    nVF<-round(sqrt(nE*2))+1# vertices in full graph
    
    g <- erdos.renyi.game(nVF, p.or.m=nE, type="gnm");
    g<-add.vertices(g,nV-nVF)
  }
  
  
  
  #A-team load from file (TEMP)
  if(gTitle=="A-team" || gTitle=="A-Team")
  {
    gfn<-paste(Sys.getenv("SNA4PBI_PATH"),"data/benchmark_graphs/my_perfect.xml",sep="")
    g<-read_graph(gfn,format="graphml")
  }
  #Mafia = star + random
  if(gTitle=="Mafia" || gTitle=="Autocracy" )
  {
    g<-as.undirected(graph.star(nV))
    #add nE-nV-1 random vertices 
    if(nE-nV-1>0)
    {
      ee<-round(runif(2*(nE-nV-1), 2-0.5, nV+0.5))
      g<-simplify(add.edges(g,ee))
    }
  }
  
  
  #Familia = random
  if(gTitle=="Family")
    g <- erdos.renyi.game(nV, p.or.m=nE, type="gnm");
  
  
  
  
  return(g)
  
  
  
}
