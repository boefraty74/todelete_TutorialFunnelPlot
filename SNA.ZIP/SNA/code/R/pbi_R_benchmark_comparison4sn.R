source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\my_compare_two_graphs.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\generate_special_graph.R",sep=""))
library(fmsb)

#dbgf<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\debug.Rda",sep="")
#load(file=dbgf)# for DEBUG
pbi_R_benchmark_comparison4sn<-function(gr,benchListFile=NULL)
{
  if(is.null(benchListFile))
    benchListFile<-paste(Sys.getenv("SNA4PBI_PATH"),"data/benchmark_graphs/benchmark_list1.csv",sep="")
  bl<-read.csv(benchListFile,header = T,stringsAsFactors=F)
  NR<-nrow(bl)
  nE<-length(E(gr))
  nV<-length(V(gr))
  dists<-rep(0,NR)
  for(r in seq(1,NR))
  {
    #gr2<- read_graph(bl$fileName[r],format="graphml")
    gTitle<-bl$title[r]
    print(gTitle)
    gr2<- generate_special_graph(nE,nV,gTitle)
    temp<-my_compare_two_graphs(gr,gr2,params=NULL)
    dists[r]<-temp[[1]]
  }
  
 # dists<-max(dists)-dists
#  dists<-100*dists/sum(dists)
  dists<-100*dists/sum(dists)
  dists<- 100-dists
  dists<-100*dists/sum(dists)
  
  
   
  slices <- dists
  lbls <- bl$title
  pct <- round((slices)/sum(slices)*100)
  lbls <- paste(lbls, pct) # add percents to labels 
  lbls <- paste(lbls,"%",sep="") # ad % to labels 
  pie(slices[slices>0],labels = lbls[slices>0], col=rainbow(length(lbls)),
      main="Similarity to benchmark networks")
  
  

#   radarDF<-data.frame(t(cbind(0,100,slices[slices>0])))
#   radarchart(df=radarDF,maxmin=F,centerzero = T,vlabels=lbls[slices>0])
  
}
