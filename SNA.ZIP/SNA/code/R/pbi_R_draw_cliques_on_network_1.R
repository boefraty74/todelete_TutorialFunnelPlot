source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))

#save(dataset,file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")# for DEBUG
pbi_R_draw_cliques_on_network_1<-function(dataset,tit=NULL,MINC=NULL)
{
  source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))
  
  #dataset$nodeColAttrib<-dataset$V_coreness
  #pbi_R_graph_draw_with_attributes(dataset)
  
  eFrom <- dataset$autoNodeID
  eTo <- dataset$autoNodeID.1
  eWeight <- dataset$weight
  vID <- dataset$V_id
  vLabel <- dataset$V_label
  autoNodeID<-dataset$autoNodeID.2
  
  g_sna<-reconstruct_iGraph_from_PBI_columns(eFrom,eTo,eWeight,vID,vLabel,autoNodeID)
  g_sna<-as.undirected(g_sna)
  set.seed(42)
  #l_sna<-layout.fruchterman.reingold(g_sna)
  l_sna<-mylayout<-layout_with_graphopt(g_sna,mass=30) 
  
  #cliques
  ###
  cl <- maximal.cliques(g_sna)
  LCL<-length(cl)
  if(is.null(MINC))
    MINC=5
  
  ml<-c(1:LCL)
  for (i in c(1:LCL))
  {
    ml[i]<-length(cl[[i]])
  }
  cl1<-cl[ml>MINC]
  
  
  colbar <- rainbow(length(cl1) + 1)
  if(length(cl1)>0)
    for (i in 1:length(cl1)) {
      V(g_sna)[cl1[[i]]]$color <- colbar[i+1]
    }
  par(mar=c(5, 4, 4, 2)/4 + 0.1);
  plot(g_sna, mark.groups=cl1,vertex.size=.3, vertex.label.cex=0.8, edge.color=rgb(.4,.4,0,.3),layout=l_sna)
  
  if(is.null(tit))
    title(main=paste("Cliques of size  >",MINC))
  else
    title(main=tit)
  
  #largest cliques
  
 # cl <- largest.cliques(g_sna)
#  colbar <- rainbow(length(cl) + 1)
  
 # for (i in 1:length(cl)) {
#    V(g_sna)[cl[[i]]]$color <- colbar[i+1]
 # }
#  plot(g_sna, mark.groups=cl,vertex.size=.3, vertex.label.cex=0.5, edge.color=rgb(.4,.4,0,.3),layout=l_sna)
  
#  title(main=paste("Largest Cliques of size",length(cl[[1]])))
  
  
 
  
  
 
}
