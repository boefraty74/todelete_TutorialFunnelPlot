#makeGraphWithDocs.R
library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\prepareSimpleTable4networkNavigator.R",sep=""))


# returns string w/o leading or trailing whitespace
trim <- function (x) gsub("^\\s+|\\s+$", "", x)


stringDocs2Vector<-function(tempStr)
{
  x=strsplit(tempStr, ";")
  x=x[[1]]
  x=sapply(x,trim)
  x=x[x!=""]
  x=unique(x)
  return(x)
}

my_simplify1<-function(gr)
{
  gr<-simplify(gr)
  #remove isolated
  d<-degree(gr)
  isol<-seq(1,length(V(gr)))[d==0]
  gr<-delete.vertices(gr,isol)
  return(gr)
}

fold_the_nodes<-function(gr,nodeInds=NULL)
{
  gr1<-gr
  if(is.null(nodeInds) && length(V(gr)>1))
  {
    nodeInds=seq(1,length(V(gr)))
  }
    
    for (nodeInd in nodeInds)
    {
      #connect nodes between each other
      ae<-as.vector(adjacent_vertices(gr,nodeInd,mode="all")[[1]])
      #add edges between each two
      
      if(length(ae)>2){
        ee<-as.vector(combn(ae,2))
        gr1<-add.edges(gr1,ee,weight=1)
        
      }
    
    }  
    gr1<-delete.vertices(gr1,nodeInds);
    gr1<-simplify(gr1, edge.attr.comb=list(weight="sum",e_type="last"))
    plot(nodeInd)
  
  return(gr1)
}

# mygraph is a social graph without outsider
makeGraphWithDocs<-function(mygraph,toshow=FALSE)
{
  rgbHuman<- rgb(0.9,0.3,0.3) # almost red
  rgbTrend<- rgb(0,1,0) # green
  rgbModi<- rgb(0.0,0.9,0.9) # bluish
  
  
  
  # create new graph with 2 types of nodes + 3 types of edges 
  V(mygraph)$v_type<-"person" # or "document" 
  E(mygraph)$e_type<-"social" # or "modify", "trend"
  V(mygraph)$label<-one_word_labels(V(mygraph)$Title)
  V(mygraph)$color<- rgbHuman
  # generate list of documents 
  
  temp1<-V(mygraph)$ModifiedTitles
  temp1<-cbind(temp1,V(mygraph)$TrendingTitles)
  temp2=temp1[temp1!="unknown"]
  
  
  
  allDocs<-NULL
  ci=1
  for (t in temp2)
  {
    #   x=strsplit(t, ";")
    #   x=x[[1]]
    #   x=sapply(x,trim)
    #   x=x[x!=""]
    x<-stringDocs2Vector(t)
    allDocs<-append(allDocs,x)
  }
  allDocs<-unique(allDocs)
  # add documents as nodes
  NP<-length(V(mygraph))
  ND<-length(allDocs)
  
  mygraph1<-add.vertices(mygraph,ND)# add empty vertices for docs
  
  if(ND)
  {
    V(mygraph1)$Title[seq(NP+1,NP+ND)]<-allDocs
    V(mygraph1)$v_type[seq(NP+1,NP+ND)]<-"document"
    V(mygraph1)$color[seq(NP+1,NP+ND)]<-rgbTrend
    
    V(mygraph1)$label[seq(NP+1,NP+ND)]<-as.character(seq(1,ND))
    
    # add connectivity 
    for (n in seq(1,NP))
    { 
      
      stringModified<-V(mygraph1)$ModifiedTitles[n]
      stringTrend<-V(mygraph1)$TrendingTitles[n]
      
      vecModified<-stringDocs2Vector(stringModified)
      vecTrend<-stringDocs2Vector(stringTrend)
      
      #match elements in vectors 
      iTrend<-match(vecTrend,allDocs)
      iModi<-match(vecModified,allDocs)
      if(is.na(iTrend[1])){
        iTrend=NULL}
      if(is.na(iModi[1])){
        iModi=NULL}
      
      #create edges
      ee<-NULL # trend
      for (i in seq(from=1,length.out=length(iTrend)))
      {
        #edge between node n and doc[iTrend[i]]= iTrend[i]+NP
        ee<-rbind(ee,c(n,iTrend[i]+NP))
      }
      if(!is.null(ee))
      {
        mygraph1<-add.edges(mygraph1,as.vector(t(ee)),weight=1,e_type="trend")
        for(ie in seq(from=1,length.out=nrow(ee)))
        {
          if(V(mygraph1)$color[ee[ie,2]]!=rgbModi)
            V(mygraph1)$color[ee[ie,2]]<-rgbTrend
        }
       
      }
      ee<-NULL # modi
      for (i in seq(from=1,length.out=length(iModi)))
      {
        #edge between node n and doc[iTrend[i]]= iTrend[i]+NP
        ee<-rbind(ee,c(n,iModi[i]+NP))
      }
      if(!is.null(ee))
      {
        mygraph1<-add.edges(mygraph1,as.vector(t(ee)),weight=1,e_type="modify")
        V(mygraph1)$color[ee[,2]]<-rgbModi
      }
      print(n)
    }
  }
  NE<-length(E(mygraph1))
  #modi and trend
  mygraph_people_n_docs<-mygraph1
  mygraph_people_n_docs<-my_simplify1(mygraph_people_n_docs)
  
  #modi
  mygraph_modi<-delete.edges(mygraph1,seq(from=1,length.out=NE)[E(mygraph1)$e_type!="modify"])
  mygraph_modi<-simplify(mygraph_modi)
  
  #trend
  mygraph_trend<-delete.edges(mygraph1,seq(from=1,length.out=NE)[E(mygraph1)$e_type!="trend"])
  mygraph_trend<-simplify(mygraph_trend)
  
  #
  gr=mygraph_trend; nodeInds=seq(1,NP)
  mygraph_trend_sna<-fold_the_nodes(mygraph_trend,seq(1,NP))
  mygraph_trend_sna<-my_simplify1(mygraph_trend_sna)
  
  mygraph_modi_sna<-fold_the_nodes(mygraph_modi,seq(1,NP))
  mygraph_modi_sna<-my_simplify1(mygraph_modi_sna)
  
  
  #convert to tables for visual 
  mygraph_modi<-my_simplify1(mygraph_modi)
  mygraph_trend<-my_simplify1(mygraph_trend)
  
  
  dfnn_mygraph_modi<-prepareSimpleTable4networkNavigator(mygraph_modi)
  dfnn_mygraph_trend<-prepareSimpleTable4networkNavigator(mygraph_trend)
  dfnn_mygraph_trend_sna<-prepareSimpleTable4networkNavigator(mygraph_trend_sna)
  dfnn_mygraph_modi_sna<-prepareSimpleTable4networkNavigator(mygraph_modi_sna)
  dfnn_mygraph_people_n_docs<-prepareSimpleTable4networkNavigator(mygraph_people_n_docs)
  
  resList<-list(dfnn_mygraph_modi=dfnn_mygraph_modi,
                dfnn_mygraph_trend=dfnn_mygraph_trend,
                dfnn_mygraph_trend_sna=dfnn_mygraph_trend_sna,
                dfnn_mygraph_modi_sna=dfnn_mygraph_modi_sna,
                dfnn_mygraph_people_n_docs=dfnn_mygraph_people_n_docs)
  
  
  
  if(toshow)
  {
    # show social ONLY
    #mygraph
    my_graph_plot_advanced(mygraph)
    title("Social Network")
    
    # show documents and people + edges modify   
    my_graph_plot_advanced(my_simplify1(mygraph_modi),nodeColor=V(mygraph_modi)$color)
    title("Documents modified")
    
    
    # show documents and people + edges trend   
    my_graph_plot_advanced(my_simplify1(mygraph_trend),nodeColor=V(mygraph_trend)$color)
    title("Documents trending around")
    
    
    #social life of documents
    my_graph_plot_advanced(my_simplify1(mygraph_trend_sna),nodeColor=V(mygraph_trend_sna)$color)
    title("Documents trending SN")
    
    my_graph_plot_advanced(my_simplify1(mygraph_modi_sna),nodeColor=V(mygraph_modi_sna)$color)
    title("Documents modified SN")
  } 
  
  
  
  return(resList)
}
