source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))

#save(dataset,file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")# for DEBUG
pbi_R_graph_draw_with_attributes<-function(dataset)
{
  eFrom <- dataset$autoNodeID
  eTo <- dataset$autoNodeID.1
  eWeight <- dataset$weight
  vID <- dataset$V_id
  vLabel <- dataset$V_label
  autoNodeID<-dataset$autoNodeID.2
  
  g<-reconstruct_iGraph_from_PBI_columns(eFrom,eTo,eWeight,vID,vLabel,autoNodeID)
  g<-as.undirected(g)
  
  nodeColAttrib1<-dataset$nodeColAttrib
  #sort 
 # u<-data.frame(vID,vLabel,autoNodeID,nodeColAttrib1,stringsAsFactors = F)
#  u<-unique(u)
#  u<-u[order(u$autoNodeID),]
  
  
  
  V(g)$label.dist=0
  V(g)$label.degree=-pi/2
  #my_graph_plot_advanced(g,mylayout=NULL,nodeColAttrib=u$nodeColAttrib)
  my_graph_plot_advanced(g,mylayout=NULL,nodeColAttrib=nodeColAttrib1[g$selectedNodes],
                         nodeRadAttrib = nodeColAttrib1[g$selectedNodes],
                         smart_sparsify_labels = TRUE)
}