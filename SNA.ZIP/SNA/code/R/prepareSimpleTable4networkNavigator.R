#convert igraph to table for networkNavigator

#TEMP
#mygraph=mygraph_modi
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))

prepareSimpleTable4networkNavigator<-function(mygraph)
{
  resDF=NULL
  if(length(V(mygraph))<=1) return(resDF)
  
  ava<-get.vertex.attribute(mygraph)
  vnames<-names(ava)
  
  aea<-get.edge.attribute(mygraph)
  enames<-names(aea)
  
  
  NE<-length(E(mygraph))
  NV<-length(V(mygraph))
  
  edgelist<-get.edgelist(mygraph)
  
  #sourceNodeLabel | targetNodeLabel | allEdgeProps | allNodeProps
  resDF=data.frame(myEdgeID=seq(1,NE))
  resDF=cbind(resDF,indVertFrom=edgelist[,1],indVertTo=edgelist[,2])
  # get all properties of edges 
  for (pe in seq(1,length(aea)))
  {
    resDF=cbind(resDF,aea[[pe]])
    colnames(resDF)[ncol(resDF)] <- enames[pe]
  }
  #get all properties of nodes 
  for (pn in seq(1,length(ava)))
  {
    # copy properties of node FROM 
    resDF=cbind(resDF,ava[[pn]][edgelist[,1]])
    colnames(resDF)[ncol(resDF)] <- paste("FROM_",vnames[pn],sep="")
    
    # copy properties of node TO 
    resDF=cbind(resDF,ava[[pn]][edgelist[,2]])
    colnames(resDF)[ncol(resDF)] <- paste("TO_",vnames[pn],sep="")
    
  }
  return(resDF)
}

