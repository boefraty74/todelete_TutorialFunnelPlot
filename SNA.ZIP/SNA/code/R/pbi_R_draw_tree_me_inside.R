source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))

#save(dataset,file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")# for DEBUG
pbi_R_draw_tree_me_inside<-function(dataset)
{
  DEFAULT_NODE_COLOR<-rgb(1,1,0.0,0.5)
  DEFAULT_MYNODE_COLOR<-rgb(0,1,0.0,0.9)
  
  
  source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
  #find wich one of dataset$V1[1],dataset$V1[2],dataset$V1[3] is sGraph
  treeFile<-as.character(dataset$V1[1])
  if(length(grep("hGraph",as.character(dataset$V1[2])))>0)
    treeFile<-as.character(dataset$V1[2])
  if(length(grep("hGraph",as.character(dataset$V1[3])))>0)
    treeFile<-as.character(dataset$V1[3])
  
  
  myPropFile<-as.character(dataset$V1[1])
  if(length(grep(".csv",as.character(dataset$V1[2])))>0)
    myPropFile<-as.character(dataset$V1[2])
  if(length(grep(".csv",as.character(dataset$V1[3])))>0)
    myPropFile<-as.character(dataset$V1[3])
  
  t<-read.csv(myPropFile)
  
  
  
  g_tree_with_outsider<-read_graph(file=treeFile,format="graphml")
  Lp1<-length(V(g_tree_with_outsider))
  g_tree<-delete.vertices(g_tree_with_outsider,V(g_tree_with_outsider)[Lp1])
  
  nodeColor1=rep(DEFAULT_NODE_COLOR,length(V(g_tree)))
  myInd<-NULL
  for(i in seq(1,length(V(g_tree))))
    if(V(g_tree)$id[i]==as.character(t[1]))
    {
      nodeColor1[i]<-DEFAULT_MYNODE_COLOR
      myInd<-i
      break
    }
  
  par(mar=c(5, 4, 4, 2)/8 + 0.1)
  set.seed(42)
  nodeLabelShowIndicator<-V(g_tree)$hrank+runif(length(V(g_tree)))
  nodeLabelShowIndicator[myInd]<-1000
  
    my_graph_plot_advanced(g_tree,nodeLabel=one_word_labels(V(g_tree)$Title),
                           nodeColor=nodeColor1,mylayout = NULL,
                           nodeLabelShowIndicator=nodeLabelShowIndicator,smart_sparsify_labels=TRUE)
  
    
    
    
    title(main="My location in the group hierarchy")
}