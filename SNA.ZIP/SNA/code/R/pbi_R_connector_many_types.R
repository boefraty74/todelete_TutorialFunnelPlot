#pbi_R_connector_many_types.R
#copy or source this code into connector

#should work for files of type: edgelist(txt),pajek,ncol,graphml(xml),dimacs,gml,dl 
#the extension of the file should be correct 

#### USER PARAMS #######
COMPUTE_VERTEX_DEGREE = TRUE #will add stat_vDegree column
COMPUTE_VERTEX_BETWEENNESS = TRUE #will add stat_vBetweenness column
COMPUTE_VERTEX_CLOSENESS = TRUE#will add stat_vCloseness column
COMPUTE_VERTEX_CORENESS = TRUE#will add stat_vCoreness column
COMPUTE_VERTEX_PAGE_RANK = TRUE#will add stat_vPageRank column
COMPUTE_VERTEX_CONNECTED_COMPONENT = TRUE#will add stat_vConnComp column
COMPUTE_VERTEX_MAX_CLIQUE = TRUE#will add stat_vCliques column with max clique membership

####Library  and source declarations #############
library(tools)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\computeDataFrame4igraph.R",sep=""))


###########Internal parameters definitions###############

MIN_CLIQUE_SIZE=NULL # for example 3 (NULL is default)
MAX_CLIQUE_SIZE=NULL # for example 7 (NULL is maximal possible)


###########Internal functions definitions###############
my_read_graph<-function(fileName,format=NA,...)
{
 #should work for : edgelist(txt),pajek,ncol,graphml(xml),dimacs,gml,dl 
  ext<-tolower(file_ext(fileName))
  if(is.na(format))
    format=ext
  
  eee<-c("edgelist","txt")# --> "edgelist"
  if(sum(!is.na(match(eee,ext))))
    format=eee[1]
  
  eee<-c("pajek","net")# --> "pajek"
  if(sum(!is.na(match(eee,ext))))
    format=eee[1]
  
  eee<-c("graphml","xml")# --> "graphml"
  if(sum(!is.na(match(eee,ext))))
    format=eee[1]
  
  
  g<-read_graph(file=fileName,format=format)
  
  #if no weights provided assign weight=1 for all
  if(!length(names(edge.attributes(g))))
    E(g)$weight=1
  
  return(g)
}

###########input correctness validations ####


############ Main connector script ###########

#replace by any file name (full path)
myFile <- file.choose() #opens dialog




g_sna<-my_read_graph(file=myFile)
listRes<-computeDataFrame4igraph(g_sna)

df4nodes<-listRes[[1]]
df4edges<-listRes[[2]]
df4graph<-listRes[[3]]


#compute whatever extra properties for graph nodes and graph edges on demand
ean=tolower(names(edge.attributes(g_sna)))
NN=length(V(g_sna))
weights=NULL
temp<-match(c("weight","width"),ean)
if(sum(!is.na(temp)))
{
  iw<-(temp[!is.na(temp)])[1]
  weights<-edge.attributes(g_sna)[[iw]]
}

if(COMPUTE_VERTEX_DEGREE)
  df4nodes$stat_vDegree<-degree(g_sna)

if(COMPUTE_VERTEX_BETWEENNESS)
  df4nodes$stat_vBetweenness<-betweenness(g_sna,directed=is.directed(g_sna),weights=weights)

if(COMPUTE_VERTEX_CONNECTED_COMPONENT)
  df4nodes$stat_vConnComp<-components(g_sna)$membership

if(COMPUTE_VERTEX_CLOSENESS)
  df4nodes$stat_vCloseness<-closeness(g_sna,weights=weights,normalized = TRUE)

if(COMPUTE_VERTEX_CORENESS)
  df4nodes$stat_vCoreness<-coreness(g_sna)

if(COMPUTE_VERTEX_PAGE_RANK)
  df4nodes$stat_vPageRank<-page_rank(g_sna,weights = weights)$vector

if(COMPUTE_VERTEX_MAX_CLIQUE)
{
  mc<-max_cliques(g_sna, min = MIN_CLIQUE_SIZE, max = MAX_CLIQUE_SIZE)
  stat_vMaxClique<-rep(0,NN)
  for (i in seq(1,length.out=length(mc)))
    stat_vMaxClique[as.vector(mc[[i]])]=length(as.vector(mc[[i]]))
  df4nodes$stat_vMaxClique<-stat_vMaxClique
}

df4nodes_From<-df4nodes
df4nodes_To<-df4nodes
remove("df4nodes")

