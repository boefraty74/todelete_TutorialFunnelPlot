source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))

#save(dataset,file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")# for DEBUG
pbi_R_draw_hlevel<-function(dataset)
{
  source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\pbi_R_graph_draw_with_attributes.R",sep=""))
  set.seed(42)
  dataset$nodeColAttrib<-(-dataset$V_height)
  par(mar=c(5, 4, 4, 2)/7 + 0.1);
  pbi_R_graph_draw_with_attributes(dataset)
  title(main=paste("Level in hierarchy on top of Social Network"))
}