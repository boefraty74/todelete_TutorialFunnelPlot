source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))

#save(dataset,file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")# for DEBUG
pbi_R_draw_organization<-function(dataset)
{
  source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\pbi_R_graph_draw_with_attributes.R",sep=""))
  set.seed(42)
  dataset$nodeColAttrib<-NULL
  pbi_R_graph_draw_with_attributes(dataset)
  title(main=paste("Social Network"))
}