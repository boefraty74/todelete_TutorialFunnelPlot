source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\get_betw_value_missing_edges.R",sep=""))


#save(dataset,file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")# for DEBUG
pbi_R_reccomend_org_centr<-function(dataset)
{
  set.seed(42)
  MAX_NEE<-750
  source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
  #find wich one of dataset$V1[1],dataset$V1[2],dataset$V1[3] is sGraph
  snaFile<-as.character(dataset$V1[1])
  if(length(grep("sGraph",as.character(dataset$V1[2])))>0)
    snaFile<-as.character(dataset$V1[2])
  if(length(grep("sGraph",as.character(dataset$V1[3])))>0)
    snaFile<-as.character(dataset$V1[3])
  
  myPropFile<-as.character(dataset$V1[1])
  if(length(grep(".csv",as.character(dataset$V1[2])))>0)
    myPropFile<-as.character(dataset$V1[2])
  if(length(grep(".csv",as.character(dataset$V1[3])))>0)
    myPropFile<-as.character(dataset$V1[3])
  
  
  
  g_sna_with_outsider<-read_graph(file=snaFile,format="graphml")
  Lp1<-length(V(g_sna_with_outsider))
  g_sna<-delete.vertices(g_sna_with_outsider,V(g_sna_with_outsider)[Lp1])
  
  
  g<-g_sna
  
  ee<-matrix(nrow=0,ncol=2)
  for (tN in 1:length(V(g)))
  {
    av<-as.vector(adjacent_vertices(g,tN,mode="all")[[1]])
    non_av<-setdiff(seq(1,length(V(g))),av)
    ee1<-cbind(rep(tN,length(non_av)),non_av)
    ff<-ee1[,1]<ee1[,2]
    ee1<-ee1[ff,]
    ee<-rbind(ee,ee1)
  }
  #TODO: leave only up to 2000 random edges 
  NEE<-nrow(ee)
  
  if(NEE>MAX_NEE)
  {
    iii<-sample(seq(1,NEE),MAX_NEE)
    ee<-ee[iii,]
  }
  res<-get_betw_value_missing_edges(g=g,ee=ee,tN=NULL)
  
  absChange<-res[[1]]
  relChange<-res[[2]]
  
  sortedChange<-sort(relChange,decreasing = TRUE,index.return = TRUE)
  
  
  par(mar = c(0,0,0,0))
  plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')
  
  text(x = 0.1, y = 0.9, paste("RECOMMENDATION: Connections to improve organization \n  CENTRALITY in the social network"), 
       cex = 1.0, col = "black", family="serif", font=2, adj=0)
  
  
  sss<-""
  for(i in 1:min(10,nrow(ee)))
  {
    sss<-paste(sss,"\n",
               V(g)$Title[ee[sortedChange$ix[i],1]],
               "--",
               V(g)$Title[ee[sortedChange$ix[i],2]],
               sortedChange$x[i],"%")
    
    
  }
  
  
  text(x = 0.1, y = 0.4, sss, 
       cex = 1.0, col = "gray30", family="sans", font=1, adj=0)
  
  
  
  
  
  
}

