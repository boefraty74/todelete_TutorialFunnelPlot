#read graph and get from there all titles
#and save them to CSV file 

##### FILE NAMES
hfname<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\orenw\\hGraph.xml"
sfname<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\orenw\\sGraph.xml"


csvTitlesMapAno<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\orenw\\Titles_map_anonymus.csv"
csvTitles<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\orenw\\Titles.csv"

ano_hfname<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\anonym\\hGraph.xml"
ano_sfname<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\demo_data\\OfficeGraphData\\anonym\\sGraph.xml"



######### READ Titles ############
library(igraph)

g<-read_graph(file=hfname,format="graphml")
V(g)$Title
Title<-V(g)$Title
write.csv(Title,file=csvTitles)






##########       #######
anonymusMap<-read.csv(file=csvTitlesMapAno,sep=",")

g<-read_graph(file=hfname,format="graphml")
Title<-anonymusMap$anonym
V(g)$Title<-as.character(Title)
write_graph(graph=g,file=ano_hfname,format="graphml")

g<-read_graph(file=sfname,format="graphml")
Title<-anonymusMap$anonym
V(g)$Title<-as.character(Title)
write_graph(graph=g,file=ano_sfname,format="graphml")



