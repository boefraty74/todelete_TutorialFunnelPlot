library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
g<-read_graph(file=as.character(graph.fileName$inputFile[1]),format="graphml")
V(g)$label<-V(g)$id
g.n.clos<-closeness(g,mode="all")

set.seed(42)
l<-layout.auto(g) 
my_graph_plot(g,g.n.clos,l);title(main="Closeness")


#####

graph.fileName<-dataset
library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
g<-read_graph(file=as.character(graph.fileName$inputFile[1]),format="graphml")
V(g)$label<-V(g)$id
g.n.betw<-betweenness(g)

set.seed(42)
l<-layout.auto(g) 
my_graph_plot(g,g.n.betw,l);title(main="Betweenness")

####

library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
g<-read_graph(file=as.character(graph.fileName$inputFile[1]),format="graphml")
V(g)$label<-V(g)$id
g.n.page_rank<-page_rank(g)$vector

set.seed(42)
l<-layout.auto(g) 
my_graph_plot(g,g.n.page_rank,l);title(main="Page Rank")

####

library(igraph)
source("C:\\Users\\boefraty\\projects\\PBI\\SNA\\code\\utils_igraph.R")
g<-read_graph(file=as.character(graph.fileName$inputFile[1]),format="graphml")
V(g)$label<-V(g)$id
blocks <- cohesive.blocks(g)
set.seed(42)
l<-layout.auto(g) 
plot(blocks, g, vertex.size=.3, vertex.label.cex=0.4, edge.color=rgb(.4,.4,0,.3),layout=l)
title(main="Communities")


###
graph.fileName<-dataset
library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
g<-read_graph(file=as.character(graph.fileName$inputFile[1]),format="graphml")
V(g)$label<-V(g)$id
cl <- maximal.cliques(g)
LCL<-length(cl)
MINC=2

ml<-c(1:LCL)
for (i in c(1:LCL))
{
   ml[i]<-length(cl[[i]])
}
cl1<-cl[ml>MINC]


colbar <- rainbow(length(cl1) + 1)
set.seed(42)
l<-layout.auto(g) 
for (i in 1:length(cl1)) {
  V(g)[cl1[[i]]]$color <- colbar[i+1]
}
plot(g, mark.groups=cl1,vertex.size=.3, vertex.label.cex=0.4, edge.color=rgb(.4,.4,0,.3),layout=l)

title(main=paste("Cliques of size  >",MINC))

###
graph.fileName<-dataset
library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
g<-read_graph(file=as.character(graph.fileName$inputFile[1]),format="graphml")
V(g)$label<-V(g)$id
cl <- largest.cliques(g)
colbar <- rainbow(length(cl) + 1)
set.seed(42)
l<-layout.auto(g) 
for (i in 1:length(cl)) {
  V(g)[cl[[i]]]$color <- colbar[i+1]
}
plot(g, mark.groups=cl,vertex.size=.3, vertex.label.cex=0.4, edge.color=rgb(.4,.4,0,.3),layout=l)

title(main="Largest Cliques")





