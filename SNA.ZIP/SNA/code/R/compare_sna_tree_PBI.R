library(igraph)
source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))

inputFile_company_tree<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\hGraph.xml",sep="")

inputFile_company_sna<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\sGraph.xml",sep="")

g_sna_with_outsider<-read_graph(file=inputFile_company_sna,format="graphml")
g_tree_with_outsider<-read_graph(file=inputFile_company_tree,format="graphml")

Lp1<-length(V(g_sna_with_outsider))
g_sna<-delete.vertices(g_sna_with_outsider,V(g_sna_with_outsider)[Lp1])
g_tree<-delete.vertices(g_tree_with_outsider,V(g_tree_with_outsider)[Lp1])
LLL<-length(V(g_sna))


V(g_sna)$label<-one_word_labels(V(g_sna)$Title)
V(g_tree)$label<-one_word_labels(V(g_tree)$Title)

snaWeight<-E(g_sna)$weight
E(g_sna)$weight<-1

tree.clos<-closeness(g_tree,mode="all")
sna.clos<-closeness(g_sna,mode="all")
myEps<- 1e-15

tree.clos_norm<-(tree.clos-min(tree.clos)+myEps)/(max(tree.clos)-min(tree.clos)+myEps)
sna.clos_norm<-(sna.clos-min(sna.clos)+myEps)/(max(sna.clos)-min(sna.clos)+myEps)

clos_conflict_abs<- abs(tree.clos_norm-sna.clos_norm)
clos_conflict_direction<- sign(tree.clos_norm-sna.clos_norm)


soaa<-sort(clos_conflict_abs, index.return = TRUE,decreasing = TRUE)
lala<-V(g_sna)$label
sorted_labels<-lala[soaa$ix]
sorted_conflicts<-soaa$x
sorted_conflict_direction<-clos_conflict_direction[soaa$ix]
colors1<-vector(mode="character", length=LLL)
colors1[sorted_conflict_direction==-1]<-"green"
colors1[sorted_conflict_direction==1]<-"red"

LL=min(10,round(length(soaa$x)/2))
ii1<-c(1:LL)
ii2<-seq(length(soaa$x)-LL+1,length(soaa$x))        
ind2show<-c(ii1,ii2)

par(mfrow=c(1,1))

barplot(sorted_conflicts[ind2show],names.arg=sorted_labels[ind2show] ,cex.names=0.5,main="Largest and smallset  gaps of Closeness",
        xlab= "Name",
        ylab= "Gap in closeness",
        col=colors1[ind2show]
)


# plot(tree.clos_norm,sna.clos_norm,
#      main= "\"Hierarchy Closeness\" vs. \"Closeness in Social Network\" ",
#      xlab= "Position in company hierarchy (norm.)",
#      ylab= "Closeness in social network (norm.)",
#      col= "blue", pch = 19, cex = 1, lty = "solid", lwd = 2)
# text(tree.clos,sna.clos, labels=V(g_sna)$label, cex= 0.7,pos=3)



l_tree <-layout.reingold.tilford(g_tree) # good for tree



par(mfrow=c(1,2))

my_graph_plot(g_tree,tree.clos,l_tree);title(main="Hierarchy")

set.seed(42)
l_sna<-layout.auto(g_sna) 
my_graph_plot(g_sna,sna.clos,l_sna);title(main="Closeness")


# return weights
E(g_sna)$weight<-snaWeight




###
#mynetworkD3plot(g_sna,NULL,"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\my2.html")

