library(igraph)

dataEdges<-function(g)
{
ee<-ends(g,c(1:length(E(g))))

E_from<-V(g_sna_with_outsider)$id[ee[,1]]
E_to<-V(g_sna_with_outsider)$id[ee[,2]]
  
E_from_title<-V(g_sna_with_outsider)$Title[ee[,1]]
E_to_title<-V(g_sna_with_outsider)$Title[ee[,2]]

df4edges<-as.data.frame(edge.attributes(g))
df4edges$E_from<-E_from
df4edges$E_to<-E_to
df4edges$E_from_title<-E_from_title
df4edges$E_to_title<-E_to_title
return(df4edges)
 }

