#reconstruct_iGraph_from_PBI_columns
#copy into caller
#source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep="")) 

#load(file="C:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\debug.Rda")
#eFrom <- dataset$autoNodeID
#eTo <- dataset$autoNodeID.1
#eWeight <- dataset$weight
#vID <- dataset$V_id
#vLabel <- dataset$V_label
#autoNodeID<-dataset$autoNodeID.2
library(igraph)

reconstruct_iGraph_from_PBI_columns<-function(eFrom,eTo,eWeight=NULL,vID,vLabel=NULL,autoNodeID)
{
  # eFrom = vID of "from" vertex
  # eTo = vID of "to" vertex
  # eWeight = weight of edge (if null will be replaced by 1)
  # vID = unique IDs of vertices 
  # vLabel = unique strings for vertices "to show", (if NULL will be replaced by vID)
  #autoNodeID = 1,2,3,...
  
  
  #TODO: WORKS WRING IF SOME autoNodeID is missing 
  NV<-length(unique(vID))
  NE<-length(eFrom)
  
 
  
  if(is.null(eWeight)){
    eWeight<-rep(1,NE)
  }
  if(is.null(vLabel)){
    vLabel<-vID
  }
  
  u<-data.frame(vID,vLabel,autoNodeID,stringsAsFactors = F)
  u<-unique(u)
  u<-u[order(u$autoNodeID),]
  
  myIDs<-seq(1,NV)
  names(myIDs)<-as.character(u$autoNodeID)
  
  #g<-graph.empty(n=NV, directed=FALSE)
  #add.vertices(g, myIDs[vID])
  #add.edges(g,as.vector(rbind(myIDs[eFrom],myIDs[eTo])))
  
  #eedges<-as.numeric(as.vector(rbind(myIDs[eFrom],myIDs[eTo])))
  eFromTo<-rbind(eFrom,eTo)
  
  NC<-  ncol(eFromTo)
  keepEdges<-rep(1,NC)
  for (c in seq(1,NC))
    keepEdges[c]<-prod(is.element(eFromTo[,c],u$autoNodeID))
  
  eFromTo<-eFromTo[,as.logical(keepEdges)]
  eedges<-as.numeric(as.vector(eFromTo))
  
  #selectedEdges<-seq(1,NC)
  #selectedEdges<-selectedEdges[as.logical(keepEdges)]
  
  
  
  #g<-graph(eedges,n=max(eedges), directed=F)
  g<-graph(as.character(eedges))
 
  
  #Order rows in u such that autoNodeID coinsides with names(V(g))
  uu<-u[myIDs[names(V(g))],]
  
  
  
  V(g)$label<-as.character(uu$vLabel)
  V(g)$id<-as.character(uu$vID)
  
  g<-simplify(g)
  
  
  #TODO: find selected edges 
  sho<-paste(ends(g,E(g))[,1],ends(g,E(g))[,2],sep="_")
  lo<-paste(eFrom,eTo,sep="_")
  selectedEdges<-match(sho,lo)
  
  
  g$selectedEdges<-selectedEdges
  g$selectedNodes<-match(V(g)$id,as.character(vID))
  
  E(g)$weight<-eWeight[selectedEdges]
  
  
  return(g)
}