#source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\utils_igraph.R",sep=""))
#source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\reconstruct_iGraph_from_PBI_columns.R",sep=""))

dbgf<-paste(Sys.getenv("SNA4PBI_PATH"),"data\\debug.Rda",sep="")
load(file=dbgf)# for DEBUG
tit="Level in hierarchy on top of Social Network"

###########
library(igraph)
############
my_graph_plot<-function(gr,attrib_node,mylayout)
{
  #generate 100 colors black to white
  mcolors<-array(dim=100)
  j<-1
  for (i in seq(0,1,0.01))
  {
    mcolors[j]<-rgb(0,i,0,0.8)
    j<-j+1
  }
  mi<-min(attrib_node)
  ma<-max(attrib_node)
  #assign due to attribute 
  for (i in c(1:length(V(gr))))
  {
    temp<-round(((attrib_node[i]-mi)/(ma-mi))*100)
    V(gr)[i]$color <- mcolors[temp+1]
  }
  V(gr)$label.cex <- 0.5 * attrib_node / ma+ .3
  V(gr)$label.color <- rgb(0.8, 0.2, .0, .8)
  V(gr)$frame.color <- NA
  #plot 
  plot(gr, vertex.color=V(gr)$color,vertex.label=V(gr)$number,layout=mylayout)
}

############################
one_word_labels<-function(la)
{
  L=length(la)
  res<-la
  fff<-strsplit(la," ")
  for(i in c(1:L))
  {
    res[i]<-fff[[i]][1]
    
  }
  return(res)
}
################################

reconstruct_iGraph_from_PBI_columns<-function(eFrom,eTo,eWeight=NULL,vID,vLabel=NULL,autoNodeID)
{
  # eFrom = vID of "from" vertex
  # eTo = vID of "to" vertex
  # eWeight = weight of edge (if null will be replaced by 1)
  # vID = unique IDs of vertices 
  # vLabel = unique strings for vertices "to show", (if NULL will be replaced by vID)
  #autoNodeID = 1,2,3,...
  
  
  #TODO: WORKS WRING IF SOME autoNodeID is missing 
  NV<-length(unique(vID))
  NE<-length(eFrom)
  
  
  
  if(is.null(eWeight)){
    eWeight<-rep(1,NE)
  }
  if(is.null(vLabel)){
    vLabel<-vID
  }
  
  u<-data.frame(vID,vLabel,autoNodeID,stringsAsFactors = F)
  u<-unique(u)
  u<-u[order(u$autoNodeID),]
  
  myIDs<-seq(1,NV)
  names(myIDs)<-as.character(u$autoNodeID)
  
  #g<-graph.empty(n=NV, directed=FALSE)
  #add.vertices(g, myIDs[vID])
  #add.edges(g,as.vector(rbind(myIDs[eFrom],myIDs[eTo])))
  
  #eedges<-as.numeric(as.vector(rbind(myIDs[eFrom],myIDs[eTo])))
  eFromTo<-rbind(eFrom,eTo)
  
  NC<-  ncol(eFromTo)
  keepEdges<-rep(1,NC)
  for (c in seq(1,NC))
    keepEdges[c]<-prod(is.element(eFromTo[,c],u$autoNodeID))
  
  eFromTo<-eFromTo[,as.logical(keepEdges)]
  eedges<-as.numeric(as.vector(eFromTo))
  
  #selectedEdges<-seq(1,NC)
  #selectedEdges<-selectedEdges[as.logical(keepEdges)]
  
  
  
  #g<-graph(eedges,n=max(eedges), directed=F)
  g<-graph(as.character(eedges))
  
  
  #Order rows in u such that autoNodeID coinsides with names(V(g))
  uu<-u[myIDs[names(V(g))],]
  
  
  
  V(g)$label<-as.character(uu$vLabel)
  V(g)$id<-as.character(uu$vID)
  
  g<-simplify(g)
  
  
  #TODO: find selected edges 
 # sho<-paste(ends(g,E(g))[,1],ends(g,E(g))[,2],sep="_")
#  lo<-paste(eFrom,eTo,sep="_")
#  selectedEdges<-match(sho,lo)
  
  
#  g$selectedEdges<-selectedEdges
  g$selectedNodes<-match(V(g)$id,as.character(vID))
  
  E(g)$weight<-1# eWeight[selectedEdges]
  
  
  return(g)
}
####################
my_graph_get_show_node_labels<-function(gr,nodeLabel,nodeLabelShowIndicator,parinfo)
{
  # if graph is overloaded will present only few labels 
  # nodeLabelShowIndicator if NULL => do nothing 
  # if 0 => do not show anything
  # if 1 => show integer indexes
  # nodeLabelShowIndicator => show best and worst automatically 
  
  numNodes<-length(V(gr))
  
  if(is.null(nodeLabelShowIndicator) || numNodes< 12)
    return(gr);
  
  if(length(nodeLabelShowIndicator)==1 && nodeLabelShowIndicator==0)
  {
    V(gr)$label<-NA
    return(gr)
  }
  if(length(nodeLabelShowIndicator)==1 && nodeLabelShowIndicator==1)
  {
    V(gr)$label<-seq(1,length(V(gr)))
    return(gr)
  }
  seder<-sort(nodeLabelShowIndicator,index.return = T)$ix
  
  keepOnly <- 3 #TEMP
  areaSize<-sqrt(prod(parinfo$din))
  areaPerNodeRoot<-sqrt(areaSize/numNodes)# what is an area per node
  
  temp<-as.numeric(as.character(cut(areaPerNodeRoot,
                                    breaks=c(0,0.3,0.5,Inf),
                                    labels=c(0.25,0.5,1))))
  #  print(temp)
  
  keepOnly<-round(temp*numNodes/2)
  
  
  if(keepOnly+1<numNodes-keepOnly)
    V(gr)$label[seder[seq(keepOnly+1,numNodes-keepOnly)]]<-NA
  
  
  
  
  return(gr)
  
}
#############################
my_graph_get_node_rad<-function(gr,nodeRadAttrib,parinfo)
{
  DNR<-1
  
  if(!is.null(nodeRadAttrib) && min(nodeRadAttrib)==max(nodeRadAttrib))
  {
    DNR=nodeRadAttrib[1]
    nodeRadAttrib=NULL
  }
  
  numNodes<-length(V(gr))
  areaSize<-sqrt(prod(parinfo$din))
  
  areaPerNodeRoot<-sqrt(areaSize/numNodes)# what is an area per node
  
  temp<-as.numeric(as.character(cut(areaSize,
                                    breaks=c(0,0.1,0.5,1,2,3,4,5,7,10,20,50,Inf),
                                    labels=c(0.1,0.5,2,3,6,7,8,10,11,12,15,20))))
  #print(temp)
  DNR<-DNR*temp
  
  
  if(!is.null(nodeRadAttrib))
  {
    msizes<-seq(0.3,1.4,length.out = 102)*DNR
    mi<-min(nodeRadAttrib)
    ma<-max(nodeRadAttrib)
    nodeRadAttrib<-(nodeRadAttrib-mi)/(ma-mi)
    #assign due to attribute 
    for (i in c(1:length(V(gr))))
    {
      temp<-round((nodeRadAttrib[i])*100)
      V(gr)[i]$size <- msizes[temp+1]
    }
  }
  else
  {
    V(gr)[]$size <- DNR
  }
  
  return(gr)
}
###########
my_graph_get_node_color<-function(gr,nodeColAttrib,nodeColor,parinfo)
{
  DEFAULT_NODE_COLOR<-rgb(1,1,0.0,0.7)
  mcolors<-array(dim=100)
  j<-1
  for (i in seq(0.2,0.95,length.out = 102))
  {
    mcolors[j]<-rgb(0.1,i,0,0.6)
    j<-j+1
  }
  #(nodeColAttrib)
  if(!is.null(nodeColAttrib) && min(nodeColAttrib)!=max((nodeColAttrib)))
  {
    mi<-min(nodeColAttrib)
    ma<-max(nodeColAttrib)
    nodeColAttrib<-(nodeColAttrib-mi)/(ma-mi)
    #assign due to attribute 
    for (i in c(1:length(V(gr))))
    {
      temp<-round((nodeColAttrib[i])*100)
      V(gr)[i]$color <- mcolors[temp+1]
      
    }
    
  }
  else
  {
    if(is.null(nodeColor)) 
      V(gr)[]$color <- DEFAULT_NODE_COLOR
    else
      V(gr)$color<-nodeColor
  } 
  return(gr)
}

##########
my_graph_get_node_label<-function(gr,nodeLabel,parinfo)
{
  # nodeLabel=NA #TEMP
  DEFAULT_NODE_LABEL<-NA
  DEFAULT_NODE_LABEL_FONT_COLOR<-rgb(0.6, 0.05, .0, .8)
  
  if(!is.null(nodeLabel))
    V(gr)$label<-nodeLabel
  
  V(gr)$label.color <- DEFAULT_NODE_LABEL_FONT_COLOR
  
  return(gr)
}

##################
my_graph_get_node_label_size<-function(gr,nodeLabelSizeAttrib,parinfo)
{
  DEFAULT_NODE_LABEL_SIZE<-0.1
  
  DNLS<-DEFAULT_NODE_LABEL_SIZE
  
  if(!is.null(nodeLabelSizeAttrib) && min(nodeLabelSizeAttrib)==max(nodeLabelSizeAttrib))
  {
    DNLS=nodeLabelSizeAttrib[1]
    nodeLabelSizeAttrib=NULL
  }
  
  numNodes<-length(V(gr))
  areaSize<-sqrt(prod(parinfo$din))
  
  areaPerNodeRoot<-sqrt(areaSize/numNodes)# what is an area per node
  
  temp<-as.numeric(as.character(cut(areaSize,
                                    breaks=c(0,0.1,0.5,1,2,3,4,5,7,10,20,50,Inf),
                                    labels=c(2.1,2.2,2.5,4,6,7,8,9,10,12,15,20))))
  
  print(temp)
  
  DNLS<-DNLS*temp
  
  
  if(!is.null(nodeLabelSizeAttrib))
  {
    msizes<-seq(0.2,2,length.out = 102)*DNLS
    mi<-min(nodeLabelSizeAttrib)
    ma<-max(nodeLabelSizeAttrib)
    nodeLabelSizeAttrib<-(nodeLabelSizeAttrib-mi)/(ma-mi)
    #assign due to attribute 
    for (i in c(1:length(V(gr))))
    {
      temp<-round((nodeLabelSizeAttrib[i])*100)
      V(gr)[i]$label.cex <- nsizes[temp+1]
    }
  }
  else
  {
    V(gr)[]$label.cex <- DNLS
  }
  
  return(gr)
  
}
##################
#  my_graph_plot_advanced 
##################
my_graph_plot_advanced<-function(gr,nodeRadAttrib=NULL,nodeColAttrib=NULL,
                                 nodeLabelShowIndicator=NULL,
                                 nodeLabel=NULL,nodeLabelSizeAttrib=NULL,
                                 nodeGroupIndicator=NULL, nodeColor=NULL,
                                 edgeColorAttrib=NULL,edgeWidthAttrib=NULL,edgeTypeAttrib=NULL,
                                 mylayout=layout.auto(gr))
{
  nodeLabelShowIndicator<-nodeRadAttrib #TEMP
  
  DEFAULT_NODE_SHAPE<-"circle"
  
  DEFAULT_EDGE_WIDTH<-1
  DEFAULT_EDGE_LABEL<-1
  DEFAULT_EDGE_COLOR<-rgb(0.1, 0.1, 0.1, .8)
  
  PARINFO<-par()#PARINFO$din
  PARINFO$side<-sqrt(prod(PARINFO$din))
  
  numNodes<-length(V(gr))
  numEdges<-length(E(gr))
  
  
  # set nodeRad
  gr<-my_graph_get_node_rad(gr,nodeRadAttrib,PARINFO)
  # set nodeColor
  gr<-my_graph_get_node_color(gr,nodeColAttrib,nodeColor,PARINFO)
  
  #TODO: set nodeShape
  #set nodeLabel
  gr<-my_graph_get_node_label(gr,nodeLabel,PARINFO)
  
  
  
  #set nodeLabelSize
  gr<-my_graph_get_node_label_size(gr,nodeLabelSizeAttrib,PARINFO)
  
  
  #set sparse label
  gr<-my_graph_get_show_node_labels(gr,nodeLabel,nodeLabelShowIndicator,PARINFO)
  
  #TODO: set edgeWidth
  #TODO: set edgeLabel
  #TODO: set edgeColor
  
  
  if(is.null(mylayout))
  {
    if(is.directed(gr))
      mylayout <-layout.reingold.tilford(gr,root=1) # good for tree
    else
      mylayout<-layout.fruchterman.reingold(gr)
    
  }
  
  
  V(gr)$frame.color <- NA # no frame on node
  
  if(is.directed(gr))
    plot(gr,vertex.color=V(gr)$color,layout=mylayout,asp=0)
  else
    plot(gr,vertex.color=V(gr)$color,layout=mylayout)
  
}



########################
pbi_R_graph_draw_with_attributes<-function(dataset)
{
  eFrom <- dataset$autoNodeID
  eTo <- dataset$autoNodeID.1
  eWeight <- dataset$weight
  vID <- dataset$V_id
  vLabel <- dataset$V_label
  autoNodeID<-dataset$autoNodeID.2
  
  g<-reconstruct_iGraph_from_PBI_columns(eFrom,eTo,eWeight,vID,vLabel,autoNodeID)
  g<-as.undirected(g)
  
  nodeColAttrib1<-dataset$nodeColAttrib
  
  V(g)$label.dist=0
  V(g)$label.degree=-pi/2
  my_graph_plot_advanced(g,mylayout=NULL,nodeColAttrib=nodeColAttrib1[g$selectedNodes],
                         nodeRadAttrib = nodeColAttrib1[g$selectedNodes])
}

###############################
### NOLOCAL
##############################

#source(paste(Sys.getenv("SNA4PBI_PATH"),"code\\R\\pbi_R_graph_draw_with_attributes.R",sep=""))
set.seed(42)
NC<-ncol(dataset)
dataset$nodeColAttrib<-dataset[,NC]
par(mar=c(5, 4, 4, 2)/7 + 0.1);





pbi_R_graph_draw_with_attributes(dataset)
if(is.null(tit))
  tit<-paste("Attribute on top of Social Network: ",names(dataset)[NC])
title(main=tit)