library(igraph)

#inputFile<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\simple.graphml"
inputFile<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\company.graphml"
#inputFile<-"c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\company_sna.graphml"
#TODO: flexible input
if(inputFile_graphml=="")
{
  myFile <- file.choose()
}

g<-read_graph(file=inputFile,format="graphml")
V(g)$label<-V(g)$id

# node properties
g.n.betw<-betweenness(g)
g.n.clos<-closeness(g,mode="all")
g.n.deg<-degree(g)

g.n.vertices<-V(g)
g.n.alpha_c<-alpha_centrality(g)
g.n.page_rank<-page_rank(g)$vector

#class(g.n.vertices)="numeric"

# graph properties
a<-components(g, mode = c("weak"))
g.num_comp<-a$no
g.n.comp_memb=a$membership
g.avg_deg<-mean(g.n.deg)


#graph in PBI form: table_nodes,table_edges, adjacency matrix
M<-as_adj(g)
adj_matr<-as.data.frame.matrix(M)
#table_nodes<-data.frame(g.n.vertices)
ee<-ends(g,c(1:length(E(g))))
#table_edges
table_edges<-as.data.frame.matrix(ee)
vv<-as.numeric(V(g))
table_nodes<-data.frame(vv)



node_prop<-data.frame(g.vertices,g.n.deg,g.n.betw,g.n.clos,g.n.page_rank,g.n.alpha_c)
#node_prop<-data.frame(g.n.deg,g.n.betw,g.n.clos,g.n.page_rank,g.n.alpha_c)
graph_prop<-data.frame(g.num_comp,g.avg_deg)



####

#visual
dataset<-table_edges

library(igraph)
Emat<-as.matrix.data.frame(dataset)
gra<-graph(t(Emat), n=max(Emat), directed=F)
plot(gra)




## some other staff
library(networkD3)
simpleNetwork(table_edges) # funny plot 
saveNetwork(net_D3,file='c:\\Users\\boefraty\\projects\\PBI\\SNA\\data\\my.html',selfcontained = TRUE)

my_graph_plot<-function(gr,attrib_node,mylayout)
{
  #generate 100 colors black to white
  mcolors<-array(dim=100)
  j<-1
  for (i in seq(0,1,0.01))
  {
    mcolors[j]<-rgb(0,i,0,0.8)
    j<-j+1
  }
  mi<-min(attrib_node)
  ma<-max(attrib_node)
  #assign due to attribute 
  for (i in c(1:length(V(gr))))
  {
    temp<-round(((attrib_node[i]-mi)/(ma-mi))*100)
    V(gr)[i]$color <- mcolors[temp+1]
  }
  V(gr)$label.cex <- 2.2 * attrib_node / ma+ .2
  V(gr)$label.color <- rgb(0.8, 0.2, .0, .8)
  V(gr)$frame.color <- NA
  #plot 
  plot(gr, vertex.color=V(g)$color,vertex.label=V(g)$number,layout=mylayout)

}
l <-layout.reingold.tilford(g,root=1) # good for tree
#l<-layout.auto(g) 

par(mfrow=c(3,2))
my_graph_plot(g,g.n.betw,l);title(main="Betweeness")
my_graph_plot(g,g.n.deg,l);title(main="Degree")
my_graph_plot(g,g.n.clos,l);title(main="Closeness")
my_graph_plot(g,g.n.alpha_c,l);title(main="Alpha Centrality")
my_graph_plot(g,g.n.page_rank,l);title(main="Page Rank")

#par(mfrow=c(1,1))




